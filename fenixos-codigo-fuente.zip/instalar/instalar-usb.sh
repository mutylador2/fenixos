#!/bin/bash
# =====================================================================
# FenixOS 1.2 «Horizonte» — instalador para hardware real (USB/disco)
# Graba la imagen de FenixOS en un dispositivo de bloques de forma segura.
#
# Uso:
#   ./instalar-usb.sh /dev/sdX          # dispositivo completo (USB, HDD)
#   ./instalar-usb.sh --img otra.img /dev/sdX
#
# REQUIERE ROOT (sudo). ¡El dispositivo se SOBREESCRIBE por completo!
# =====================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IMG="${SCRIPT_DIR}/../fenixos.img"

if [ "${1:-}" = "--img" ]; then
    IMG="$2"; shift 2
fi

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: ejecuta con sudo:  sudo $0 /dev/sdX"
    exit 1
fi

if [ -z "${1:-}" ]; then
    echo "Uso: sudo $0 /dev/sdX   (o --img ruta.img /dev/sdX)"
    echo
    echo "Dispositivos de bloque disponibles:"
    lsblk -d -o NAME,SIZE,TYPE,MODEL | grep -E "disk" || true
    exit 1
fi

DEV="$1"

# --- comprobaciones de seguridad ---
if [ ! -b "$DEV" ]; then
    echo "ERROR: '$DEV' no es un dispositivo de bloque."
    exit 1
fi

if [ ! -f "$IMG" ]; then
    echo "ERROR: no encuentro la imagen '$IMG'."
    echo "  Genera la imagen desde el código fuente con 'make' o"
    echo "  pásame otra con: $0 --img ruta/fenixos.img $DEV"
    exit 1
fi

# no permitir el disco del sistema
ROOTDEV="$(findmnt -n -o SOURCE / 2>/dev/null | sed 's/[0-9]*$//' || true)"
if [ "$ROOTDEV" = "$DEV" ]; then
    echo "ERROR: '$DEV' es el disco del sistema. ABORTANDO."
    exit 1
fi

SIZE_IMG=$(stat -c%s "$IMG")
SIZE_DEV=$(blockdev --getsize64 "$DEV")
if [ "$SIZE_DEV" -lt "$SIZE_IMG" ]; then
    echo "ERROR: el dispositivo ($SIZE_DEV bytes) es más pequeño que la imagen ($SIZE_IMG)."
    exit 1
fi

echo "=============================================================="
echo "  FenixOS 1.2 «Horizonte» — instalación en hardware real"
echo "=============================================================="
echo "  Imagen      : $IMG ($((SIZE_IMG/1024/1024)) MB)"
echo "  Destino     : $DEV ($(lsblk -d -n -o MODEL "$DEV" 2>/dev/null | xargs), $((SIZE_DEV/1024/1024)) MB)"
echo
echo "  ATENCIÓN: TODO el contenido de $DEV se perderá."
echo "  Comprueba dos veces que es el dispositivo correcto."
echo
read -r -p "¿Escribir FenixOS en $DEV? Escribe SI en mayúsculas para continuar: " OK
if [ "$OK" != "SI" ]; then
    echo "Cancelado."
    exit 1
fi

echo "[1/4] Desmontando particiones de $DEV..."
umount -f "${DEV}"?* 2>/dev/null || umount -f "$DEV" 2>/dev/null || true

echo "[2/4] Grabando imagen (dd, 4 MB por bloque)..."
dd if="$IMG" of="$DEV" bs=4M conv=fsync status=progress

echo "[3/4] Sincronizando buffers..."
sync

echo "[4/4] Verificando sector de arranque..."
if dd if="$DEV" bs=512 count=1 2>/dev/null | od -An -tx1 | grep -q "55 aa"; then
    echo "      OK: firma 0x55AA presente en el MBR."
else
    echo "      AVISO: no se verifica la firma (algunos medios tardan)."
fi

echo
echo "FenixOS instalado en $DEV."
echo "Arranca el equipo desde ese dispositivo (modo Legacy/CSM)"
echo "y verás el escritorio FenixOS directamente."
echo
echo "Cuentas: admin/fenix · usuario/1234 · invitado (sin clave)"
echo "Orden recomendada al arrancar: 'ayuda' y 'login admin fenix'"
