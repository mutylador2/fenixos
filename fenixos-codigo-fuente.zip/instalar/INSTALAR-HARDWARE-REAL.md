# Instalación de FenixOS 1.4 «Faro» en hardware real

Esta guía explica cómo arrancar e instalar FenixOS en un ordenador físico.
Hay dos caminos:

1. **Arranque directo**: la imagen ya es el sistema completo (bootloader en
   el sector 0 + kernel). Grábala en un USB/disco y arranca: verás el
   **menú multiboot**.
2. **Instalación desde el propio sistema**: arranca el USB/CD y usa el
   **instalador gráfico** para instalar FenixOS en otro disco, en disco
   completo o **«junto a otros OS»** (crea su propia partición sin tocar
   las de Windows/Linux).

---

## 1. Requisitos

| Requisito | Detalle |
|---|---|
| CPU | x86_64 (Intel/AMD de 64 bits) |
| Firmware | BIOS legacy o UEFI con **CSM/Legacy** activable (el bootloader es BIOS, no UEFI puro) |
| RAM | 128 MB mínimo (256 MB recomendado) |
| Vídeo | Cualquier GPU con VBE 2.0+ (todas las posteriores a 2004); pantalla 1024×768 |
| Almacenamiento de arranque | USB, disco SATA/IDE o CD/DVD |
| Entrada | Teclado/ratón PS/2 **o** teclado/ratón USB con "USB legacy support" activado en la BIOS |

---

## 2. Opción A — USB booteable con Rufus o dd (recomendada)

La **misma `fenixos.iso` vale para CD y USB** (lleva un MBR híbrido dentro).

1. **Con Rufus (Windows)**: selecciona `fenixos.iso`, esquema **MBR**,
   destino *BIOS (o UEFI-CSM)* y, si pregunta, modo **DD** («escribir imagen
   exacta»). El aviso de que el ISO es híbrido es lo esperado.
2. **Con dd (Linux/macOS)**: identifica tu USB con cuidado (`lsblk`), por
   ejemplo `/dev/sdb`, y graba:
   `sudo dd if=fenixos.iso of=/dev/sdX bs=4M conv=fsync status=progress`
3. O usa el script incluido: `sudo ./instalar-usb.sh /dev/sdX`
   (comprueba el disco del sistema, pide confirmación en mayúsculas y
   verifica la firma del MBR).
4. **Arranca desde el USB**: en la BIOS/UEFI elige el USB en el menú de
   arranque (F12 normalmente) con **modo Legacy/CSM** activado.
5. Aparecerá el **menú multiboot**: `1) FenixOS`, `2) modo seguro`,
   `3) otro sistema de este disco` (chainload del Windows/Linux ya
   instalado), `4) otro disco`, `5) información del sistema`.

### Instalar FenixOS junto a Windows/Linux desde el propio sistema

Arranca el USB (o el CD) y abre el **instalador** (icono del escritorio u
orden `instalador`):

- Elige el disco interno donde quieres FenixOS.
- El instalador lista las particiones existentes y ofrece dos modos:
  **Disco completo** (lo dedica entero, pide confirmación) o
  **Junto a otros OS**: crea una partición nueva tipo 0x63 en el espacio
  libre, reescribe el MBR conservando las entradas existentes e instala
  stage1/stage2/kernel/config **dentro de su partición**.
- Tras instalar, ese disco arranca el **menú multiboot** de FenixOS y la
  opción 3 encadena el Windows/Linux que ya tuvieras: **nada se borra**.

> Verificación automática: la suite `test_v13.py` instala sobre un disco
> con «Windows» (NTFS) y «Linux» simulados y comprueba byte a byte que sus
> particiones y datos siguen intactos, y que tanto FenixOS como el otro
> sistema arrancan (chainload).

## 3. Opción B — disco duro dedicado

- Escribe la imagen en un disco SATA/IDE completo (no en una partición):
  `sudo dd if=fenixos.img of=/dev/sdX bs=4M conv=fsync status=progress`
- Arranca desde ese disco. FenixOS ocupa los primeros sectores (bootloader +
  kernel) y guarda su configuración al final del disco (LBA reservado).

## 4. Opción C — CD/DVD físico

- Graba `fenixos.iso` con Brasero, ImgBurn, `wodim` o `growisofs`.
- Arranca desde el CD. El disco duro no se toca (la configuración persistente
  solo funciona si hay disco detectado; en caso contrario usa valores por
  defecto y lo indica en el log).

## 5. Primer arranque

1. Verás el **menú multiboot** (desde disco/USB) o el arranque directo
   (desde CD), la consola del kernel en modo texto y después el escritorio
   gráfico.
2. Sesión inicial: `admin` (autologin por defecto). Cuentas:
   - `admin / fenix` — administrador
   - `usuario / 1234` — usuario
   - `invitado` (sin clave) — solo lectura
3. Órdenes recomendadas: `ayuda`, `sistema` (panel del hardware con
   RAM/CPU/GPU/discos), `disco`, `arranque 1 8` (configura el menú),
   `config guardar` (persiste tu configuración en el disco local).
4. Red: este sistema no incluye todavía drivers de las NIC de los PCs
   físicos más comunes (la pila TCP/IP está unida a la e1000 de las VMs);
   en hardware real la red es el siguiente hito de la hoja de ruta.

## 6. Solución de problemas

| Síntoma | Causa probable | Solución |
|---|---|---|
| Arranca en pantalla negra | UEFI puro sin CSM | Activa CSM/Legacy en el firmware |
| No hay teclado/ratón | USB sin legacy support | Activa "USB legacy" en la BIOS; usa puertos PS/2 si existen |
| Pantalla roja de pánico | Hardware muy distinto del emulado | Envíanos el texto del pánico (escribelo a mano, está en pantalla) |
| No detecta el disco | Controladora en modo RAID | Pon la controladora en modo **AHCI** (driver AHCI/SATA propio) o "IDE compatibility" |
| Configuración no persiste | Arranque desde CD sin disco | Es lo esperado: graba en USB/disco para persistencia |
| El menú arranca FenixOS antes de elegir | Autoarranque muy corto | Pulsa 1-5 antes del timeout o cambia el timeout con `arranque <opción> <segundos>` |

## 7. Desinstalar

Borra simplemente: formatea o regraba el USB/disco (`dd if=/dev/zero ...`).
FenixOS no escribe nada fuera de su dispositivo de arranque (salvo la
configuración, en el propio dispositivo).
