#!/usr/bin/env python3
"""dep_httpd2.py: ¿se congela la tarea httpd? — uptime durante el curl"""
import os, socket, subprocess, struct, sys, time

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
SERIAL = "/tmp/dep2.log"
MON = "/tmp/dep2.sock"
DUMP = "/tmp/dep2.pcap"
for f in (SERIAL, MON, DUMP):
    if os.path.exists(f): os.unlink(f)
open(SERIAL, "w").close()

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SERIAL}",
       "-netdev", "user,id=n0,hostfwd=tcp::18080-:80",
       "-device", "e1000,netdev=n0",
       "-object", f"filter-dump,id=f0,netdev=n0,file={DUMP}",
       "-drive", f"if=ide,index=0,format=raw,file={BASE}/fenixos.img"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def monitor(c, wait=0.1):
    mon.sendall((c + "\n").encode())
    time.sleep(wait)
    try: return mon.recv(65536).decode(errors="replace")
    except socket.timeout: return ""

def wait_serial(needle, timeout=60):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if needle in open(SERIAL, errors="replace").read(): return True
        time.sleep(0.4)
    return False

wait_serial("FenixOS 1.4", 60)
time.sleep(3)
KEYMAP = {' ': "spc", '.': "dot", ':': "shift-semicolon", '/': "slash", '\n': "ret"}
def send_text(t, d=0.06):
    for ch in t:
        monitor(f"sendkey {KEYMAP.get(ch, ch)}", d)
    time.sleep(0.3)

send_text("servidor on\n")
print("listen:", wait_serial("escuchando en puerto 80", 10))

# curl en segundo plano y comprobar si 'uptime' responde mientras tanto
curlp = subprocess.Popen(["curl", "-s", "--max-time", "12", "http://127.0.0.1:18080/"],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
time.sleep(4)
S1 = open(SERIAL, errors="replace").read()
n_before = S1.count("escuchando en puerto 80")
print("escuchando count antes:", n_before)
send_text("uptime\n")
time.sleep(1.5)
S2 = open(SERIAL, errors="replace").read()
print("uptime ejecutado durante curl:", "orden: uptime" in S2)
print("escuchando count ahora:", S2.count("escuchando en puerto 80"))
out, _ = curlp.communicate(timeout=20)
print("curl body len:", len(out))
time.sleep(1)
S3 = open(SERIAL, errors="replace").read()
print("escuchando count final:", S3.count("escuchando en puerto 80"))
print("--- cola serial ---")
print("\n".join(S3.splitlines()[-12:]))

monitor("quit", 0.5)
time.sleep(0.5)
subprocess.run(["pkill", "-f", "qemu-system"], capture_output=True)

data = open(DUMP, "rb").read()
off = 24
n = 0
while off + 16 <= len(data) and n < 40:
    ts, tus, capl, oril = struct.unpack("<IIII", data[off:off + 16])
    pkt = data[off + 16:off + 16 + capl]
    off += 16 + capl
    if len(pkt) >= 34:
        et = (pkt[12] << 8) | pkt[13]
        if et == 0x0806:
            print(n, "ARP op", (pkt[20] << 8 | pkt[21]))
        elif et == 0x0800 and pkt[23] == 6:
            ihl = (pkt[14] & 0xF) * 4
            tcp = pkt[14 + ihl:]
            fl = tcp[13]
            flags = "".join(nm for b, nm in [(0x02, "S"), (0x10, "A"), (0x08, "P"), (0x01, "F"), (0x04, "R")] if fl & b)
            print(n, f"TCP {pkt[26]}.{pkt[27]}.{pkt[28]}.{pkt[29]}:{(tcp[0]<<8)|tcp[1]} -> {pkt[30]}.{pkt[31]}.{pkt[32]}.{pkt[33]}:{(tcp[2]<<8)|tcp[3]} [{flags}] len={capl}")
    n += 1
