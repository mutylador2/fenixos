#!/usr/bin/env python3
"""FenixOS — patch_embed.py
Sustituye los placeholders FNXEMB1/FNXEMB2 de kernel.bin por los
binarios reales de stage1.bin y stage2.bin (mismo tamaño; el kernel ya
está enlazado, así que las direcciones no cambian).

Uso: patch_embed.py <kernel_in> <stage1.bin> <stage2.bin> <kernel_out>
"""
import os
import sys

MAGIC1 = b"FNXEMB1"
MAGIC2 = b"FNXEMB2"
SIZE1 = 512
SIZE2 = 40 * 512


def main():
    if len(sys.argv) != 5:
        print("uso: patch_embed.py <kernel_in> <stage1.bin> <stage2.bin> <kernel_out>")
        sys.exit(1)
    kin, s1p, s2p, kout = sys.argv[1:5]
    data = bytearray(open(kin, "rb").read())
    s1 = open(s1p, "rb").read()
    s2 = open(s2p, "rb").read()
    assert len(s1) == SIZE1, f"stage1 mide {len(s1)}, debe medir {SIZE1}"
    assert len(s2) == SIZE2, f"stage2 mide {len(s2)}, debe medir {SIZE2}"

    i1 = data.find(MAGIC1)
    assert i1 >= 0, "no se encontró el marcador FNXEMB1 en kernel.bin"
    assert data.find(MAGIC1, i1 + 1) < 0, "marcador FNXEMB1 duplicado"
    data[i1:i1 + SIZE1] = s1

    i2 = data.find(MAGIC2)
    assert i2 >= 0, "no se encontró el marcador FNXEMB2 en kernel.bin"
    assert data.find(MAGIC2, i2 + 1) < 0, "marcador FNXEMB2 duplicado"
    data[i2:i2 + SIZE2] = s2

    with open(kout, "wb") as f:
        f.write(data)
    print(f"kernel.inst.bin : {len(data)} bytes (stage1@{i1}, stage2@{i2} incrustados)")


if __name__ == "__main__":
    main()
