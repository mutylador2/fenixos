#!/usr/bin/env python3
"""dbg_key.py — prueba sendkey contra el menú del bootloader (modo real)."""
import socket, subprocess, time, os
from PIL import Image

QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-keydbg.sock"
DISK = "/tmp/fenix-otros-os.img"
if os.path.exists(MON): os.unlink(MON)

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait",
       "-drive", f"format=raw,file={DISK}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def shot_size():
    ppm = "/tmp/keydbg.ppm"
    try:
        mon.sendall(f"screendump {ppm}\n".encode())
        time.sleep(0.4)
        img = Image.open(ppm); s = img.size; img.close(); os.unlink(ppm)
        return s
    except Exception as e:
        return None

# esperar a que el menú esté (texto con muchas letras)
for _ in range(12):
    s = shot_size()
    if s == (720, 400):
        break
    time.sleep(0.5)
time.sleep(2)
print("menú arriba, tamaño:", shot_size())

mon.sendall(b"sendkey 1\n")
time.sleep(0.5)
print("'1' enviado")

ok = False
for i in range(24):
    s = shot_size()
    if s == (1024, 768):
        ok = True
        print(f"GUI 1024x768 en t={i*1.0:.0f}s tras la tecla -> sendkey FUNCIONA")
        break
    time.sleep(1.0)
if not ok:
    print("GUI no alcanzada en 24s -> sendkey NO llegó al menú")
mon.close()
proc.terminate()
