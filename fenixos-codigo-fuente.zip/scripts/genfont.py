#!/usr/bin/env python3
"""Genera la fuente bitmap 8x16 de FenixOS renderizando una TTF con PIL.
Salida: kernel/font.c con los glifos ASCII 32..126 (95 glifos, 16 bytes/glyph)."""
from PIL import Image, ImageDraw, ImageFont
import os

CANDIDATES = [
    "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
    "/usr/share/fonts/truetype/english/Carlito-Regular.ttf",
]
FONT_PATH = next((p for p in CANDIDATES if os.path.exists(p)), None)
assert FONT_PATH, "No se encontró ninguna fuente TTF"

CELL_W, CELL_H = 8, 16
FONT_SIZE = 13  # advance ~7.8px para DejaVu Mono a 13px → cabe en 8
FIRST, LAST = 32, 126
N = LAST - FIRST + 1

font = ImageFont.truetype(FONT_PATH, FONT_SIZE)
ascent, descent = font.getmetrics()
y_off = max(0, (CELL_H - (ascent + descent)) // 2 + 1)

glyphs = []
for code in range(FIRST, LAST + 1):
    ch = chr(code)
    img = Image.new("L", (CELL_W, CELL_H), 0)
    d = ImageDraw.Draw(img)
    bbox = d.textbbox((0, 0), ch, font=font)
    w = bbox[2] - bbox[0]
    x = max(0, (CELL_W - w) // 2 - bbox[0])
    d.text((x, y_off), ch, fill=255, font=font)
    px = img.load()
    rows = []
    for y in range(CELL_H):
        b = 0
        for x2 in range(CELL_W):
            if px[x2, y] > 100:
                b |= (1 << (7 - x2))
        rows.append(b)
    glyphs.append(rows)

glyphs[0] = [0] * CELL_H  # espacio en blanco

out = []
out.append("/* Fuente bitmap 8x16 generada automaticamente por scripts/genfont.py")
out.append(" * Origen: " + os.path.basename(FONT_PATH) + " a " + str(FONT_SIZE) + "px")
out.append(" * Glifos ASCII " + str(FIRST) + ".." + str(LAST) + " (95), 16 bytes por glifo, bit 7 = pixel mas a la izquierda */")
out.append("")
out.append('#include "font.h"')
out.append("")
out.append("const unsigned char font8x16[%d][%d] = {" % (N, CELL_H))
for i, code in enumerate(range(FIRST, LAST + 1)):
    rows = glyphs[i]
    c = chr(code)
    label = "\\\\" if c == "\\" else c
    out.append("    { /* '%s' 0x%02X */" % (label, code))
    body = []
    for y in range(0, CELL_H, 8):
        chunk = ", ".join("0x%02X" % rows[j] for j in range(y, min(y + 8, CELL_H)))
        body.append("        " + chunk)
    out.append(",\n".join(body))
    out.append("    },")
out.append("};")
out.append("")

with open(os.path.join(os.path.dirname(__file__), "..", "kernel", "font.c"), "w") as f:
    f.write("\n".join(out))

print("font.c generado:", N, "glifos desde", FONT_PATH)
for code in [ord('A'), ord('a'), ord('0'), ord(':'), ord('$'), ord('>')]:
    g = glyphs[code - FIRST]
    print(chr(code) + ":")
    for row in g:
        print("".join("#" if row & (1 << (7 - x)) else "." for x in range(8)))
