#!/usr/bin/env python3
"""test_usb.py — simula Rufus en modo DD: vuelca fenixos.iso a un disco y
arranca desde él como USB (HDD). Verifica: menú multiboot -> opción 1 ->
kernel 1.3 -> escritorio. Genera captura 37-usb-rufus.png."""
import os, socket, subprocess, sys, time
from PIL import Image

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
USB = "/tmp/fenix-usb-rufus.img"
MON = "/tmp/fenix-usb.sock"
SER = os.path.join(OUT, "serial-usb-rufus.log")

# 1) "grabar" el ISO con dd (lo que hace Rufus en modo DD)
r = subprocess.run(["dd", f"if={BASE}/fenixos.iso", f"of={USB}",
                    "bs=4M", "conv=fsync"], capture_output=True, text=True)
assert r.returncode == 0, r.stderr
print(f"ISO volcado a {USB} ({os.path.getsize(USB)} bytes)")

# 2) comprobaciones binarias: MBR híbrido con firma y partición
d = open(USB, "rb").read(512)
assert d[510] == 0x55 and d[511] == 0xAA, "el sector 0 del ISO no es MBR arrancable"
ptype = d[446 + 4]
start = int.from_bytes(d[446 + 8:446 + 12], "little")
print(f"MBR híbrido OK: partición tipo 0x{ptype:02x} start LBA {start}")
assert ptype == 0x17 or ptype != 0, "tipo de partición híbrida inesperado"

# 3) arrancar como disco USB
if os.path.exists(MON): os.unlink(MON)
open(SER, "w").close()
cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SER}",
       "-drive", f"format=raw,file={USB}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def shot(tag):
    ppm = os.path.join(OUT, tag + ".ppm")
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    img = Image.open(ppm).convert("RGB")
    img.save(os.path.join(OUT, tag + ".png"))
    os.unlink(ppm)
    return img

ok_menu = False
for _ in range(30):
    ppm = "/tmp/usb.ppm"
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    try:
        img = Image.open(ppm); s = img.size; img.close(); os.unlink(ppm)
    except Exception:
        time.sleep(0.3); continue
    if s == (720, 400):
        ok_menu = True
        break
    time.sleep(0.5)
time.sleep(3.5)                       # margen SeaBIOS
img = shot("37-usb-rufus-menu")
print("menú del USB (720x400):", "OK" if ok_menu else "FALLO")

# arrancar opción 1
mon.sendall(b"sendkey 1\n")
time.sleep(0.5)

ok_gui = False
for _ in range(40):
    ppm = "/tmp/usb2.ppm"
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.6)
    try:
        img = Image.open(ppm); s = img.size; img.close(); os.unlink(ppm)
    except Exception:
        time.sleep(0.3); continue
    if s == (1024, 768):
        ok_gui = True
        break

ser = open(SER, errors="replace").read()
ok_titan = "FenixOS 1.3 'Titan'" in ser
time.sleep(3)
img = shot("37-usb-rufus-escritorio")
mon.close()
proc.terminate()

print(f"arranque USB: menú={ok_menu} Titan={ok_titan} escritorio={ok_gui}")
sys.exit(0 if (ok_menu and ok_titan and ok_gui) else 1)
