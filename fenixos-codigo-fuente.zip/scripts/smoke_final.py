#!/usr/bin/env python3
"""smoke_final.py — verificación final de entrega:
  1) arranque por CD (-cdrom, ruta El Torito)
  2) arranque del VHD fresco (ruta VirtualBox aproximada por QEMU)
Genera capturas 38-cd-escritorio.png y 39-vhd-escritorio.png."""
import os, socket, subprocess, sys, time
from PIL import Image

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")

def boot_and_check(tag, extra, serial):
    MON = f"/tmp/fenix-smoke-{tag}.sock"
    if os.path.exists(MON): os.unlink(MON)
    open(serial, "w").close()
    cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
           "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{serial}"] + extra
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    for _ in range(100):
        if os.path.exists(MON): break
        time.sleep(0.1)
    mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    mon.connect(MON); mon.settimeout(2.0)
    try: mon.recv(4096)
    except socket.timeout: pass

    ok_gui = False
    for _ in range(60):
        ppm = f"/tmp/smoke-{tag}.ppm"
        try:
            mon.sendall(f"screendump {ppm}\n".encode())
            time.sleep(0.6)
            img = Image.open(ppm); s = img.size; img.close(); os.unlink(ppm)
        except Exception:
            time.sleep(0.3); continue
        if s == (1024, 768):
            ok_gui = True
            break
    time.sleep(3)
    ppm = os.path.join(OUT, f"{tag}-escritorio.ppm")
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.6)
    img = Image.open(ppm).convert("RGB")
    img.save(os.path.join(OUT, f"{tag}-escritorio.png"))
    os.unlink(ppm)
    ser = open(serial, errors="replace").read()
    mon.close()
    proc.terminate()
    titan = "FenixOS 1.3 'Titan'" in ser
    print(f"{tag}: Titan={titan} escritorio={ok_gui}")
    return titan and ok_gui

cd_ok = boot_and_check("38-cd", ["-cdrom", f"{BASE}/fenixos.iso"],
                       os.path.join(OUT, "serial-cd.log"))
subprocess.run(["pkill", "-f", "qemu-system"], capture_output=True)
time.sleep(2)

vhd_ok = boot_and_check("39-vhd", ["-drive", f"format=vpc,file={BASE}/fenixos.vhd"],
                        os.path.join(OUT, "serial-vhd.log"))
subprocess.run(["pkill", "-f", "qemu-system"], capture_output=True)
sys.exit(0 if (cd_ok and vhd_ok) else 1)
