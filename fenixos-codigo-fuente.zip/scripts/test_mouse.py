#!/usr/bin/env python3
"""FenixOS — test_mouse.py
Prueba automatizada del RATÓN PS/2 en QEMU headless:
  - mueve el cursor con 'mouse_move' del monitor HMP
  - hace clicks con 'mouse_button' (1 = izquierdo)
  - verifica por PÍXELES que el cursor se movió, que un click abre
    la ventana FenixDemo y que el arrastre de ventanas funciona
  - comprueba en serial.log que el driver recibió ACK del ratón
Genera capturas 07..11 en capturas/.
"""
import os
import re
import socket
import subprocess
import sys
import time

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG = os.path.join(BASE, "fenixos.img")
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
SERIAL = os.path.join(OUT, "serial.log")
MON = "/tmp/fenix-mmon.sock"

os.makedirs(OUT, exist_ok=True)
if os.path.exists(MON):
    os.unlink(MON)

cmd = [
    QEMU,
    "-drive", f"format=raw,file={IMG}",
    "-m", "256",
    "-vga", "std",
    "-nic", "none",
    "-display", "none",
    "-monitor", f"unix:{MON},server,nowait",
    "-serial", f"file:{SERIAL}",
]

print("[test] lanzando QEMU:", " ".join(cmd))
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)

for _ in range(100):
    if os.path.exists(MON):
        break
    time.sleep(0.1)
else:
    print("[test] ERROR: el monitor no apareció")
    proc.kill()
    sys.exit(1)

time.sleep(1.0)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON)
mon.settimeout(2.0)
try:
    mon.recv(4096)  # banner
except socket.timeout:
    pass


def monitor(command, wait=0.1):
    mon.sendall((command + "\n").encode())
    time.sleep(wait)
    try:
        return mon.recv(65536).decode(errors="replace")
    except socket.timeout:
        return ""


KEYMAP = {' ': "spc", '.': "dot", ',': "comma", '-': "minus", '=': "equal",
          '/': "slash", ';': "semicolon", "'": "apostrophe", '\n': "ret"}


def send_text(text):
    for ch in text:
        key = KEYMAP.get(ch, ch)
        monitor(f"sendkey {key}", 0.06)
    time.sleep(0.3)


def mouse_move(dx, dy, wait=0.12):
    monitor(f"mouse_move {dx} {dy}", wait)


def click(wait=0.4):
    monitor("mouse_button 1", wait)
    monitor("mouse_button 0", 0.1)


def ppm_to_png(ppm_path, png_path):
    from PIL import Image
    img = Image.open(ppm_path)
    img.save(png_path)
    return img.size


def load(path):
    from PIL import Image
    return Image.open(path).convert("RGB")


def is_accent(c, focused_only=False):
    if not focused_only and near(c, ACCENT_UNFOCUSED, 25):
        return True
    return near(c, ACCENT, 40)


def cursor_white(img, mx, my):
    """cuenta píxeles casi blancos en la caja 10x16 del cursor"""
    px = img.load()
    n = 0
    for y in range(my, min(my + 16, img.size[1])):
        for x in range(mx, min(mx + 10, img.size[0])):
            r, g, b = px[x, y]
            if r > 220 and g > 220 and b > 220:
                n += 1
    return n


def pix(img, x, y):
    return img.load()[x, y]


def near(c, t, tol):
    return all(abs(a - b) <= tol for a, b in zip(c, t))


ACCENT = (0xFF, 0x7A, 0x18)          # acento tema fuego (ventana con foco)
ACCENT_UNFOCUSED = (0x5A, 0x60, 0x68)  # acento de ventana sin foco
DEMO_BODY = (0x0A, 0x0E, 0x12)       # fondo ventana FenixDemo

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(f"[test] {'OK ' if cond else 'FALLO'} {name} {detail}")


def shot(tag):
    ppm = os.path.join(OUT, tag + ".ppm")
    monitor(f"screendump {ppm}", 0.3)
    png = os.path.join(OUT, tag + ".png")
    size = ppm_to_png(ppm, png)
    print(f"[test] captura {tag} -> {size[0]}x{size[1]}")
    return load(ppm)


# ---- diagnóstico: dispositivo de ratón activo en QEMU ----
print("[test] info mice:", monitor("info mice", 0.3).replace("\n", " | ")[:200])

# ---- 1. arranque + 'raton' antes de mover nada (cursor en el centro) ----
time.sleep(15.0)
send_text("raton\n")
time.sleep(0.8)
img0 = shot("07-raton-antes")
check("cursor visible en el centro (512,384)", cursor_white(img0, 512, 384) >= 10,
      f"blancos={cursor_white(img0, 512, 384)}")

# ---- 2. mover el cursor al icono Demo (54,150) ----
for dx, dy in [(-200, 0), (-200, 0), (-58, 0), (0, -234)]:
    mouse_move(dx, dy)
time.sleep(0.6)
img1 = shot("08-raton-movido")
check("cursor SE MOVIÓ al punto (54,150)", cursor_white(img1, 54, 150) >= 10,
      f"blancos={cursor_white(img1, 54, 150)}")
check("cursor ya NO está en el centro", cursor_white(img1, 512, 384) < 5,
      f"blancos={cursor_white(img1, 512, 384)}")

# ---- 3. click izquierdo sobre el icono Demo -> se abre FenixDemo ----
click(0.5)
time.sleep(1.0)
img2 = shot("09-click-demo")
check("ventana FenixDemo abierta (cuerpo en 834,200)",
      near(pix(img2, 834, 200), DEMO_BODY, 12), f"px={pix(img2, 834, 200)}")
check("antes del click ese punto era fondo", not near(pix(img1, 834, 200), DEMO_BODY, 12),
      f"px={pix(img1, 834, 200)}")

# ---- 4. arrastrar la ventana FenixShell por su barra de título ----
# agarrar en (300,62): título de la shell en (60,48)
for dx, dy in [(123, 0), (123, 0), (0, -88)]:
    mouse_move(dx, dy)
time.sleep(0.2)
check("línea de acento de la shell ANTES del arrastre (400,49)",
      is_accent(pix(img2, 400, 49)), f"px={pix(img2, 400, 49)}")
monitor("mouse_button 1", 0.4)
for dx, dy in [(60, 40), (60, 40), (60, 40)]:   # +180,+120
    mouse_move(dx, dy)
monitor("mouse_button 0", 0.1)
time.sleep(0.8)
img3 = shot("10-arrastre")
check("ventana arrastrada: acento en la nueva posición (400,169)",
      is_accent(pix(img3, 400, 169), focused_only=True), f"px={pix(img3, 400, 169)}")
check("posición antigua liberada (400,49 ya no es acento)",
      not is_accent(pix(img3, 400, 49)), f"px={pix(img3, 400, 49)}")

# ---- 5. click en el botón de la shell en la taskbar + 'raton' final ----
for dx, dy in [(-200, 0), (-103, 0), (0, 200), (0, 200), (0, 168)]:
    mouse_move(dx, dy)
time.sleep(0.2)
click(0.5)
time.sleep(0.6)
send_text("raton\n")
time.sleep(0.8)
img4 = shot("11-raton-despues")
check("cursor sobre el botón de taskbar (177,750)", cursor_white(img4, 177, 750) >= 10,
      f"blancos={cursor_white(img4, 177, 750)}")

# ---- cerrar QEMU ----
monitor("quit")
try:
    proc.wait(timeout=5)
except subprocess.TimeoutExpired:
    proc.kill()

# ---- serial.log: el driver debe haber recibido ACK del ratón ----
serial_txt = ""
if os.path.exists(SERIAL):
    with open(SERIAL) as f:
        serial_txt = f.read()
line_hw = ""
for ln in serial_txt.splitlines():
    if "][HW] raton" in ln:
        line_hw = ln
ack_ok = bool(line_hw) and ("habilitado" in line_hw or "activo" in line_hw)
check("serial.log: driver del ratón inicializado", ack_ok, line_hw)

# ---- informe ----
print("\n===== informe del test de ratón =====")
fallos = 0
for name, ok, detail in results:
    if not ok:
        fallos += 1
    print(f"  {'OK ' if ok else 'FALLO'}  {name}  {detail}")
print(f"\n{len(results) - fallos}/{len(results)} comprobaciones correctas")
sys.exit(0 if fallos == 0 else 2)
