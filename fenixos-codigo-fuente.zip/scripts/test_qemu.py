#!/usr/bin/env python3
"""FenixOS — test_qemu.py
Prueba automatizada del sistema en QEMU headless:
  - Arranca fenixos.img con monitor en socket unix y serial a archivo
  - Captura pantallas (screendump) en momentos clave
  - Escribe órdenes en la shell con sendkey
  - Convierte los PPM a PNG y verifica que hay contenido en pantalla
"""
import os
import socket
import subprocess
import sys
import time

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG = os.path.join(BASE, "fenixos.img")
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
SERIAL = os.path.join(OUT, "serial.log")
MON = "/tmp/fenix-qmon.sock"

os.makedirs(OUT, exist_ok=True)
if os.path.exists(MON):
    os.unlink(MON)

cmd = [
    QEMU,
    "-drive", f"format=raw,file={IMG}",
    "-m", "256",
    "-vga", "std",
    "-nic", "none",
    "-display", "none",
    "-monitor", f"unix:{MON},server,nowait",
    "-serial", f"file:{SERIAL}",
]

print("[test] lanzando QEMU:", " ".join(cmd))
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)

# esperar socket del monitor
for _ in range(100):
    if os.path.exists(MON):
        break
    time.sleep(0.1)
else:
    print("[test] ERROR: el monitor no apareció")
    proc.kill()
    sys.exit(1)

time.sleep(1.0)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON)
mon.settimeout(2.0)
try:
    mon.recv(4096)  # banner
except socket.timeout:
    pass


def monitor(command, wait=0.1):
    mon.sendall((command + "\n").encode())
    time.sleep(wait)
    try:
        return mon.recv(65536).decode(errors="replace")
    except socket.timeout:
        return ""


def screendump(name, wait=0.3):
    path = os.path.join(OUT, name + ".ppm")
    monitor(f"screendump {path}", wait)
    return path


KEYMAP = {
    ' ': "spc", '.': "dot", ',': "comma", '-': "minus", '=': "equal",
    '/': "slash", ';': "semicolon", "'": "apostrophe", ':': "shift-semicolon",
    '_': "shift-minus", '\n': "ret",
}


def send_text(text):
    for ch in text:
        key = KEYMAP.get(ch, ch)
        monitor(f"sendkey {key}", 0.06)
    time.sleep(0.3)


def ppm_to_png(ppm_path, png_path):
    from PIL import Image
    img = Image.open(ppm_path)
    img.save(png_path)
    return img.size


def analyze(ppm_path):
    """Detecta si la pantalla tiene contenido (no es toda negra)."""
    from PIL import Image
    img = Image.open(ppm_path).convert("RGB")
    w, h = img.size
    px = img.load()
    colors = set()
    for y in range(0, h, 16):
        for x in range(0, w, 16):
            colors.add(px[x, y])
    return len(colors)


results = []
shots = []


def shot(tag, note=""):
    ppm = screendump(tag)
    png = os.path.join(OUT, tag + ".png")
    size = ppm_to_png(ppm, png)
    ncolors = analyze(ppm)
    shots.append(png)
    results.append((tag, ncolors, note))
    print(f"[test] {tag}: {size[0]}x{size[1]}, {ncolors} colores muestreados -> {png}")
    return ncolors


# ---- 1. arranque y escritorio ----
time.sleep(14.0)                   # tiempo para menú (8s) + boot + GUI
shot("01-escritorio", "desktop tras arranque")

# ---- 2. comando info (osfetch) ----
send_text("info\n")
time.sleep(0.8)
shot("02-info", "salida de info")

# ---- 3. mem y ps ----
send_text("mem\n")
time.sleep(0.6)
send_text("ps\n")
time.sleep(0.6)
shot("03-mem-ps", "memoria y tareas")

# ---- 4. demo ----
send_text("demo on\n")
time.sleep(1.2)
shot("04-demo", "ventana demo activa")

# ---- 5. tema ----
send_text("tema azul\n")
time.sleep(0.8)
shot("05-tema-azul", "tema azul")

# ---- 6. fecha + uptime ----
send_text("tema fuego\n")
time.sleep(0.5)
send_text("fecha\n")
time.sleep(0.5)
send_text("uptime\n")
time.sleep(0.5)
shot("06-fecha-uptime", "fecha y uptime")

monitor("quit")
try:
    proc.wait(timeout=5)
except subprocess.TimeoutExpired:
    proc.kill()

# ---- informe ----
print("\n===== informe =====")
ok = True
for tag, ncolors, note in results:
    status = "OK" if ncolors > 8 else "SOSPECHOSO"
    if ncolors <= 8:
        ok = False
    print(f"  {tag:16s} colores={ncolors:5d} {status} ({note})")

print("\n===== serial.log =====")
if os.path.exists(SERIAL):
    with open(SERIAL) as f:
        print(f.read()[:3000])

sys.exit(0 if ok else 2)
