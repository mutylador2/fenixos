#!/usr/bin/env python3
"""FenixOS — smoke_v13.py: arranque básico de las 3 rutas de la v1.3
  1) fenixos.img como disco  -> menú multiboot -> autoarranque -> escritorio
  2) fenixos.iso como CD     -> arranque directo -> escritorio
  3) fenixos.iso como DISCO  (ruta USB híbrida) -> menú -> escritorio
"""
import os, socket, subprocess, sys, time

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
os.makedirs(OUT, exist_ok=True)
MON = "/tmp/fenix-smoke.sock"
if os.path.exists(MON): os.unlink(MON)

def boot_and_check(tag, extra, expect_serial, wait_menu=0):
    sock = MON + "." + tag
    if os.path.exists(sock): os.unlink(sock)
    cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
           "-monitor", f"unix:{sock},server,nowait",
           "-serial", f"file:{OUT}/serial-{tag}.log"] + extra
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    for _ in range(100):
        if os.path.exists(sock): break
        time.sleep(0.1)
    mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    mon.connect(sock); mon.settimeout(2.0)
    try: mon.recv(4096)
    except socket.timeout: pass
    time.sleep(6 + wait_menu)
    ppm = os.path.join(OUT, f"smoke-{tag}.ppm")
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    time.sleep(8)
    S = open(f"{OUT}/serial-{tag}.log", errors="replace").read()
    ok = expect_serial in S
    print(f"[{tag}] {'OK  ' if ok else 'FALLO'} serial contiene '{expect_serial}'")
    mon.close()
    p.terminate()
    return ok

r1 = boot_and_check("img-menu", ["-drive", f"format=raw,file={BASE}/fenixos.img"],
                    "FenixOS 1.3 'Titan' iniciando", wait_menu=10)
r2 = boot_and_check("cd-directo", ["-cdrom", f"{BASE}/fenixos.iso"],
                    "FenixOS 1.3 'Titan' iniciando", wait_menu=2)
r3 = boot_and_check("usb-hibrido", ["-drive", f"format=raw,file={BASE}/fenixos.iso,if=ide"],
                    "FenixOS 1.3 'Titan' iniciando", wait_menu=10)
print("smoke:", "OK" if (r1 and r2 and r3) else "FALLOS", f"({r1},{r2},{r3})")
sys.exit(0 if (r1 and r2 and r3) else 1)
