#!/usr/bin/env python3
"""dbg_int16.py — prueba mínima de sendkey + BIOS int 0x16 en modo real."""
import socket, subprocess, time, os
from PIL import Image

QEMU = "/home/z/my-project/tools/qemu"
NASM = "/home/z/my-project/tools/root/usr/bin/nasm"
MON = "/tmp/fenix-i16.sock"

ASM = r"""
BITS 16
ORG 0x7C00
start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    sti
    mov si, hello
.p: lodsb
    or al, al
    jz .w
    mov ah, 0x0E
    mov bx, 0x07
    int 0x10
    jmp .p
.w:
    mov ah, 0x01
    int 0x16
    jz .w
    mov ah, 0x00
    int 0x16
    mov ah, 0x0E
    mov bx, 0x07
    int 0x10
    cmp al, '5'
    je .done
    jmp .w
.done:
    mov si, ok
.p2:
    lodsb
    or al, al
    jz .h
    mov ah, 0x0E
    mov bx, 0x07
    int 0x10
    jmp .p2
.h:
    hlt
    jmp .h
hello db "int16 test - pulsa 5: ", 0
ok    db "  [OK RECIBIDO]", 0
times 510-($-$$) db 0
dw 0xaa55
"""

open("/tmp/i16.asm", "w").write(ASM)
r = subprocess.run([NASM, "-f", "bin", "/tmp/i16.asm", "-o", "/tmp/i16.img"],
                   capture_output=True, text=True)
assert r.returncode == 0, r.stderr

if os.path.exists(MON): os.unlink(MON)
cmd = [QEMU, "-m", "128", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait",
       "-drive", "format=raw,file=/tmp/i16.img"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def dump(tag):
    ppm = f"/tmp/i16-{tag}.ppm"
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    img = Image.open(ppm).convert("RGB")
    img.save(f"/tmp/i16-{tag}.png")
    os.unlink(ppm)
    return img

time.sleep(3)
img = dump("antes")
px = img.load()
# texto inicial visible? (píxeles claros en la zona superior)
n0 = sum(1 for y in range(0, 40) for x in range(0, 400) if px[x, y][0] > 120)
print(f"texto inicial visible: {n0} px claros")

mon.sendall(b"sendkey 5\n")
time.sleep(1.5)
img = dump("despues")
px = img.load()
n1 = sum(1 for y in range(0, 40) for x in range(0, 720) if px[x, y][0] > 120)
print(f"tras sendkey 5: {n1} px claros (si >> n0 y aparece [OK], int16 recibe)")
print("PNG: /tmp/i16-antes.png /tmp/i16-despues.png")
mon.close()
proc.terminate()
