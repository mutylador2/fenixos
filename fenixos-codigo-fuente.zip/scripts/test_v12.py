#!/usr/bin/env python3
"""FenixOS — test_v12.py
Suite automatizada de las NOVEDADES de la v1.2 en QEMU headless:
  - red: ping 10.0.2.2 (ICMP real por slirp) verificado por el serial
  - navegador: nav http://example.com (DNS + TCP + HTTP real) + ventana
  - calculadora gráfica: clicks reales en 5 + 3 = y verificación de píxeles
  - visor de archivos con desplazamiento
  - FenixScript: ext / fx hola.fx / EXEC dentro de script
  - FenixCompat: win muestra.exe (análisis MZ/PE)
  - usuarios y permisos: login usuario -> apagar denegado -> volver a admin
  - logs y ps
  - configuración persistente: hostname + tema azul guardados en disco,
    REARRANQUE y verificación de que se recargan (serial + píxeles)
Genera capturas 21-29 en capturas/ y devuelve 0 si TODO pasa.
"""
import os, socket, subprocess, sys, time
from PIL import Image

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG = os.path.join(BASE, "fenixos.img")
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
SERIAL = os.path.join(OUT, "serial-v12.log")
MON = "/tmp/fenix-v12.sock"
os.makedirs(OUT, exist_ok=True)
if os.path.exists(MON): os.unlink(MON)

results = []

def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(f"[test] {'OK  ' if cond else 'FALLO'} {name} {extra}")

cmd = [QEMU, "-drive", f"format=raw,file={IMG}", "-m", "256", "-vga", "std",
       "-nic", "user,model=e1000", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SERIAL}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
time.sleep(1.0)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def monitor(command, wait=0.1):
    mon.sendall((command + "\n").encode())
    time.sleep(wait)
    try: return mon.recv(65536).decode(errors="replace")
    except socket.timeout: return ""

KEYMAP = {' ': "spc", '.': "dot", ',': "comma", '-': "minus", '=': "equal",
          '/': "slash", ';': "semicolon", ':': "shift-semicolon",
          "'": "apostrophe", '\n': "ret"}
CUR = (512, 384)

def send_text(text):
    for ch in text:
        key = KEYMAP.get(ch, ch)
        monitor(f"sendkey {key}", 0.06)
    time.sleep(0.25)

def mouse_to(x, y, wait=0.12):
    global CUR
    dx, dy = x - CUR[0], y - CUR[1]
    monitor(f"mouse_move {dx} {dy}", wait)
    CUR = (x, y)

def click(wait=0.4):
    monitor("mouse_button 1", wait)
    monitor("mouse_button 0", 0.1)

def shot(tag):
    ppm = os.path.join(OUT, tag + ".ppm")
    monitor(f"screendump {ppm}", 0.4)
    img = Image.open(ppm).convert("RGB")
    img.save(os.path.join(OUT, tag + ".png"))
    os.unlink(ppm)
    return img

def count_color(img, box, pred):
    px = img.load()
    n = 0
    for y in range(box[1], box[3]):
        for x in range(box[0], box[2]):
            if pred(*px[x, y]): n += 1
    return n

green = lambda r, g, b: g > 170 and r < 160 and b < 180      # 0xFF7EE787
blue  = lambda r, g, b: b > 25 and b > r and b >= g - 4       # tema azul (oscuro)
serial_read = lambda: open(SERIAL, errors="replace").read()

# ============================ arranque ============================
time.sleep(27)
S = serial_read()
check("arranque: kernel 1.3", "FenixOS 1.3 'Titan'" in S)
check("arranque: ATA detectado", "QEMU HARDDISK" in S)
check("arranque: e1000 lista", "e1000 lista" in S)
check("arranque: pila TCP/IP", "pila lista: IP 10.0.2.15" in S)
check("arranque: sesion admin", "sesion iniciada como 'admin'" in S)

# ============================ info ============================
send_text("info\n")
time.sleep(1)
S = serial_read()
check("orden: info ejecutada", "orden: info" in S)
img = shot("21-info-v12")

# ============================ ping ============================
send_text("ping 10.0.2.2\n")
time.sleep(6)
S = serial_read()
ok_echos = S.count("ICMP] eco") + S.count("eco")  # trazas del driver
check("ping: orden ejecutada", "orden: ping" in S)
check("ping: ecos ICMP OK", "ICMP] eco 1 OK" in S, f"({S.count('[I][ICMP]')} ecos)")
img = shot("22-ping-gateway")

# ============================ navegador ============================
send_text("nav http://example.com\n")
time.sleep(14)
S = serial_read()
check("nav: DNS resuelto", "TCP] connect example.com:80 -> OK" in S or "TCP] connect" in S)
check("nav: respuesta HTTP", "respuesta recibida" in S)
check("nav: estado 200", "estado 200" in S)
img = shot("23-nav-example")

# ============================ calculadora ============================
mouse_to(180, 750); click(0.3)          # foco a la terminal (el visor lo tenia)
send_text("calculadora\n")
time.sleep(1.2)
# geometría de la ventana (1024x768): x=744, y=432, rejilla desde (752, 504)
CX, CY, GX, GY = 744, 432, 752, 504
def calc_click(col, row, wait=0.35):
    x = CX + 8 + col * 60 + 28
    y = GY + row * 56 + 26
    mouse_to(x, y); click(wait)
img = shot("24a-calculadora")
calc_click(1, 1)          # 5
calc_click(3, 3)          # +
calc_click(2, 2)          # 3
calc_click(2, 3)          # =
time.sleep(0.6)
img = shot("24b-calculadora-5mas3")
# el resultado "8" se pinta en verde en el visor (zona superior de la ventana)
zona_disp = (CX + 2, CY + 30, CX + 246, CY + 62)
verdes = count_color(img, zona_disp, green)
check("calculadora: 5+3=8 mostrado", verdes > 22, f"({verdes} px verdes)")

# ============================ visor ============================
mouse_to(180, 750); click(0.3)          # volver al foco de la terminal
send_text("visor notas.txt\n")
time.sleep(1.2)
img = shot("25-visor-notas")
send_text("\n")  # devolver foco a la terminal no hace falta: visor tiene foco

# clic en la barra de tareas para devolver el foco a la shell
mouse_to(180, 750); click(0.3)

# ============================ FenixScript ============================
send_text("ext\n")
time.sleep(1)
S = serial_read()
check("ext: orden ejecutada", "orden: ext" in S)
img = shot("26a-ext")

send_text("fx hola.fx\n")
time.sleep(1.5)
S = serial_read()
check("fx: orden ejecutada", "orden: fx" in S)
img = shot("26b-fx-hola")
# la salida del script contiene "n = 7": texto claro en la ventana shell
claros = count_color(img, (60, 48, 680, 448), lambda r, g, b: r > 200 and g > 200 and b > 200)
check("fx: salio texto del script", claros > 200, f"({claros} px)")

send_text("fx cuenta.fx\n")
time.sleep(1.5)
img = shot("26c-fx-cuenta")

# ============================ FenixCompat ============================
send_text("win muestra.exe\n")
time.sleep(1.2)
S = serial_read()
check("win: analisis COMPAT", "COMPAT] analisis de 'muestra.exe'" in S)
img = shot("27-win-compat")

# ============================ logs y ps ============================
send_text("logs\n")
time.sleep(1)
img = shot("28-logs")
send_text("ps\n")
time.sleep(1)
img = shot("29-ps-cpu")

# ============================ permisos ============================
send_text("login usuario 1234\n")
time.sleep(1)
S = serial_read()
check("login: cambio a usuario", "login: 'usuario' (rol usuario)" in S)
send_text("apagar\n")
time.sleep(1)
S = serial_read()
check("permiso: apagar denegado a usuario", "'apagar' denegada a 'usuario'" in S)
img = shot("30-permiso-denegado")
send_text("login admin fenix\n")
time.sleep(1)

# ============================ config persistente ============================
send_text("config hostname fenix-v12\n")
time.sleep(1)
send_text("tema azul\n")
time.sleep(0.8)
send_text("config guardar\n")
time.sleep(2)
S = serial_read()
check("config: guardada en disco", "configuración guardada en disco" in S)

# ============================ REARRANQUE + persistencia ============================
send_text("reboot\n")
time.sleep(29)
S = serial_read()
check("rearranque: config cargada del disco", "configuración cargada del disco" in S)
check("rearranque: tema azul aplicado", "tema aplicado: azul" in S)
time.sleep(3)
img = shot("31-tema-azul-persistente")
# escritorio azul: fondo azul en zona central-superior (sin ventanas encima lo más probable)
azules = count_color(img, (700, 430, 1010, 690), blue)
check("rearranque: escritorio AZUL (persistencia del tema)", azules > 4000, f"({azules} px)")
send_text("\n")
time.sleep(0.5)
send_text("quiensoy\n")
time.sleep(1)
S = serial_read()
img = shot("32-prompt-hostname")

# ============================ resumen ============================
monitor("quit\n"); time.sleep(0.8)
try: proc.wait(timeout=8)
except Exception: proc.kill()

fallos = [n for n, ok in results if not ok]
print(f"\n[RESUMEN] {len(results) - len(fallos)}/{len(results)} pruebas OK")
if fallos:
    print("[FALLOS]:")
    for f in fallos: print("  -", f)
sys.exit(0 if not fallos else 1)
