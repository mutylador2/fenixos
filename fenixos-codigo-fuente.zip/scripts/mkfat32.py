#!/usr/bin/env python3
"""FenixOS — mkfat32.py: crea una imagen de disco de datos FAT32 (16 MB)
formateada a mano (sin mkfs.vfat) con archivos de prueba:
  - LEEME.TXT  (8.3, contenido conocido)
  - NOTAS.TXT  (8.3, contenido conocido)
  - FICHA DE PROYECTO.TXT -> LFN real "informe-largo-fenix.txt"
  - CARPETA    (un subdirectorio vacío, solo para listar)
FenixOS debe leer los 8.3 y el LFN, escribir archivo nuevo y borrar.
Uso: python3 mkfat32.py [salida.img]
"""
import struct, sys

SECT = 512
out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/fenix-fat32.img"

# ---- geometría ----
total_sect = 32768            # 16 MB
spc = 4                       # sectores por cluster
reserved = 32
nfats = 2
fatsz = 64                    # sectores por FAT
rootclus = 2
clusters = (total_sect - reserved - nfats * fatsz) // spc
data_start = reserved + nfats * fatsz
bpc = spc * SECT

img = bytearray(total_sect * SECT)

def put(off, data):
    img[off:off + len(data)] = data

# ---- BPB ----
bpb = bytearray(SECT)
bpb[0] = 0xEB; bpb[1] = 0x3C; bpb[2] = 0x90
bpb[3:11] = b"FENIXOS "
struct.pack_into("<H", bpb, 11, SECT)
bpb[13] = spc
struct.pack_into("<H", bpb, 14, reserved)
bpb[16] = nfats
struct.pack_into("<H", bpb, 17, 0)          # root entries (FAT32=0)
struct.pack_into("<H", bpb, 19, 0)          # totsec16
bpb[21] = 0xF8                              # media
struct.pack_into("<H", bpb, 22, 0)          # fatsz16
struct.pack_into("<H", bpb, 24, 63)         # sectors/track
struct.pack_into("<H", bpb, 26, 16)         # heads
struct.pack_into("<I", bpb, 28, 0)          # hidden
struct.pack_into("<I", bpb, 32, total_sect)
struct.pack_into("<I", bpb, 36, fatsz)
struct.pack_into("<H", bpb, 40, 0x0000)     # extflags (FAT mirroring)
struct.pack_into("<H", bpb, 42, 0)          # fsver
struct.pack_into("<I", bpb, 44, rootclus)
struct.pack_into("<H", bpb, 48, 1)          # fsinfo sector
struct.pack_into("<H", bpb, 50, 6)          # backup boot sector
bpb[64] = 0x80                              # drive number
bpb[65] = 0
bpb[66] = 0x29                              # ext boot signature
struct.pack_into("<I", bpb, 67, 0x1F40CAFE)
bpb[71:82] = b"FENIXDATOS  "
bpb[82:90] = b"FAT32   "
bpb[510] = 0x55; bpb[511] = 0xAA
put(0, bpb)

# ---- FSInfo (sector 1) ----
fsi = bytearray(SECT)
fsi[0:4] = b"RRaA"
fsi[484:488] = b"rrAa"
struct.pack_into("<I", fsi, 488, clusters - 8)   # free count aprox
struct.pack_into("<I", fsi, 492, 0xFFFFFFFF)
fsi[510] = 0x55; fsi[511] = 0xAA
put(SECT, fsi)

# ---- backup boot (sector 6) ----
put(6 * SECT, bpb)

# ---- FATs ----
def fat_entry_byte(clus, val):
    for f in range(nfats):
        off = (reserved + f * fatsz) * SECT + clus * 4
        struct.pack_into("<I", img, off, val)

fat_entry_byte(0, 0x0FFFFFF8)
fat_entry_byte(1, 0x0FFFFFFF)

# cadena del directorio raíz: 1 cluster (cluster 2)
fat_entry_byte(2, 0x0FFFFFFF)
# datos: un cluster para cada archivo pequeño (3..7) + dir (8)
next_free = 3
def alloc_chain(nclusters):
    global next_free
    first = next_free
    for i in range(nclusters):
        if i == nclusters - 1:
            fat_entry_byte(next_free, 0x0FFFFFFF)
        else:
            fat_entry_byte(next_free, next_free + 1)
        next_free += 1
    return first

def cluster_off(clus):
    return data_start * SECT + (clus - 2) * bpc

def short_name(name):
    base, _, ext = name.partition(".")
    return base.upper().ljust(8)[:8] + ext.upper().ljust(3)[:3]

def lfn_checksum(short):
    s = 0
    for c in short:
        s = (((s & 1) << 7) + (s >> 1) + c) & 0xFF
    return s

def lfn_entries(longname, short11):
    # UTF-16LE, 13 chars por entrada
    chars = [ord(c) for c in longname] + [0x0000]
    while len(chars) % 13 != 0:
        chars.append(0xFFFF)
    n = len(chars) // 13
    cs = lfn_checksum(short11)
    ents = []
    for i in range(n, 0, -1):
        chunk = chars[(i - 1) * 13:i * 13]
        e = bytearray(32)
        e[0] = i | (0x40 if i == n else 0)
        e[11] = 0x0F
        e[12] = 0
        e[13] = cs
        # posiciones de los 13 UTF-16: 1,3,5,7,9 (5) + 14,16,18,20,22,24 (6) + 28,30 (2)
        pos = [1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30]
        for k, ch in enumerate(chunk):
            e[pos[k]] = ch & 0xFF
            e[pos[k] + 1] = (ch >> 8) & 0xFF
        ents.append(bytes(e))
    return ents

def add_file(name, data, lfn=None):
    d = data if isinstance(data, bytes) else data.encode()
    nclus = max(1, (len(d) + bpc - 1) // bpc)
    first = alloc_chain(nclus)
    put(cluster_off(first), d.ljust(bpc, b"\x00"))
    short11 = short_name(name)
    entries = b""
    if lfn:
        entries += b"".join(lfn_entries(lfn, short11.encode()))
    e = bytearray(32)
    e[0:11] = short11.encode()
    e[11] = 0x20                    # archivo
    # fecha/hora DOS: 2026-09-27 12:00:00
    struct.pack_into("<H", e, 14, (12 << 11) | (0 << 5) | 0)
    struct.pack_into("<H", e, 16, ((2026 - 1980) << 9) | (9 << 5) | 27)
    struct.pack_into("<H", e, 18, ((2026 - 1980) << 9) | (9 << 5) | 27)
    struct.pack_into("<H", e, 22, (12 << 11) | (0 << 5) | 0)
    struct.pack_into("<H", e, 24, ((2026 - 1980) << 9) | (9 << 5) | 27)
    e[26] = first & 0xFF
    e[27] = (first >> 8) & 0xFF
    e[20] = (first >> 16) & 0xFF
    e[21] = (first >> 24) & 0xFF
    struct.pack_into("<I", e, 28, len(d))
    entries += bytes(e)
    return entries

def add_dir(name):
    first = alloc_chain(1)
    # . y .. (raíz como padre)
    dot = bytearray(32); dot[0:11] = b".          "
    dot[11] = 0x10
    dotdot = bytearray(32); dotdot[0:11] = b"..         "
    dotdot[11] = 0x10
    put(cluster_off(first), bytes(dot) + bytes(dotdot) + b"\x00" * (bpc - 64))
    e = bytearray(32)
    e[0:11] = name.upper().ljust(11)[:11].encode()
    e[11] = 0x10
    struct.pack_into("<H", e, 16, ((2026 - 1980) << 9) | (9 << 5) | 27)
    struct.pack_into("<H", e, 24, ((2026 - 1980) << 9) | (9 << 5) | 27)
    e[26] = first & 0xFF
    e[27] = (first >> 8) & 0xFF
    struct.pack_into("<I", e, 28, 0)
    return bytes(e)

leeme = ("FenixOS 1.4 leendo FAT32 real.\n"
         "Este archivo lo puso el anfitrion (mkfat32.py) y FenixOS "
         "debe leerlo sin problemas: interoperabilidad con Windows/Linux.\n")
notas = "Nota 1: FAT32 funciona.\nNota 2: dual-boot amigable.\n"

root = b""
root += add_file("LEEME.TXT", leeme)
root += add_file("NOTAS.TXT", notas)
root += add_file("INFORME.TXT", "informe largo con nombre largo " * 8,
                 lfn="informe-largo-fenix.txt")
root += add_dir("CARPETA")
root += b"\x00" * (bpc - len(root))       # fin del directorio
put(cluster_off(2), root)

with open(out, "wb") as f:
    f.write(img)

print(f"FAT32 listo: {out} ({len(img)} bytes)")
print(f"  spc={spc} reserved={reserved} fatsz={fatsz} clusters={clusters}")
print(f"  root: LEEME.TXT ({len(leeme)}B), NOTAS.TXT ({len(notas)}B), "
      f"informe-largo-fenix.txt (LFN, 272B), CARPETA/")
