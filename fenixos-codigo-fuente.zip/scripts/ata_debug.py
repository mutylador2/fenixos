#!/usr/bin/env python3
"""Prueba un solo arranque img y vuelca el serial."""
import os, socket, subprocess, sys, time
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
QEMU = "/home/z/my-project/tools/qemu"
SERIAL = "/tmp/ata-debug.log"
cmd = [QEMU, "-drive", f"format=raw,file={BASE}/fenixos.img", "-m", "256",
       "-vga", "std", "-nic", "user,model=e1000", "-display", "none",
       "-serial", f"file:{SERIAL}"]
p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
time.sleep(16)
p.kill()
print(open(SERIAL).read())
