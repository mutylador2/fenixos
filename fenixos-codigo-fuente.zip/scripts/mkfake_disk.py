#!/usr/bin/env python3
"""FenixOS — mkfake_disk.py
Crea /tmp/fenix-otros-os.img: disco de 32MB que simula un equipo con
Windows y Linux ya instalados, para probar la CONVIVENCIA:
  part 1: tipo 0x07 (Windows NTFS), start 2048, 10 MB, ACTIVA,
          VBR = stub azul 'OTRO OS' (para el test de chainload)
  part 2: tipo 0x83 (Linux), start 22528, 10 MB
  resto:  espacio libre (donde el instalador creará la 0x63)
"""
import struct
import subprocess
import sys

OUT = "/tmp/fenix-otros-os.img"
MB = 32

ASM = r"""
BITS 16
ORG 0x7C00
start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    mov ax, 0x0600
    mov bh, 0x1F
    xor cx, cx
    mov dx, 0x184F
    int 0x10
    mov si, msg
.p:
    lodsb
    or al, al
    jz .h
    mov ah, 0x0E
    mov bx, 0x1F
    int 0x10
    jmp .p
.h:
    hlt
    jmp .h
msg db "OTRO OS (simulado) - chainload CORRECTO", 0
times 510-($-$$) db 0
dw 0xaa55
"""

def chs():
    return bytes([0xFE, 0xFF, 0xFF])

def main():
    disk = bytearray(MB * 1024 * 1024)
    # VBR simulado de Windows en la part 1
    open("/tmp/fake_vbr.asm", "w").write(ASM)
    r = subprocess.run(["/home/z/my-project/tools/root/usr/bin/nasm", "-f", "bin",
                        "/tmp/fake_vbr.asm", "-o", "/tmp/fake_vbr.bin"],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    vbr = open("/tmp/fake_vbr.bin", "rb").read()
    disk[2048*512: 2048*512+len(vbr)] = vbr
    # datos "de usuario" dentro de la partición 2 (Linux)
    disk[(22528+5)*512:(22528+5)*512+11] = b"DATOS-LINUX"
    # MBR con dos particiones (código no arrancable: hlt infinito)
    mbr = bytearray(512)
    mbr[0] = 0xF4                       # hlt
    struct.pack_into("<B", mbr, 446, 0x80)              # activa
    struct.pack_into("<B", mbr, 450, 0x07)              # NTFS
    struct.pack_into("<I", mbr, 454, 2048)
    struct.pack_into("<I", mbr, 458, 20480)
    struct.pack_into("<B", mbr, 462 + 4, 0x83)          # Linux (tipo en +4)
    struct.pack_into("<I", mbr, 470, 22528)
    struct.pack_into("<I", mbr, 474, 20480)
    mbr[510] = 0x55
    mbr[511] = 0xAA
    disk[0:512] = mbr
    with open(OUT, "wb") as f:
        f.write(disk)
    print(f"{OUT}: {MB} MB con Windows(0x07, activa) + Linux(0x83)")

if __name__ == "__main__":
    main()
