#!/usr/bin/env python3
"""dbg_tm.py — comprueba el tamaño de screendump durante el menú (modo texto)."""
import socket, subprocess, time, os
from PIL import Image

QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-tmdbg.sock"
DISK = "/tmp/fenix-otros-os.img"
if os.path.exists(MON): os.unlink(MON)

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait",
       "-drive", f"format=raw,file={DISK}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

ppm = "/tmp/tmdbg.ppm"
for i in range(24):
    try:
        mon.sendall(f"screendump {ppm}\n".encode())
        time.sleep(0.6)
        img = Image.open(ppm)
        print(f"t={i*0.9:4.1f}s  size={img.size}")
        img.close(); os.unlink(ppm)
    except Exception as e:
        print(f"t={i*0.9:4.1f}s  err: {e}")
        continue
    if i >= 6:
        img = None
        break
mon.close()
proc.terminate()
