#!/usr/bin/env python3
"""FenixOS — smoke.py: arranque rápido img/iso + escritorio visible."""
import os, socket, subprocess, sys, time
from PIL import Image

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
os.makedirs(OUT, exist_ok=True)

def boot(medium, shot, wait=14):
    mon = f"/tmp/fenix-smoke-{medium}.sock"
    if os.path.exists(mon): os.unlink(mon)
    cmd = [QEMU]
    if medium == "img":
        cmd += ["-drive", f"format=raw,file={BASE}/fenixos.img"]
    else:
        cmd += ["-cdrom", f"{BASE}/fenixos.iso", "-drive", "format=raw,file=/dev/null,if=none"]
    cmd += ["-m", "256", "-vga", "std", "-nic", "none", "-display", "none",
            "-monitor", f"unix:{mon},server,nowait",
            "-serial", f"file:{OUT}/serial-smoke.log"]
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    for _ in range(100):
        if os.path.exists(mon): break
        time.sleep(0.1)
    time.sleep(1.0)
    m = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM); m.connect(mon); m.settimeout(2)
    try: m.recv(4096)
    except socket.timeout: pass
    time.sleep(wait)
    m.sendall(b"screendump " + shot.encode() + b"\n")
    time.sleep(1.2)
    m.sendall(b"quit\n"); time.sleep(0.6)
    try: m.close()
    except Exception: pass
    p.wait(timeout=10)
    Image.open(shot).convert("RGB").save(shot.replace(".ppm", ".png"))
    os.unlink(shot)
    # verificación de píxeles: taskbar clara en la parte baja + ventanas
    img = Image.open(shot.replace(".ppm", ".png"))
    w, h = img.size
    px = img.load()
    colores = set()
    for x in range(0, w, 7):
        for y in range(h-30, h):
            colores.add(px[x, y])
    ok = len(colores) > 5
    print(f"[smoke:{medium}] escritorio={'OK' if ok else 'FALLO'} ({shot.replace('.ppm','')})")
    return ok

ok1 = boot("img", "/tmp/smoke-img.ppm")
ok2 = boot("iso", "/tmp/smoke-iso.ppm")
sys.exit(0 if (ok1 and ok2) else 1)
