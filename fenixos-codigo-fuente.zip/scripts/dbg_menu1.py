#!/usr/bin/env python3
"""dbg_menu5.py — envía '5' al menú REAL de stage2 varias veces y comprueba
si la pantalla cambia (la opción 5 muestra la pantalla de información)."""
import socket, subprocess, time, os
from PIL import Image

QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-key1.sock"
DISK = "/tmp/fenix-otros-os.img"
if os.path.exists(MON): os.unlink(MON)

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait",
       "-drive", f"format=raw,file={DISK}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def bright_size():
    ppm = "/tmp/key1.ppm"
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    try:
        img = Image.open(ppm).convert("L"); s = img.size
        b = sum(1 for v in img.getdata() if v > 160)
        img.close(); os.unlink(ppm)
        return s, b
    except Exception:
        return None, 0

for _ in range(30):
    s, b = bright_size()
    if s == (720, 400) and b > 12000:
        print("menú arriba")
        break
    time.sleep(0.6)

# congelar la cuenta atrás imposible; enviar '5' cada 2.5s y comparar brillo
prev = b
for i in range(8):
    mon.sendall(b"sendkey 1\n")
    time.sleep(2.5)
    s, b = bright_size()
    print(f"intento {i+1}: size={s} bright={b} (antes {prev}) {'CAMBIO' if abs(b-prev)>800 else ''}")
    prev = b

mon.sendall(b"sendkey 1\n")
time.sleep(1.0)
ppm = "/tmp/key1-final.ppm"
mon.sendall(f"screendump {ppm}\n".encode())
time.sleep(0.6)
img = Image.open(ppm).convert("RGB")
img.save("/tmp/key1-final.png"); os.unlink(ppm)
print("captura /tmp/key1-final.png")
mon.close()
proc.terminate()
