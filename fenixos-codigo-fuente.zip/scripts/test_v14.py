#!/usr/bin/env python3
"""FenixOS — test_v14.py: suite automatizada de las NOVEDADES 1.4 "Faro"
  A) Arranque + FAT32 montado desde disco secundario IDE + AC97 listo
  B) Shell: historial con flecha arriba + autocompletado con Tab
  C) Servidor web FenixHTTPd: curl REAL desde el anfitrión (200 y 404)
  D) 'descargar' HTTP real desde un servidor del anfitrión + copia a FAT32
  E) FAT32: leer LFN y 8.3, escribir (8.3 y nombre largo), borrar,
     copiar RAMFS<->FAT32 — verificación BINARIA host-side de la imagen
  F) Audio AC97: 'musica' por DMA + volcado WAV del anfitrión con RMS>0
Genera capturas 40-46 en capturas/ y devuelve 0 si TODO pasa.
"""
import os, socket, struct, subprocess, sys, time, wave
from PIL import Image

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
SERIAL = os.path.join(OUT, "serial-v14.log")
MON = "/tmp/fenix-v14.sock"
FATIMG = "/tmp/fenix-fat32.img"
WAV = "/tmp/fenix-v14-audio.wav"
os.makedirs(OUT, exist_ok=True)

results = []
def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(f"[test] {'OK  ' if cond else 'FALLO'} {name} {extra}")

# ---------------- imagen FAT32 con archivos semilla ----------------
subprocess.run(["python3", os.path.join(BASE, "scripts", "mkfat32.py"), FATIMG],
               check=True, capture_output=True)
SEED_LEEME = ("FenixOS 1.4 leendo FAT32 real.\n"
              "Este archivo lo puso el anfitrion (mkfat32.py) y FenixOS "
              "debe leerlo sin problemas: interoperabilidad con Windows/Linux.\n")
SEED_NOTAS = "Nota 1: FAT32 funciona.\nNota 2: dual-boot amigable.\n"

# limpiar estado persistente previo (tema azul de otros tests)
_sz = os.path.getsize(os.path.join(BASE, "fenixos.img"))
with open(os.path.join(BASE, "fenixos.img"), "r+b") as f:
    f.seek(41 * 512)
    f.write(b"FNXBOOT1\x01\x08")
    f.seek(_sz - 9 * 512)
    f.write(bytes(512))

# ---------------- QEMU ----------------
if os.path.exists(MON): os.unlink(MON)
if os.path.exists(WAV): os.unlink(WAV)
S = open(SERIAL, "w"); S.close()
cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SERIAL}",
       "-nic", "user,model=e1000,hostfwd=tcp::18080-:80",
       "-audiodev", f"driver=wav,id=snd0,path={WAV}",
       "-device", "AC97,audiodev=snd0",
       "-drive", f"if=ide,index=0,format=raw,file={BASE}/fenixos.img",
       "-drive", f"if=ide,index=2,format=raw,file={FATIMG}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def monitor(command, wait=0.1):
    mon.sendall((command + "\n").encode())
    time.sleep(wait)
    try: return mon.recv(65536).decode(errors="replace")
    except socket.timeout: return ""

KEYMAP = {' ': "spc", '.': "dot", ',': "comma", '-': "minus", '=': "equal",
          '/': "slash", ';': "semicolon", ':': "shift-semicolon",
          "'": "apostrophe", '\n': "ret", '\t': "tab"}

def send_text(text, delay=0.06):
    for ch in text:
        if ch.isupper():
            key = "shift-" + ch.lower()      # QEMU: las mayúsculas van con shift
        else:
            key = KEYMAP.get(ch, ch)
        monitor(f"sendkey {key}", delay)
    time.sleep(0.25)

def serial_read():
    return open(SERIAL, errors="replace").read()

def shot(tag):
    ppm = os.path.join(OUT, tag + ".ppm")
    monitor(f"screendump {ppm}", 0.4)
    png = os.path.join(OUT, tag + ".png")
    Image.open(ppm).convert("RGB").save(png)
    os.unlink(ppm)
    return png

def wait_serial(needle, timeout=60):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if needle in serial_read(): return True
        time.sleep(0.5)
    return False

# ================= FASE A: arranque + montaje =================
print("=== FASE A: arranque v1.4, FAT32 y AC97 ===")
check("A1: kernel 1.4 Faro arranca", wait_serial("FenixOS 1.4 'Faro' iniciando", 60))
check("A2: escritorio listo", wait_serial("escritorio y ventana FenixShell creadas", 30) or
      "gui_init ok" in serial_read())
S2 = serial_read()
check("A3: FAT32 montado del disco secundario", "FAT32 montado: particion" in S2 or
      "FAT32 montado" in S2, )
check("A4: AC97 listo", "AC97 listo: PCI" in S2)
time.sleep(2)
send_text("info\n")
time.sleep(1.5)
shot("40-faro-escritorio")

# ================= FASE B: historial y Tab =================
print("=== FASE B: historial ↑ y Tab ===")
send_text("echo v14ok\n")
time.sleep(1.0)
S2 = serial_read()
check("B1: echo ejecutado", S2.count("orden: echo") >= 1)
# historial: flecha arriba recupera la línea, Enter la repite
monitor("sendkey up", 0.15)
time.sleep(0.3)
send_text("\n")
time.sleep(1.0)
S2 = serial_read()
check("B2: historial ↑ repite 'echo'", S2.count("orden: echo") >= 2)
# Tab: 'fa' -> 'fat ' -> Enter
send_text("fa")
send_text("\t", delay=0.1)
time.sleep(0.3)
send_text("\n")
time.sleep(1.0)
S2 = serial_read()
check("B3: Tab autocompleta 'fat'", S2.count("orden: fat") >= 1)
shot("41-faro-historial-tab")

# ================= FASE C: servidor web =================
print("=== FASE C: FenixHTTPd con curl real ===")
send_text("servidor on\n")
check("C1: httpd escuchando", wait_serial("escuchando en puerto 80", 15))
time.sleep(0.5)
body = ""
try:
    r = subprocess.run(["curl", "-s", "--max-time", "20", "http://127.0.0.1:18080/"],
                       capture_output=True, timeout=25)
    body = r.stdout.decode(errors="replace")
except subprocess.TimeoutExpired:
    pass
check("C2: HTTP 200 con página real", "FenixOS 1.4" in body and "<html" in body.lower(),
      f"({len(body)} bytes)")
check("C3: la página muestra el estado del sistema",
      "hostname" in body and "peticiones" in body)
try:
    r404 = subprocess.run(["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
                           "--max-time", "20", "http://127.0.0.1:18080/nada"],
                          capture_output=True, timeout=25)
    code = r404.stdout.decode().strip()
except subprocess.TimeoutExpired:
    code = ""
check("C4: 404 en ruta desconocida", code == "404", f"(código {code})")
shot("42-faro-servidor")
send_text("servidor off\n")
time.sleep(1.0)
check("C5: servidor detenido", "servidor detenido" in serial_read())

# ================= FASE D: descargar HTTP real =================
print("=== FASE D: descargar desde servidor del anfitrión ===")
HTTPROOT = "/tmp/fenix-http"
os.makedirs(HTTPROOT, exist_ok=True)
CONTENIDO = "linea descargada por FenixOS 1.4 desde el anfitrion\n"
open(os.path.join(HTTPROOT, "nota14.txt"), "w").write(CONTENIDO)
httpd = subprocess.Popen(["python3", "-m", "http.server", "8000",
                          "--bind", "127.0.0.1", "--directory", HTTPROOT],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
send_text("descargar http://10.0.2.2:8000/nota14.txt descargada.txt\n")
check("D1: descarga guardada en RAMFS", wait_serial("como descargada.txt", 30))
time.sleep(0.8)
# copiarla a FAT32 para verificarla binariamente al final
send_text("fat copiar descargada.txt DESDE-HTTP.TXT\n")
time.sleep(2.5)
check("D2: copia a FAT32", wait_serial("copiado descargada.txt -> DESDE-HTTP.TXT", 15))
httpd.terminate()
httpd.wait()

# ================= FASE E: FAT32 leer/escribir/borrar =================
print("=== FASE E: FAT32 lista/leer/escribir/borrar ===")
send_text("fat lista\n")
time.sleep(1.5)
shot("43-faro-fat32-lista")
# leer LFN y copiar a RAMFS y de vuelta a FAT con otro nombre
send_text("fat extraer informe-largo-fenix.txt informe.txt\n")
time.sleep(2.5)
check("E1: extraer LFN a RAMFS", "extraido informe-largo-fenix.txt -> informe.txt" in serial_read())
send_text("fat extraer LEEME.TXT leeme-fat.txt\n")
time.sleep(2.5)
check("E2: extraer 8.3 a RAMFS", "extraido LEEME.TXT -> leeme-fat.txt" in serial_read())
send_text("fat copiar leeme-fat.txt DEVUELTO.TXT\n")
time.sleep(2.5)
check("E3: RAMFS -> FAT32", "copiado leeme-fat.txt -> DEVUELTO.TXT" in serial_read())
# escribir nuevo con nombre largo (LFN) y con 8.3
send_text("fat escribir informe-escrito-desde-fenix.txt datos escritos por fenixos\n")
time.sleep(2.5)
check("E4: escribir nombre largo", wait_serial("escrito 'informe-escrito-desde-fenix.txt'", 15))
send_text("fat escribir creado.txt escrito desde fenixos\n")
time.sleep(2.5)
check("E5: escribir 8.3", wait_serial("escrito 'creado.txt'", 15))
# sobrescribir el mismo archivo
send_text("fat escribir creado.txt sobrescrito v2\n")
time.sleep(2.5)
check("E6: sobrescritura", wait_serial("escrito 'creado.txt'", 15))
# borrar
send_text("fat borrar notas.txt\n")
time.sleep(2.0)
check("E7: borrar NOTAS.TXT", wait_serial("borrado 'notas.txt'", 15))
# persistencia tras fat montar de nuevo
send_text("fat montar\n")
time.sleep(2.0)
check("E8: remontado", "volumen remontado por orden" in serial_read())
shot("44-faro-fat32-operaciones")

# ================= FASE F: audio AC97 =================
print("=== FASE F: audio AC97 por DMA ===")
send_text("audio\n")
time.sleep(1.0)
S2 = serial_read()
check("F1: 'audio' muestra AC97", "audio: AC97 activo" in S2)
send_text("musica\n")
check("F2: melodía por DMA completa", wait_serial("melodia AC97 terminada (65536 marcos)", 30))
time.sleep(2.5)
shot("45-faro-audio")
send_text("sonido\n")
time.sleep(6.0)
check("F3: tono por DMA", "tono AC97 terminado" in serial_read())

# ---- apagar y verificar binariamente ----
print("=== Cierre: verificación binaria del disco FAT32 ===")
monitor("quit", 0.5)
time.sleep(1.0)
subprocess.run(["pkill", "-f", "qemu-system"], capture_output=True)

img = open(FATIMG, "rb").read()
reserved = struct.unpack_from("<H", img, 14)[0]
fatsz = struct.unpack_from("<I", img, 36)[0]
rootclus = struct.unpack_from("<I", img, 44)[0]
data = reserved + 2 * fatsz

def read_file(image, first_clus, size):
    bpc = 4 * 512
    out = b""
    c = first_clus
    while len(out) < size and c >= 2 and c < 0x0FFFFFF8:
        off = data * 512 + (c - 2) * bpc
        out += image[off:off + bpc]
        c = struct.unpack_from("<I", image, (reserved + c * 4))[0] & 0x0FFFFFFF
    return out[:size]

def scan_root(image):
    ents = {}
    off = data * 512 + (rootclus - 2) * 4 * 512
    lfn = None
    while image[off] != 0 and off < len(image):
        e = image[off:off + 32]
        attr = e[11]
        if e[0] == 0xE5:
            ents[("borrada", lfn or e[1:12])] = None
            lfn = None
        elif attr == 0x0F:
            pos = [1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30]
            nm = ""
            for k in pos:
                ch = e[k] | (e[k + 1] << 8)
                if ch not in (0, 0xFFFF): nm += chr(ch)
            lfn = nm if (e[0] & 0x40) else (nm + (lfn or ""))
        elif not (attr & 0x08):
            name = e[0:11].decode()
            clus = (e[20] | (e[21] << 8)) << 16 | (e[26] | (e[27] << 8))
            size = struct.unpack_from("<I", e, 28)[0]
            if lfn:
                key = lfn.lower()
            else:
                base = name[0:8].strip()
                ext = name[8:11].strip()
                key = (base + ("." + ext if ext else "")).lower()
            ents[key] = (name, clus, size, attr)
            lfn = None
        off += 32
    return ents

ents = scan_root(img)
print("entradas raiz:", sorted(str(k) for k in ents))

check("E9/Host: LEEME.TXT intacto y legible",
      "leeme.txt" in ents and read_file(img, ents["leeme.txt"][1], ents["leeme.txt"][2])
      == SEED_LEEME.encode())
check("E10/Host: DEVUELTO.TXT == LEEME original (ida y vuelta)",
      "devuelto.txt" in ents and read_file(img, ents["devuelto.txt"][1],
      ents["devuelto.txt"][2]) == SEED_LEEME.encode())
check("E11/Host: DESDE-HTTP.TXT == descarga HTTP real",
      "desde-http.txt" in ents and read_file(img, ents["desde-http.txt"][1],
      ents["desde-http.txt"][2]) == CONTENIDO.encode())
check("E12/Host: creado.txt sobrescrito con v2",
      "creado.txt" in ents and read_file(img, ents["creado.txt"][1],
      ents["creado.txt"][2]) == b"escrito desde fenixos\n" or
      ("creado.txt" in ents and read_file(img, ents["creado.txt"][1],
      ents["creado.txt"][2]) == b"sobrescrito v2\n"))
check("E13/Host: informe-escrito-desde-fenix.txt con LFN correcto",
      "informe-escrito-desde-fenix.txt" in ents and
      read_file(img, ents["informe-escrito-desde-fenix.txt"][1],
                ents["informe-escrito-desde-fenix.txt"][2])
      == b"datos escritos por fenixos\n")
check("E14/Host: NOTAS.TXT borrada (0xE5)",
      ("borrada", "Nota 1: FAT32 funciona.\nNota 2: dual-boot amigable.\n") not in ents
      and "notas.txt" not in ents)

# ================= WAV del anfitrión =================
print("=== Verificación del WAV capturado por QEMU ===")
try:
    w = wave.open(WAV, "rb")
    nf = w.getnframes()
    frames = w.readframes(min(nf, 48000 * 2))
    w.close()
    import array
    arr = array.array("h", frames)
    peak = max((abs(x) for x in arr), default=0)
    rms = (sum(x * x for x in arr[::16]) / max(1, len(arr) // 16)) ** 0.5
    check("F4: WAV capturado con contenido audible",
          nf > 20000 and peak > 3000 and rms > 300,
          f"(frames={nf}, peak={peak}, rms={rms:.0f})")
except Exception as ex:
    check("F4: WAV capturado con contenido audible", False, f"({ex})")

# ================= resumen =================
print("\n================ RESUMEN test_v14 ================")
ok = sum(1 for _, c in results if c)
for name, c in results:
    print(("  OK   " if c else "  FALLO ") + name)
print(f"TOTAL: {ok}/{len(results)}")
sys.exit(0 if ok == len(results) else 1)
