#!/usr/bin/env python3
"""FenixOS — dbg_partboot.py: construye un disco particionado idéntico al
del instalador (stage1+part0x63+stage2+kernel) y lo arranca para aislar
el fallo del arranque particionado."""
import socket, struct, subprocess, sys, time, os

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
IMG = "/tmp/fenix-part-test.img"

s1 = open(f"{BASE}/boot/stage1.bin", "rb").read()
s2 = open(f"{BASE}/boot/stage2.bin", "rb").read()
k = open(f"{BASE}/kernel.inst.bin", "rb").read()
assert len(s1) == 512 and len(s2) == 40 * 512

DISK_MB = 32
disk = bytearray(DISK_MB * 1024 * 1024)
disk[0:512] = s1
# entrada 0x63
struct.pack_into("<B", disk, 446 + 32 + 4, 0x63)
struct.pack_into("<I", disk, 446 + 32 + 8, 43008)
struct.pack_into("<I", disk, 446 + 32 + 12, 22528)
disk[510:512] = b"\x55\xaa"
# stage2 en base+1
base = 43008
disk[(base + 1) * 512:(base + 1) * 512 + len(s2)] = s2
# bootcfg en base+41
disk[(base + 41) * 512:(base + 41) * 512 + 10] = b"FNXBOOT1\x01\x08"
# kernel en base+128
disk[(base + 128) * 512:(base + 128) * 512 + len(k)] = k
open(IMG, "wb").write(disk)
print("imagen particionada de prueba creada")

MON = "/tmp/fenix-pb.sock"
SER = "/tmp/fenix-pb.log"
if os.path.exists(MON): os.unlink(MON)
open(SER, "w").close()
cmd = [QEMU, "-m", "256", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SER}",
       "-drive", f"format=raw,file={IMG}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass
time.sleep(6)
mon.sendall(b"screendump /tmp/pb1.ppm\n"); time.sleep(0.6)
time.sleep(14)
mon.sendall(b"screendump /tmp/pb2.ppm\n"); time.sleep(0.6)
mon.close()
proc.terminate(); proc.wait(timeout=10)

print("--- serial ---")
print(open(SER, errors="replace").read()[:600])
from PIL import Image
for t in ("pb1", "pb2"):
    Image.open(f"/tmp/{t}.ppm").convert("RGB").save(f"/tmp/{t}.png")
print("capturas /tmp/pb1.png /tmp/pb2.png")
