#!/usr/bin/env python3
"""dbg_pe2.py — mide el tiempo real key->Titan->GUI con polling del serial."""
import socket, subprocess, time, os
from PIL import Image

QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-pe2.sock"
SER = "/tmp/fenix-pe2.log"
DISK = "/tmp/fenix-otros-os.img"
if os.path.exists(MON): os.unlink(MON)
open(SER, "w").close()

T0 = time.time()
def ts(): return f"{time.time()-T0:6.1f}s"

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SER}",
       "-drive", f"format=raw,file={DISK}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def menu_listo():
    ppm = "/tmp/pe3.ppm"
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    try:
        img = Image.open(ppm).convert("L"); s = img.size
        bright = sum(1 for v in img.getdata() if v > 160)
        img.close(); os.unlink(ppm)
        return s == (720, 400) and bright > 12000
    except Exception:
        return False

for _ in range(30):
    if menu_listo(): break
    time.sleep(0.6)
print(f"{ts()} menú arriba")
time.sleep(1.0)
print(f"{ts()} sendkey 1")
mon.sendall(b"sendkey 1\n")
time.sleep(0.5)

t_titan = t_gui = None
for i in range(90):
    ser = open(SER, errors="replace").read()
    if t_titan is None and "FenixOS 1.3" in ser:
        t_titan = time.time() - T0
        print(f"{ts()} ¡Titan en serial!")
    ppm = "/tmp/pe3.ppm"
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    try:
        img = Image.open(ppm); s = img.size; img.close(); os.unlink(ppm)
        if s == (1024, 768):
            t_gui = time.time() - T0
            print(f"{ts()} GUI 1024x768")
            break
    except Exception:
        pass
print(f"RESULTADO: key->Titan={t_titan}s  key->GUI={t_gui}s")
mon.close()
proc.terminate()
