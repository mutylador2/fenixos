#!/usr/bin/env python3
"""FenixOS — test_v13.py: suite automatizada de las NOVEDADES 1.3
  A) AHCI/SATA: dos discos en controladora AHCI, 'disco' con backend AHCI
  B) 'sistema' (información del sistema), 'useradd' + persistencia,
     'arranque' (config del menú multiboot persistente)
  C) INSTALADOR GRÁFICO por clicks: instalar FenixOS en el disco 2
     (simulador con Windows+Linux) en modo 'Junto a otros OS'
  D) Verificación binaria del disco destino: particiones ajenas
     intactas, nueva partición 0x63, stage2/bootcfg/kernel/config
  E) ARRANQUE del disco instalado (particionado) + chainload de
     Windows simulado (pantalla azul) desde el menú multiboot
  F) Arranque automático en MODO SEGURO (opción 2 persistida) con
     resolución 800x600 + persistencia de usuario (login pepe)
Genera capturas 32-36 en capturas/ y devuelve 0 si TODO pasa.
"""
import os, socket, subprocess, sys, time, struct
from PIL import Image

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
SERIAL = os.path.join(OUT, "serial-v13.log")
MON = "/tmp/fenix-v13.sock"
os.makedirs(OUT, exist_ok=True)

results = []
def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(f"[test] {'OK  ' if cond else 'FALLO'} {name} {extra}")

# ============================ disco simulado ============================
subprocess.run(["python3", os.path.join(BASE, "scripts", "mkfake_disk.py")],
               check=True, capture_output=True)
FAKE = "/tmp/fenix-otros-os.img"
KERNS = os.path.getsize(os.path.join(BASE, "kernel.inst.bin"))
KSECT = (KERNS + 511) // 512

# resetear el sector de configuración del gestor de arranque y el de
# usuarios (los tests anteriores pueden haber dejado estado persistente)
import os as _os
_sz = _os.path.getsize(_os.path.join(BASE, "fenixos.img"))
with open(_os.path.join(BASE, "fenixos.img"), "r+b") as f:
    f.seek(41 * 512)
    f.write(b"FNXBOOT1\x01\x08")          # menú: opción 1, 8 s
    f.seek(_sz - 9 * 512)                  # sector de cuentas (config-1)
    f.write(bytes(512))

# ============================ FASE A: AHCI ==============================
if os.path.exists(MON): os.unlink(MON)
S = open(SERIAL, "w")   # truncar
S.close()
cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SERIAL}",
       "-nic", "user,model=e1000",
       "-device", "ich9-ahci,id=ahci",
       "-drive", f"if=none,id=d0,format=raw,file={BASE}/fenixos.img",
       "-device", "ide-hd,drive=d0,bus=ahci.0",
       "-drive", f"if=none,id=d1,format=raw,file={FAKE}",
       "-device", "ide-hd,drive=d1,bus=ahci.1"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def monitor(command, wait=0.1):
    mon.sendall((command + "\n").encode())
    time.sleep(wait)
    try: return mon.recv(65536).decode(errors="replace")
    except socket.timeout: return ""

KEYMAP = {' ': "spc", '.': "dot", ',': "comma", '-': "minus", '=': "equal",
          '/': "slash", ';': "semicolon", ':': "shift-semicolon",
          "'": "apostrophe", '\n': "ret"}
CUR = (512, 384)

def send_text(text):
    for ch in text:
        key = KEYMAP.get(ch, ch)
        monitor(f"sendkey {key}", 0.06)
    time.sleep(0.3)

def mouse_to(x, y, wait=0.15):
    """mover en pasos <=120 unidades con pausas de 0.15s (sincronía del
    driver PS/2 del kernel: a 0.06s pierde la sincronía de paquetes)"""
    global CUR
    while abs(x - CUR[0]) > 120 or abs(y - CUR[1]) > 120:
        sx = max(-120, min(120, x - CUR[0]))
        sy = max(-120, min(120, y - CUR[1]))
        monitor(f"mouse_move {sx} {sy}", 0.15)
        CUR = (CUR[0] + sx, CUR[1] + sy)
    dx, dy = x - CUR[0], y - CUR[1]
    if dx or dy:
        monitor(f"mouse_move {dx} {dy}", wait)
    CUR = (x, y)

def click(wait=0.5):
    monitor("mouse_button 1", wait)
    monitor("mouse_button 0", 0.15)

def shot(tag):
    ppm = os.path.join(OUT, tag + ".ppm")
    monitor(f"screendump {ppm}", 0.4)
    img = Image.open(ppm).convert("RGB")
    img.save(os.path.join(OUT, tag + ".png"))
    os.unlink(ppm)
    return img

def make_shot(monx):
    def s(tag):
        ppm = os.path.join(OUT, tag + ".ppm")
        monx.sendall(f"screendump {ppm}\n".encode())
        time.sleep(0.5)
        img = Image.open(ppm).convert("RGB")
        img.save(os.path.join(OUT, tag + ".png"))
        os.unlink(ppm)
        return img
    return s

def count_color(img, box, pred):
    px = img.load()
    n = 0
    for y in range(box[1], box[3]):
        for x in range(box[0], box[2]):
            if pred(*px[x, y]): n += 1
    return n

serial_read = lambda: open(SERIAL, errors="replace").read()

print("[fase A] arranque con AHCI (menú multiboot 8s + kernel)...")
time.sleep(27)
S = serial_read()
check("A: kernel 1.3 Titan", "FenixOS 1.4 'Faro'" in S)
check("A: HBA AHCI detectado", "HBA AHCI en 0x" in S)
check("A: SATA 0 presente", "SATA 0: 'QEMU HARDDISK'" in S)
check("A: SATA 1 presente", "SATA 1: 'QEMU HARDDISK'" in S)
check("A: backend AHCI", "backend de bloques: AHCI (SATA)" in S)
check("A: sesion admin", "sesion iniciada como 'admin'" in S)

send_text("disco\n")
time.sleep(0.8)
S = serial_read()
check("A: 'disco' ejecutado", "orden: disco" in S)
check("A: backend AHCI ya confirmado en arranque", "backend de bloques: AHCI (SATA)" in S)
img = shot("32-disco-ahci")

send_text("sistema\n")
time.sleep(1.2)
S = serial_read()
check("B: 'sistema' ejecutado", "orden: sistema" in S)
check("B: informe generado", "informacion del sistema generada" in S)
img = shot("33-sistema-info")

# recuperar el foco de FenixShell (el visor de 'sistema' lo tiene):
# click en la franja izquierda de la ventana shell (no tapada por el visor)
mouse_to(100, 300); click(0.4)

time.sleep(0.5)
# useradd con reintento (el foco tras 'sistema' puede tardar en volver)
for intento in range(3):
    send_text("useradd pepe 4321 1\n")
    time.sleep(0.8)
    if "cuenta creada: 'pepe'" in serial_read():
        break
    mouse_to(100, 300); click(0.4)      # reintentar foco de FenixShell
S = serial_read()
check("B: useradd pepe", "cuenta creada: 'pepe'" in S)
check("B: cuentas guardadas en disco", "cuentas guardadas en disco" in S)

send_text("arranque 2 4\n")
time.sleep(0.8)
S = serial_read()
check("B: arranque opcion 2, 4s", "config de arranque escrita: opcion 2" in S)

# ==================== FASE B: instalador gráfico ====================
print("[fase B] instalador gráfico sobre el disco 2 (Windows/Linux)...")
send_text("instalador\n")
time.sleep(1.2)
img = shot("34a-instalador-discos")
S = serial_read()
check("C: instalador abierto", "orden: instalador" in S)

# ventana instalador: x=232 y=44 w=600 h=420
# fila del disco 2 (SATA 1): y = 44+40+2*17 = 118 (click directo, sin click previo)
mouse_to(400, 122); click(0.8)
img = shot("34b-instalador-particiones")
# botón 'Junto a otros OS' (384..554, y 424..450)
mouse_to(460, 437); click(0.6)
img = shot("34c-instalador-confirmar")
# botón 'Confirmar instalacion' (244..444)
mouse_to(340, 437); click(0.6)
time.sleep(6)            # escrituras AHCI
img = shot("34d-instalador-listo")
S = serial_read()
check("C: instalación completada", "instalacion completada" in S)

monitor("quit", 0.5)
try:
    proc.wait(timeout=20)
except Exception:
    pass
subprocess.run(["pkill", "-f", "qemu-system"], capture_output=True)
time.sleep(2)      # asegurar liberación del lock de la imagen

# ==================== FASE D: verificación binaria ====================
print("[fase D] verificación binaria del disco instalado...")
d = open(FAKE, "rb").read()
mbr_ok = d[510] == 0x55 and d[511] == 0xAA
p1 = d[446:462]; p2 = d[462:478]; p3 = d[478:494]
t1, t2, t3 = p1[4], p2[4], p3[4]
s1 = struct.unpack_from("<I", p1, 8)[0]; z1 = struct.unpack_from("<I", p1, 12)[0]
s2 = struct.unpack_from("<I", p2, 8)[0]; z2 = struct.unpack_from("<I", p2, 12)[0]
s3 = struct.unpack_from("<I", p3, 8)[0]; z3 = struct.unpack_from("<I", p3, 12)[0]
check("D: MBR firma", mbr_ok)
check("D: particion Windows 0x07 intacta", t1 == 0x07 and s1 == 2048 and z1 == 20480,
      f"tipo={t1:02x} start={s1} n={z1}")
check("D: particion Linux 0x83 intacta", t2 == 0x83 and s2 == 22528 and z2 == 20480,
      f"tipo={t2:02x} start={s2} n={z2}")
check("D: nueva particion FenixOS 0x63", t3 == 0x63 and z3 > 0,
      f"tipo={t3:02x} start={s3} n={z3}")
check("D: datos de la part. 1 preservados", d[2048*512:(2048*512)+8] != bytes(8)
      and d[2048*512+510:2048*512+512] == b"\x55\xaa")
check("D: datos de la part. 2 preservados", d[(22528+5)*512:(22528+5)*512+11] == b"DATOS-LINUX")
# contenido de la partición FenixOS
base = s3
s2off = (base + 1) * 512
check("D: stage2 instalado", d[s2off:s2off+20].startswith(b"\xfc1\xc0\x8e\xd8"))
bc = d[(base + 41) * 512:(base + 41) * 512 + 10]
check("D: sector FNXBOOT1", bc[:8] == b"FNXBOOT1" and bc[8] == 1 and bc[9] == 8, str(bc))
koff = (base + 128) * 512
check("D: kernel instalado", d[koff] == 0xFA and d[koff + 1] == 0xFC,
      f"primeros bytes={d[koff:koff+4].hex()}")
cfg = d[(base + z3 - 8) * 512:(base + z3 - 8) * 512 + 8]
check("D: config FNXCFG01", cfg == b"FNXCFG01", str(cfg))

# ==================== FASE E: arranque particionado + chainload ====================
# Dar 30 s de cuenta atrás al menú del disco instalado: elimina la
# carrera entre el POST de SeaBIOS (que se come teclas) y el sendkey '3'.
with open(FAKE, "r+b") as f:
    f.seek((43008 + 41) * 512)
    f.write(b"FNXBOOT1\x01\x1e")          # opción 1, 30 s
print("[fase E] arranque desde el disco particionado (convivencia)...")
MON2 = MON + ".2"
if os.path.exists(MON2): os.unlink(MON2)
SERIAL2 = os.path.join(OUT, "serial-v13-part.log")
cmd2 = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
        "-monitor", f"unix:{MON2},server,nowait", "-serial", f"file:{SERIAL2}",
        "-drive", f"format=raw,file={FAKE}"]
proc2 = subprocess.Popen(cmd2, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON2): break
    time.sleep(0.1)
mon2 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon2.connect(MON2); mon2.settimeout(2.0)
try: mon2.recv(4096)
except socket.timeout: pass

def monitor2(command, wait=0.1):
    mon2.sendall((command + "\n").encode())
    time.sleep(wait)
    try: return mon2.recv(65536).decode(errors="replace")
    except socket.timeout: return ""

def send_text2(text):
    for ch in text:
        monitor2(f"sendkey {KEYMAP.get(ch, ch)}", 0.06)
    time.sleep(0.3)

shot2 = make_shot(mon2)

def wait_text_mode(monx, timeout=45):
    """espera hasta que el screendump sea modo texto 720x400 (menú del
    gestor de arranque). Evita la carrera con el POST de SeaBIOS, que se
    come las teclas enviadas antes de que el menú esté listo."""
    ppm = "/tmp/fenix-tm.ppm"
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            monx.sendall(f"screendump {ppm}\n".encode())
            time.sleep(0.5)
            img = Image.open(ppm); size = img.size; img.close()
            os.unlink(ppm)
        except Exception:
            time.sleep(0.3); continue
        if size == (720, 400):
            time.sleep(3.5)      # margen: ventana del menú de SeaBIOS (2.5 s)
            return True
    return False

wait_text_mode(mon2)             # menú del disco particionado
monitor2("sendkey 1", 0.5)       # arrancar FenixOS ya (no esperar los 30 s)
time.sleep(17)                   # kernel -> escritorio
S2 = open(SERIAL2, errors="replace").read()
check("E: kernel 1.3 arranca desde partición 0x63", "FenixOS 1.4 'Faro'" in S2)
check("E: zona de instalación = partición", "particion 0x63" in S2 and "base 4" in S2,
      "(LBA 43008)")
img = shot2("35a-escritorio-particion")

# chainload: reboot -> menú (30 s) -> 3 -> 1 (partición Windows simulada)
send_text2("reboot\n")
wait_text_mode(mon2)             # menú de nuevo
time.sleep(1.0)
monitor2("sendkey 3", 0.5)
time.sleep(1.2)
ppm = os.path.join(OUT, "35b-menu-particiones.ppm")
monitor2(f"screendump {ppm}", 0.4)
img = Image.open(ppm).convert("RGB"); img.save(os.path.join(OUT, "35b-menu-particiones.png"))
os.unlink(ppm)
monitor2("sendkey 1", 0.4)
time.sleep(2.5)
ppm = os.path.join(OUT, "35c-chainload.ppm")
monitor2(f"screendump {ppm}", 0.5)
img = Image.open(ppm).convert("RGB"); img.save(os.path.join(OUT, "35c-chainload.png"))
os.unlink(ppm)
px = img.load()
blue = sum(1 for y in range(0, img.height, 4) for x in range(0, img.width, 4)
           if px[x, y][2] > 120 and px[x, y][2] > px[x, y][0] + 30)
check("E: chainload a 'Windows' (pantalla azul)", blue > 1500, f"px azules={blue}")
mon2.close()
proc2.terminate()

# ==================== FASE F: modo seguro + usuario persistente ====================
print("[fase F] autoarranque en modo seguro (opción 2 persistida)...")
MON3 = MON + ".3"
if os.path.exists(MON3): os.unlink(MON3)
SERIAL3 = os.path.join(OUT, "serial-v13-safe.log")
cmd3 = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
        "-monitor", f"unix:{MON3},server,nowait", "-serial", f"file:{SERIAL3}",
        "-drive", f"format=raw,file={BASE}/fenixos.img"]
proc3 = subprocess.Popen(cmd3, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON3): break
    time.sleep(0.1)
mon3 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon3.connect(MON3); mon3.settimeout(2.0)
try: mon3.recv(4096)
except socket.timeout: pass

def monitor3(command, wait=0.1):
    mon3.sendall((command + "\n").encode())
    time.sleep(wait)
    try: return mon3.recv(65536).decode(errors="replace")
    except socket.timeout: return ""

def send_text3(text):
    for ch in text:
        monitor3(f"sendkey {KEYMAP.get(ch, ch)}", 0.06)
    time.sleep(0.3)

shot3 = make_shot(mon3)

time.sleep(20)          # autoarranque opción 2 (4s) + kernel
S3 = open(SERIAL3, errors="replace").read()
check("F: MODO SEGURO automático (persistencia arranque)", "MODO SEGURO" in S3)
check("F: sin red en modo seguro", "modo seguro: pila TCP/IP no inicializada" in S3)
ppm = os.path.join(OUT, "36-modo-seguro.ppm")
monitor3(f"screendump {ppm}", 0.4)
img = Image.open(ppm).convert("RGB"); img.save(os.path.join(OUT, "36-modo-seguro.png"))
os.unlink(ppm)
check("F: resolución 800x600 en modo seguro", img.size == (800, 600), str(img.size))

# restaurar arranque por defecto (admin) y probar usuario persistente
send_text3("arranque 1 8\n")
time.sleep(0.8)
S3 = open(SERIAL3, errors="replace").read()
check("F: arranque restaurado a opción 1/8s", "config de arranque escrita: opcion 1" in S3)
send_text3("login pepe 4321\n")
time.sleep(0.8)
send_text3("quiensoy\n")
time.sleep(0.8)
S3 = open(SERIAL3, errors="replace").read()
check("F: login pepe (usuario persistente)", "login: 'pepe' (rol usuario)" in S3)
check("F: quiensoy = pepe", "usuario: pepe (rol usuario)" in S3)
mon3.close()
proc3.terminate()

# verificación final del sector FNXBOOT1 restaurado en fenixos.img
time.sleep(1)
d0 = open(os.path.join(BASE, "fenixos.img"), "rb").read(42*512)
bc = d0[41*512:41*512+10]
check("F: FNXBOOT1 en disco = opcion 1, 8s", bc[:8] == b"FNXBOOT1" and bc[8] == 1 and bc[9] == 8, str(bc))

# ============================ resumen ============================
print("\n===== RESUMEN test_v13 =====")
ok = sum(1 for _, r in results if r)
for name, r in results:
    print(f"  {'OK  ' if r else 'FALLO'} {name}")
print(f"TOTAL: {ok}/{len(results)}")
sys.exit(0 if ok == len(results) else 1)
