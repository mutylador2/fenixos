#!/usr/bin/env python3
"""FenixOS — test_v11.py
Prueba automatizada de las NOVEDADES de la v1.1 en QEMU headless:
  - RAMFS: archivos / escribir / leer / tocar / borrar (por píxeles)
  - Editor gráfico: apertura, tecleo, botón Guardar (click de ratón),
    indicador "guardado" y verificación del contenido con 'leer'
  - sonido / musica (el comando se ejecuta sin panicos)
  - acerca (ventana Acerca de)
Genera capturas 12..19 en capturas/.
"""
import os
import socket
import subprocess
import sys
import time

from PIL import Image

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG = os.path.join(BASE, "fenixos.img")
QEMU = "/home/z/my-project/tools/qemu"
OUT = os.path.join(BASE, "capturas")
SERIAL = os.path.join(OUT, "serial.log")
MON = "/tmp/fenix-v11.sock"

os.makedirs(OUT, exist_ok=True)
if os.path.exists(MON):
    os.unlink(MON)

cmd = [
    QEMU,
    "-drive", f"format=raw,file={IMG}",
    "-m", "256",
    "-vga", "std",
    "-nic", "none",
    "-display", "none",
    "-monitor", f"unix:{MON},server,nowait",
    "-serial", f"file:{SERIAL}",
]

proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON):
        break
    time.sleep(0.1)
else:
    print("[test] ERROR: el monitor no apareció")
    proc.kill()
    sys.exit(1)

time.sleep(1.0)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON)
mon.settimeout(2.0)
try:
    mon.recv(4096)
except socket.timeout:
    pass


def monitor(command, wait=0.1):
    mon.sendall((command + "\n").encode())
    time.sleep(wait)
    try:
        return mon.recv(65536).decode(errors="replace")
    except socket.timeout:
        return ""


KEYMAP = {
    ' ': "spc", '.': "dot", ',': "comma", '-': "minus", '=': "equal",
    '/': "slash", ';': "semicolon", "'": "apostrophe", '\n': "ret",
}


def send_text(text):
    for ch in text:
        key = KEYMAP.get(ch, ch)
        monitor(f"sendkey {key}", 0.06)
    time.sleep(0.3)


def mouse_to(x, y, wait=0.15):
    """movimiento relativo acumulado desde la posición actual del cursor"""
    global CUR
    dx, dy = x - CUR[0], y - CUR[1]
    monitor(f"mouse_move {dx} {dy}", wait)
    CUR = (x, y)


def click(wait=0.4):
    monitor("mouse_button 1", wait)
    monitor("mouse_button 0", 0.1)


CUR = (512, 384)          # el driver arranca el cursor en el centro


def shot(tag):
    ppm = os.path.join(OUT, tag + ".ppm")
    monitor(f"screendump {ppm}", 0.4)
    img = Image.open(ppm).convert("RGB")
    img.save(os.path.join(OUT, tag + ".png"))
    return img


def count_white(img, box):
    px = img.load()
    n = 0
    for y in range(box[1], box[3]):
        for x in range(box[0], box[2]):
            r, g, b = px[x, y]
            if r > 200 and g > 200 and b > 200:
                n += 1
    return n


def count_accent(img, box):
    px = img.load()
    n = 0
    for y in range(box[1], box[3]):
        for x in range(box[0], box[2]):
            r, g, b = px[x, y]
            if r > 200 and 60 < g < 180 and b < 90:      # acento fuego 0xFF7A18
                n += 1
    return n


def count_red(img, box):
    px = img.load()
    n = 0
    for y in range(box[1], box[3]):
        for x in range(box[0], box[2]):
            r, g, b = px[x, y]
            if r > 200 and g < 140 and b < 140:          # error 0xFFF85149
                n += 1
    return n


SHELL_BOX = (70, 60, 660, 440)       # área de texto de la ventana Terminal

results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(f"[test] {'OK ' if cond else 'FALLO'} {name} {detail}")


# ---- 1. arranque + listado inicial del RAMFS (menú multiboot v1.3: +10s) ----
time.sleep(15.0)
img = shot("12-archivos")
w0 = count_white(img, SHELL_BOX)
send_text("archivos\n")
time.sleep(0.7)
img = shot("12-archivos")
w1 = count_white(img, SHELL_BOX)
check("RAMFS 'archivos' lista contenido", w1 > w0 + 60, f"blancos {w0}->{w1}")

# ---- 2. escribir + leer un archivo nuevo ----
send_text("escribir carta.txt hola fenix esto es una prueba de ramfs\n")
time.sleep(0.5)
send_text("limpiar\n")
time.sleep(0.4)
img = shot("13-leer")
w2 = count_white(img, SHELL_BOX)
send_text("leer carta.txt\n")
time.sleep(0.7)
img = shot("13-leer")
w3 = count_white(img, SHELL_BOX)
check("'escribir' + 'leer' muestran el texto", w3 > w2 + 200, f"blancos {w2}->{w3}")

# ---- 3. editor gráfico: archivo nuevo, teclear y guardar ----
send_text("editor nueva.txt\n")
time.sleep(0.9)
img = shot("14-editor")
px = img.load()
# barra de título de la ventana editor (302,56) 540x344, con foco: 0xB35310
tit = px[500, 70]
check("ventana Editor abierta con foco",
      abs(tit[0] - 179) < 40 and abs(tit[1] - 83) < 40 and tit[2] < 60,
      f"titulo px={tit}")

# teclear texto en minúsculas (sendkey sin shift no emite mayúsculas)
send_text("editado desde el editor grafico de fenixos")
time.sleep(0.4)

# click en Guardar: botón en (768..834, 378..396), centro (801,387)
mouse_to(801, 387)
click(0.6)
img = shot("15-editor-guardado")
acc = count_accent(img, (485, 372, 575, 400))
check("botón Guardar guarda (indicador 'guardado')", acc > 15, f"pixeles acento={acc}")

# ---- 4. volver a la terminal y verificar el guardado ----
mouse_to(200, 300)
click(0.4)
send_text("limpiar\n")
time.sleep(0.4)
img = shot("16-leer-editor")
w_empty = count_white(img, SHELL_BOX)
send_text("leer nueva.txt\n")
time.sleep(0.8)
img = shot("16-leer-editor")
w4 = count_white(img, SHELL_BOX)
# nueva.txt era inexistente: SOLO el editor pudo haberle puesto texto
check("'leer' refleja lo tecleado en el editor", w4 > w_empty + 200,
      f"blancos {w_empty}->{w4}")

# ---- 5. tocar + listar + borrar ----
send_text("tocar vacio.txt\n")
time.sleep(0.4)
send_text("limpiar\n")
time.sleep(0.4)
send_text("archivos\n")
time.sleep(0.7)
img = shot("17-archivos2")
w5 = count_white(img, SHELL_BOX)
check("'archivos' lista 4 entradas (2+1+1)", w5 > 500, f"blancos={w5}")

send_text("borrar nueva.txt\n")
time.sleep(0.4)
send_text("limpiar\n")
time.sleep(0.4)
send_text("leer nueva.txt\n")
time.sleep(0.7)
img = shot("18-borrado")
r1 = count_red(img, SHELL_BOX)
check("'borrar' elimina y 'leer' falla en rojo", r1 > 20, f"rojos={r1}")

# ---- 6. sonido (altavoz PC) ----
send_text("sonido\n")
time.sleep(1.2)
img = shot("19-sonido")
w6 = count_white(img, SHELL_BOX)
check("'sonido' se ejecuta sin panicos", w6 > 100, f"blancos={w6}")

# ---- 7. acerca (ventana) ----
send_text("acerca\n")
time.sleep(0.8)
img = shot("20-acerca")
px = img.load()
tit = px[400, 240]
check("ventana 'Acerca de FenixOS' abierta",
      abs(tit[0] - 179) < 40 and abs(tit[1] - 83) < 40 and tit[2] < 60,
      f"titulo px={tit}")

monitor("quit")
try:
    proc.wait(timeout=5)
except subprocess.TimeoutExpired:
    proc.kill()

# ---- informe ----
print("\n===== informe v1.1 =====")
ok = True
for name, cond, detail in results:
    if not cond:
        ok = False
    print(f"  {'OK ' if cond else 'FALLO'} {name} {detail}")

# el sistema no debe haber entrado en pánico
if os.path.exists(SERIAL):
    with open(SERIAL) as f:
        log = f.read()
    panic = "PANIC" in log
    print(f"  {'FALLO' if panic else 'OK '} sin panicos en serial.log")
    if panic:
        ok = False

sys.exit(0 if ok else 2)
