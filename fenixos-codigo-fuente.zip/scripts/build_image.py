#!/usr/bin/env python3
"""FenixOS — build_image.py (v1.3)
Construye la imagen de disco raw (64MB) con:
  LBA 0      : stage1 (MBR, con buscador de partición 0x63)
  LBA 1-40   : stage2 (20 KB)
  LBA 41     : sector de configuración del gestor de arranque 'FNXBOOT1'
  LBA 128..  : kernel.inst.bin (kernel con stage1+stage2 incrustados)
Sin tabla de particiones (instalación de disco entero); el instalador
gráfico del sistema puede convertirlo a formato particionado.
Genera también fenixos.vhd (disco fijo VHD) para VirtualBox.
"""
import struct
import sys
import os
import time
import uuid

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STAGE1 = os.path.join(BASE, "boot", "stage1.bin")
STAGE2 = os.path.join(BASE, "boot", "stage2.bin")
KERNEL = os.path.join(BASE, "kernel.inst.bin")
IMG = os.path.join(BASE, "fenixos.img")
VHD = os.path.join(BASE, "fenixos.vhd")

DISK_MB = 64
KERNEL_LBA = 128
STAGE2_SECTORS = 40
BOOTCFG_LBA = 41


def build_raw():
    size = DISK_MB * 1024 * 1024
    disk = bytearray(size)

    with open(STAGE1, "rb") as f:
        s1 = f.read()
    with open(STAGE2, "rb") as f:
        s2 = f.read()
    with open(KERNEL, "rb") as f:
        kern = f.read()

    assert len(s1) == 512, "stage1 debe medir 512 bytes"
    assert len(s2) == STAGE2_SECTORS * 512, "stage2 debe medir exactamente 20KB"
    assert len(kern) < 1024 * 1024, "kernel demasiado grande"

    disk[0:512] = s1
    disk[512:512 + len(s2)] = s2

    # sector de configuración del gestor de arranque (menú multiboot)
    bootcfg = bytearray(512)
    bootcfg[0:8] = b"FNXBOOT1"
    bootcfg[8] = 1      # opción por defecto: FenixOS
    bootcfg[9] = 8      # autoarranque: 8 segundos
    off = BOOTCFG_LBA * 512
    disk[off:off + 512] = bootcfg

    koff = KERNEL_LBA * 512
    disk[koff:koff + len(kern)] = kern

    with open(IMG, "wb") as f:
        f.write(disk)
    print(f"fenixos.img  : {size} bytes | stage1 512B | stage2 {len(s2)}B | "
          f"bootcfg LBA {BOOTCFG_LBA} | kernel {len(kern)}B ({(len(kern)+511)//512} sectores)")


def vhd_footer(size_bytes, cyl, heads, spt):
    """Footer VHD de disco fijo según el spec oficial (big-endian)."""
    f = bytearray(512)
    struct.pack_into(">8s", f, 0, b"conectix")          # cookie
    struct.pack_into(">I", f, 8, 2)                     # features
    struct.pack_into(">I", f, 12, 0x00010000)           # file format version
    struct.pack_into(">Q", f, 16, 0xFFFFFFFFFFFFFFFF)   # data offset (fixed)
    struct.pack_into(">I", f, 24, int(time.time()) - 946684800)  # timestamp desde 2000
    struct.pack_into(">4s", f, 28, b"vbox")             # creator application
    struct.pack_into(">I", f, 32, 0x00010000)           # creator version
    struct.pack_into(">4s", f, 36, b"Wi2k")             # creator host os
    struct.pack_into(">Q", f, 40, size_bytes)           # original size
    struct.pack_into(">Q", f, 48, size_bytes)           # current size
    struct.pack_into(">H", f, 56, cyl)                  # cylinder
    struct.pack_into(">B", f, 58, heads)                # heads
    struct.pack_into(">B", f, 59, spt)                  # sectors per track
    struct.pack_into(">I", f, 60, 2)                    # disk type: fixed
    # checksum en 64 (complemento a uno de la suma con el campo a cero)
    f[68:84] = uuid.uuid4().bytes
    checksum = (~sum(f)) & 0xFFFFFFFF
    struct.pack_into(">I", f, 64, checksum)
    return bytes(f)


def build_vhd():
    size = os.path.getsize(IMG)
    # geometría CHS estándar para VirtualBox
    total_sect = size // 512
    spt, heads = 63, 16
    cyl = max(1, min(65535, total_sect // (heads * spt)))
    with open(IMG, "rb") as fsrc, open(VHD, "wb") as fdst:
        while True:
            chunk = fsrc.read(1 << 20)
            if not chunk:
                break
            fdst.write(chunk)
        fdst.write(vhd_footer(size, cyl, heads, spt))
    print(f"fenixos.vhd  : {size} bytes + footer VHD (CHS {cyl}/{heads}/{spt})")


if __name__ == "__main__":
    build_raw()
    build_vhd()
