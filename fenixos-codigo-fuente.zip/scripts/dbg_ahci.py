#!/usr/bin/env python3
"""FenixOS — dbg_ahci.py: diagnóstico AHCI read/write con trazas."""
import socket, subprocess, sys, time, os

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-dbg.sock"
SER = "/tmp/fenix-dbg.log"
if os.path.exists(MON): os.unlink(MON)
open(SER, "w").close()

cmd = [QEMU, "-m", "256", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SER}",
       "-device", "ich9-ahci,id=ahci",
       "-drive", f"if=none,id=d0,format=raw,file={BASE}/fenixos.img",
       "-device", "ide-hd,drive=d0,bus=ahci.0",
       "-drive", "if=none,id=d1,format=raw,file=/tmp/fenix-otros-os.img",
       "-device", "ide-hd,drive=d1,bus=ahci.1"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def m(c, w=0.12):
    mon.sendall((c + "\n").encode()); time.sleep(w)
    try: return mon.recv(65536).decode(errors="replace")
    except socket.timeout: return ""

KMAP = {' ': "spc", '\n': "ret"}
def st(t):
    for ch in t: m("sendkey " + KMAP.get(ch, ch))
    time.sleep(0.4)

time.sleep(26)
st("arranque\n")        # leer LBA 41 (FNXBOOT1)
time.sleep(1)
st("arranque 2 5\n")    # escribir LBA 41
time.sleep(1.5)
st("arranque\n")        # releer
time.sleep(1)
mon.close()
proc.terminate()
proc.wait(timeout=10)
print("---- serial ----")
for line in open(SER, errors="replace"):
    if "[AHCI]" in line or "[BLK]" in line or "[FSH]" in line or "[CFG]" in line:
        print(line.rstrip())
d = open(f"{BASE}/fenixos.img", "rb").read(42 * 512)
print("LBA41 en fichero:", d[41 * 512:41 * 512 + 10])
