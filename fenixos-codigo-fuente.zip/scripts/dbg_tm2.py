#!/usr/bin/env python3
"""dbg_tm2.py — mide píxeles brillantes: SeaBIOS vs menú stage2."""
import socket, subprocess, time, os
from PIL import Image

QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-tmdbg2.sock"
DISK = "/tmp/fenix-otros-os.img"
if os.path.exists(MON): os.unlink(MON)

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait",
       "-drive", f"format=raw,file={DISK}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

ppm = "/tmp/tmdbg2.ppm"
prev = None
for i in range(14):
    try:
        mon.sendall(f"screendump {ppm}\n".encode())
        time.sleep(0.7)
        img = Image.open(ppm).convert("L")
        bright = sum(1 for v in img.getdata() if v > 160)
        tag = "IGUAL" if bright == prev else "cambia"
        print(f"t={i*1.2:4.1f}s  size={img.size} bright={bright} {tag}")
        prev = bright
        img.close(); os.unlink(ppm)
    except Exception as e:
        print(f"t={i*1.2:4.1f}s  err: {e}")
mon.close()
proc.terminate()
