#!/usr/bin/env python3
import struct
"""dep_httpd.py: depuración del servidor web — boot, servidor on, curl -v,
volcado de paquetes del cable slirp."""
import os, socket, subprocess, sys, time

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
SERIAL = "/tmp/dep-httpd.log"
MON = "/tmp/dep-httpd.sock"
DUMP = "/tmp/dep-httpd.pcap"
for f in (SERIAL, MON, DUMP):
    if os.path.exists(f): os.unlink(f)
open(SERIAL, "w").close()

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SERIAL}",
       "-netdev", "user,id=n0,hostfwd=tcp::18080-:80",
       "-device", "e1000,netdev=n0",
       "-object", f"filter-dump,id=f0,netdev=n0,file={DUMP}",
       "-drive", f"if=ide,index=0,format=raw,file={BASE}/fenixos.img"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def monitor(c, wait=0.1):
    mon.sendall((c + "\n").encode())
    time.sleep(wait)
    try: return mon.recv(65536).decode(errors="replace")
    except socket.timeout: return ""

def serial_read():
    return open(SERIAL, errors="replace").read()

def wait_serial(needle, timeout=60):
    t0 = time.time()
    while time.time() - t0 < timeout:
        if needle in serial_read(): return True
        time.sleep(0.5)
    return False

wait_serial("FenixOS 1.4", 60)
time.sleep(3)
KEYMAP = {' ': "spc", '.': "dot", ':': "shift-semicolon", '/': "slash", '\n': "ret"}
def send_text(t):
    for ch in t:
        monitor(f"sendkey {KEYMAP.get(ch, ch)}", 0.06)
    time.sleep(0.3)

send_text("servidor on\n")
ok = wait_serial("escuchando en puerto 80", 10)
print("listen:", ok)

# curl con verbose
r = subprocess.run(["curl", "-sv", "--max-time", "15", "http://127.0.0.1:18080/"],
                   capture_output=True, timeout=20)
print("curl stdout:", r.stdout[:300])
print("curl stderr:", r.stderr.decode(errors="replace")[:1200])
time.sleep(1)
S = serial_read()
print("--- serial (último tramo) ---")
print("\n".join(S.splitlines()[-25:]))

monitor("quit", 0.5)
time.sleep(0.5)
subprocess.run(["pkill", "-f", "qemu-system"], capture_output=True)

# analizar pcap a mano (ethernet + ARP + IPv4 + TCP flags)
data = open(DUMP, "rb").read()
# buscar pcap global header
print("pcap bytes:", len(data))
# recorrer paquetes (little endian pcap)
off = 24
n = 0
while off + 16 <= len(data) and n < 60:
    ts, tus, capl, oril = struct.unpack("<IIII", data[off:off + 16])
    pkt = data[off + 16:off + 16 + capl]
    off += 16 + capl
    if len(pkt) < 34: n += 1; continue
    et = (pkt[12] << 8) | pkt[13]
    if et == 0x0806:
        print(n, "ARP op", (pkt[20] << 8 | pkt[21]))
    elif et == 0x0800:
        proto = pkt[23]
        if proto == 6:
            ihl = (pkt[14] & 0xF) * 4
            tcp = pkt[14 + ihl:]
            sp = (tcp[0] << 8) | tcp[1]; dp = (tcp[2] << 8) | tcp[3]
            fl = tcp[13]
            flags = "".join(nm for b, nm in [(0x02, "S"), (0x10, "A"), (0x08, "P"), (0x01, "F"), (0x04, "R")] if fl & b)
            print(n, f"TCP {pkt[26]}.{pkt[27]}.{pkt[28]}.{pkt[29]}:{sp} -> {pkt[30]}.{pkt[31]}.{pkt[32]}.{pkt[33]}:{dp} [{flags}] len={capl}")
    n += 1
