#!/usr/bin/env python3
"""FenixOS — dbg_phaseE.py: replica la fase E con diagnóstico del proceso."""
import socket, subprocess, sys, time, os

BASE = "/home/z/my-project/fenixos"
QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-e.sock"
SER = "/tmp/fenix-e.log"
if os.path.exists(MON): os.unlink(MON)
open(SER, "w").close()

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SER}",
       "-drive", "format=raw,file=/tmp/fenix-otros-os.img"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass
print("conectado al monitor; qemu vivo:", proc.poll() is None)

time.sleep(23)
S = open(SER, errors="replace").read()
print("serial tiene Titan:", "FenixOS 1.3 'Titan'" in S)
print("qemu vivo tras 23s:", proc.poll() is None)

ppm = "/tmp/e2.ppm"
try:
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.6)
    print("screendump enviado OK")
except Exception as e:
    print("screendump fallo:", e)
print("qemu vivo:", proc.poll() is None)
if proc.poll() is not None:
    print("stderr:", proc.stderr.read().decode(errors="replace")[:300])
mon.close()
proc.terminate(); proc.wait(timeout=10)
from PIL import Image
try:
    Image.open(ppm).convert("RGB").save("/tmp/e2.png")
    print("captura /tmp/e2.png")
except Exception as e:
    print("sin captura:", e)
