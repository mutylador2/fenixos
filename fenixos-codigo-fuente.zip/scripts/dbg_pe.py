#!/usr/bin/env python3
"""dbg_pe.py — replica EXACTA de la fase E con timestamps y sondeos."""
import socket, subprocess, time, os
from PIL import Image

QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-pe.sock"
SER = "/tmp/fenix-pe.log"
DISK = "/tmp/fenix-otros-os.img"
if os.path.exists(MON): os.unlink(MON)
open(SER, "w").close()

T0 = time.time()
def ts(): return f"{time.time()-T0:6.1f}s"

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait", "-serial", f"file:{SER}",
       "-drive", f"format=raw,file={DISK}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass
print(f"{ts()} monitor conectado")

def drain():
    try:
        while True:
            d = mon.recv(65536)
            if not d: break
    except socket.timeout:
        pass

def shot():
    ppm = "/tmp/pe.ppm"
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    try:
        img = Image.open(ppm); s = img.size; img.close(); os.unlink(ppm)
        return s
    except Exception:
        return None

# detección de menú con píxeles brillantes (como dbg_tm2) + tamaño
def menu_listo():
    ppm = "/tmp/pe2.ppm"
    mon.sendall(f"screendump {ppm}\n".encode())
    time.sleep(0.5)
    try:
        img = Image.open(ppm).convert("L"); s = img.size
        bright = sum(1 for v in img.getdata() if v > 160)
        img.close(); os.unlink(ppm)
        return s, bright
    except Exception:
        return None, 0

for i in range(30):
    s, b = menu_listo()
    print(f"{ts()} size={s} bright={b}")
    if s == (720, 400) and b > 12000:
        print(f"{ts()} MENÚ ARRIBA (bright {b})")
        break
    time.sleep(0.6)

time.sleep(1.0)
print(f"{ts()} enviando sendkey 1")
mon.sendall(b"sendkey 1\n")
time.sleep(0.5)
drain()

gui = False
for i in range(30):
    s = shot()
    if s == (1024, 768):
        gui = True
        print(f"{ts()} GUI 1024x768 detectada")
        break
    time.sleep(1.0)
if not gui:
    print(f"{ts()} GUI NO detectada en 30s")

ser = open(SER, errors="replace").read()
print(f"{ts()} serial: {len(ser)} bytes, Titan={'FenixOS 1.3' in ser}")
print(f"{ts()} qemu vivo: {proc.poll() is None}")
mon.close()
proc.terminate()
