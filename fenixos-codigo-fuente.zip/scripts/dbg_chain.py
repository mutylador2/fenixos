#!/usr/bin/env python3
"""dbg_chain.py — reproduce el chainload (opción 3) del menú con capturas secuenciales."""
import socket, subprocess, time, os, sys
from PIL import Image

QEMU = "/home/z/my-project/tools/qemu"
MON = "/tmp/fenix-chain.sock"
DISK = sys.argv[1] if len(sys.argv) > 1 else "/tmp/fenix-otros-os.img"
if os.path.exists(MON): os.unlink(MON)

cmd = [QEMU, "-m", "256", "-vga", "std", "-display", "none",
       "-monitor", f"unix:{MON},server,nowait",
       "-drive", f"format=raw,file={DISK}"]
proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
for _ in range(100):
    if os.path.exists(MON): break
    time.sleep(0.1)
mon = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
mon.connect(MON); mon.settimeout(2.0)
try: mon.recv(4096)
except socket.timeout: pass

def shot(tag):
    ppm = f"/tmp/ch-{tag}.ppm"
    try:
        mon.sendall(f"screendump {ppm}\n".encode())
        time.sleep(0.35)
        Image.open(ppm).convert("RGB").save(f"/tmp/ch-{tag}.png")
        os.unlink(ppm)
    except Exception as e:
        print(f"shot {tag}: {e}")

def key(k, w=0.3):
    mon.sendall(f"sendkey {k}\n".encode())
    time.sleep(w)

print("esperando menú (12s)..."); time.sleep(12)
shot("0-menu")
key("3"); shot("1-tras-3"); time.sleep(0.5); shot("2-tras-3b")
key("1"); shot("3-tras-1"); time.sleep(0.5); shot("4-tras-1b")
time.sleep(1.5); shot("5-final")
mon.close()
proc.terminate()
print("listo: /tmp/ch-*.png")
