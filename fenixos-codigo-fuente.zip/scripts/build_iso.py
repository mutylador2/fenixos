#!/usr/bin/env python3
"""FenixOS — build_iso.py (v1.3)
Construye fenixos.iso como ISO HÍBRIDA:
  - CD booteable: El Torito SIN EMULACIÓN (la BIOS copia el blob entero
    a 0x7C00; sin lecturas del cdemu).
  - USB booteable (Rufus en modo DD, o dd): tras generar el ISO se
    parchea el área de sistema (primeros 32 KB, no usados por ISO9660)
    con un MBR propio (stage1hybrid) que carga stage2+kernel directamente
    desde los sectores del blob dentro del ISO.

Diseño del arranque desde CD:
  - El blob de arranque (boot/fenixos-cdboot.img) contiene TODO: stub
    (512 B) + stage2 (20 KB) + kernel. El BIOS El Torito lo copia
    COMPLETO a 0x7C00 y salta al stub, que marca el modo 2 en 0x0528.
  - Restricción de memoria: 0x7C00 + blob < 0x40000 (KBUF), es decir
    blob < 0x38400 bytes (230 KB).

Diseño del arranque híbrido por USB:
  - El catálogo El Torito indica el sector de 2 KB del blob (B).
  - En LBAs de 512 B: stage2 está en 4B+1 y el kernel en 4B+41.
  - El MBR híbrido carga stage2 a 0x7E00, pasa el LBA del kernel en
    0x0530 y stage2 sigue su ruta 'ISO híbrido'.
"""
import os
import struct
import subprocess
import sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BLOB = os.path.join(BASE, "boot", "fenixos-cdboot.img")
HYB = os.path.join(BASE, "boot", "stage1hybrid.bin")
ISO = os.path.join(BASE, "fenixos.iso")
STAGE = os.path.join(BASE, "iso-staging")
GENISO = "/home/z/my-project/tools/root/usr/bin/genisoimage"
NASM = "/home/z/my-project/tools/root/usr/bin/nasm"

VOL_ID = "FENIXOS_1.3"
BLOB_MAX = 0x38400          # 0x7C00 + blob < 0x40000 (KBUF)
MAGIC_BLOB = 0xDEADBEEF
MAGIC_S2 = 0xDEADBEE1
MAGIC_KRN = 0xDEADBEE2

LEEME = """FenixOS 1.3 "Titan" — ISO híbrida (CD + USB)
=============================================

Este disco es a la vez CD booteable y imagen USB booteable.

Como CD:
  QEMU:       qemu-system-x86_64 -cdrom fenixos.iso -m 256 -vga std
              (añade -nic user,model=e1000 para red)
  VirtualBox: Controlador IDE -> insertar este ISO y arrancar de CD.
  PC real:    graba el ISO en un CD/DVD y arranca con Legacy/CSM.
  Arranque directo: sin menú (El Torito carga todo el sistema).

Como USB (gestor de arranque con menú multiboot):
  Rufus:      selecciona fenixos.iso, esquema MBR, y si pregunta
              elige modo DD (escribir imagen exacta).
  Linux:      dd if=fenixos.iso of=/dev/sdX bs=4M conv=fsync
  Al arrancar verás el MENÚ MULTIBOOT:
    1) FenixOS              2) modo seguro
    3) otro SO de este disco (chainload Windows/Linux)
    4) otro disco           5) información del sistema

Novedades 1.3: menú multiboot con chainload, driver AHCI/SATA,
instalador gráfico (disco completo o junto a otros OS), configuración
del arranque persistente, usuarios persistentes y panel de
información del sistema.

Cuentas: admin/fenix - usuario/1234 - invitado (sin clave).
Escribe 'ayuda' en la terminal para ver todas las órdenes.
"""


def main():
    # el binario híbrido se ensambla aquí por dependencia circular con el LBA
    if not os.path.exists(HYB):
        r = subprocess.run([NASM, "-f", "bin",
                            os.path.join(BASE, "boot", "stage1hybrid.asm"),
                            "-o", HYB], capture_output=True, text=True)
        if r.returncode != 0:
            print(r.stderr)
            print("ERROR: nasm falló para stage1hybrid.asm")
            sys.exit(1)

    if not os.path.exists(BLOB):
        print("ERROR: falta boot/fenixos-cdboot.img; ejecuta make antes")
        sys.exit(1)

    blob_size = os.path.getsize(BLOB)
    assert blob_size <= BLOB_MAX, (
        f"el blob del CD mide {blob_size} bytes y supera el límite de "
        f"{BLOB_MAX} (0x7C00 + blob debe quedar por debajo de 0x40000)")

    os.makedirs(STAGE, exist_ok=True)
    with open(BLOB, "rb") as fsrc, open(os.path.join(STAGE, "fenixos-cdboot.img"), "wb") as fdst:
        fdst.write(fsrc.read())
    with open(os.path.join(STAGE, "LEEME-ISO.txt"), "w") as f:
        f.write(LEEME)

    cmd = [
        GENISO, "-quiet",
        "-o", ISO,
        "-V", VOL_ID,
        "-R", "-J",
        "-b", "fenixos-cdboot.img",
        "-c", "boot.catalog",
        "-no-emul-boot",
        "-input-charset", "utf-8",
        "-hide", "boot.catalog",
        "-hide", "fenixos-cdboot.img",
        os.path.relpath(STAGE, BASE),
    ]
    print("[iso] genisoimage (El Torito sin emulación) ...")
    r = subprocess.run(cmd, cwd=BASE, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout)
        print(r.stderr)
        print("ERROR: genisoimage falló")
        sys.exit(2)

    with open(ISO, "rb") as f:
        data = bytearray(f.read())

    # ---- verificación del catálogo El Torito ----
    brvd = 17 * 2048
    assert data[brvd + 7:brvd + 30] == b"EL TORITO SPECIFICATION", \
        "el Boot Record no es El Torito"
    catalog_lba = struct.unpack_from("<I", data, brvd + 71)[0]
    entry = catalog_lba * 2048 + 32
    assert data[entry] == 0x88, "la entrada de arranque no es arrancable"
    media = data[entry + 1]
    assert media == 0, f"media type {media} no es sin-emulación"
    nsect = struct.unpack_from("<H", data, entry + 6)[0]
    blob_lba2k = struct.unpack_from("<I", data, entry + 8)[0]   # Load RBA
    print(f"[iso] catálogo OK: media=no-emul, carga={nsect} sect "
          f"({nsect*512} bytes) | blob={blob_size} bytes @ sector 2KB {blob_lba2k}")

    # ---- parcheo HÍBRIDO: MBR propio en el área de sistema ----
    stage2_lba = blob_lba2k * 4 + 1
    kernel_lba = blob_lba2k * 4 + 41
    hyb = bytearray(open(HYB, "rb").read())
    assert len(hyb) == 512, "stage1hybrid debe medir 512 bytes"
    for magic, val in ((MAGIC_BLOB, blob_lba2k), (MAGIC_S2, stage2_lba),
                       (MAGIC_KRN, kernel_lba)):
        mb = struct.pack("<I", magic)
        i = hyb.find(mb)
        assert i >= 0, f"marcador {magic:#x} no encontrado en stage1hybrid"
        struct.pack_into("<I", hyb, i, val)
    # tamaño de la "partición" = todo el ISO (en sectores de 512)
    total512 = len(data) // 512
    struct.pack_into("<I", hyb, 446 + 16 - 4, total512)
    data[0:512] = hyb
    assert data[510] == 0x55 and data[511] == 0xAA, "firma MBR híbrida inválida"

    with open(ISO, "wb") as f:
        f.write(data)

    size = os.path.getsize(ISO)
    print(f"[iso] parcheo híbrido OK: stage2@LBA {stage2_lba}, kernel@LBA {kernel_lba}")
    print(f"fenixos.iso  : {size} bytes ({size/1024/1024:.1f} MB) | {VOL_ID} | CD + USB")


if __name__ == "__main__":
    main()
