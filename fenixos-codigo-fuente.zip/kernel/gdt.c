/* FenixOS — gdt.c: GDT propia del kernel (reemplaza la provisional de stage2) */
#include "fenixos.h"

/* 0x00 nulo | 0x08 código64 | 0x10 datos | 0x18 código32 (compatibilidad) */
static u64 gdt_entries[4];
static struct { u16 limit; u64 base; } __attribute__((packed)) gdt_desc;

static const u64 gdt_init_vals[4] = {
    0x0000000000000000ull,
    0x00AF9A000000FFFFull,   /* código 64-bit: L=1 */
    0x00CF92000000FFFFull,   /* datos */
    0x00CF9A000000FFFFull,   /* código 32-bit */
};

void gdt_init(void) {
    for (int i = 0; i < 4; i++) gdt_entries[i] = gdt_init_vals[i];
    gdt_desc.limit = sizeof(gdt_entries) - 1;
    gdt_desc.base = (u64)gdt_entries;

    __asm__ volatile(
        "lgdt %0\n"
        "push $0x08\n"
        "leaq 1f(%%rip), %%rax\n"
        "push %%rax\n"
        "lretq\n"
        "1:\n"
        "mov $0x10, %%ax\n"
        "mov %%ax, %%ds\n"
        "mov %%ax, %%es\n"
        "mov %%ax, %%ss\n"
        "xor %%ax, %%ax\n"
        "mov %%ax, %%fs\n"
        "mov %%ax, %%gs\n"
        :: "m"(gdt_desc) : "rax", "memory"
    );
}
