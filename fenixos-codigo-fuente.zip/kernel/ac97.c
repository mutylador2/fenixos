/* FenixOS — ac97.c: driver de audio AC'97 (Intel 82801AA, v1.4)
 *
 * Sale por PCI: QEMU lo emula con -device AC97, VirtualBox ofrece el
 * emulador "ICH AC97" y muchísimo hardware real de 2000-2010 usa este
 * controlador. Es LA tarjeta de sonido clásica del x86.
 *
 * Modelo:
 *   BAR0 (I/O) = NAM  : registros del códec (volúmenes, frecuencia)
 *   BAR1 (I/O) = NABM : motor DMA (lista de descriptores de búfer, BDL)
 * Cada entrada del BDL apunta a un búfer de PCM estéreo 16-bit; el
 * "len" se cuenta en marcos estéreo de 4 bytes.
 *
 * En QEMU se puede VERIFICAR automáticamente: -audiodev driver=wav
 * vuelca lo que el huésped reproduce a un archivo .wav real. */
#include "fenixos.h"

/* registros NAM (códec) */
#define NAM_RESET   0x00
#define NAM_MASTER  0x02
#define NAM_HEADPH  0x04
#define NAM_PCM     0x18
#define NAM_EXTID   0x28
#define NAM_RATE    0x2C
#define NAM_CAS     0x26

/* registros NABM del stream de salida (PCM out) */
#define NABM_BDBAR  0x10    /* dirección física del BDL */
#define NABM_CIV    0x14    /* índice actual */
#define NABM_LVI    0x15    /* último índice válido */
#define NABM_STS    0x16    /* estado (bit0 = DCH) */
#define NABM_PICB   0x18    /* posición en el búfer (marcos) */
#define NABM_CR     0x1B    /* control: bit0 RUN, bit2 IOCE */

#define PCI_CMD     0x04
#define MAX_BD      16
#define FRAMES_PER_BUF  8192          /* 8192 marcos estéreo = 32 KB */

static int   ac97_ok = 0;
static u16   nam_base = 0, nabm_base = 0;
static u8    ac97_bus = 0, ac97_dev = 0, ac97_fn = 0;
static u32   ac97_played = 0;          /* marcos reproducidos */
static u32   ac97_bd_done = 0;

static inline void wr16l(u8 *p, u16 v) { p[0] = (u8)v; p[1] = (u8)(v >> 8); }
static inline void wr32l(u8 *p, u32 v) {
    p[0] = (u8)v; p[1] = (u8)(v >> 8); p[2] = (u8)(v >> 16); p[3] = (u8)(v >> 24);
}

/* ---- acceso PCI (misma técnica que pci.c, sin depender de él) ---- */
static u32 pci_read(u8 bus, u8 dev, u8 fn, u8 off) {
    u32 addr = 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) |
               ((u32)fn << 8) | (off & 0xFC);
    outl(0xCF8, addr);
    return inl(0xCFC);
}
static void pci_write(u8 bus, u8 dev, u8 fn, u8 off, u32 val) {
    u32 addr = 0x80000000u | ((u32)bus << 16) | ((u32)dev << 11) |
               ((u32)fn << 8) | (off & 0xFC);
    outl(0xCF8, addr);
    outl(0xCFC, val);
}

/* escribir un registro del códec por el canal de comandos */
static int codec_write(u8 reg, u16 val) {
    for (int i = 0; i < 200; i++)
        if (!(inw(nam_base + NAM_CAS) & 1)) break;   /* semáforo libre */
    outw(nam_base + reg, val);
    for (int i = 0; i < 1000; i++) {
        if (!(inw(nam_base + NAM_CAS) & 1)) return 0;
        io_wait();
    }
    return -1;
}

static u16 codec_read(u8 reg) {
    for (int i = 0; i < 200; i++)
        if (!(inw(nam_base + NAM_CAS) & 1)) break;
    outw(nam_base + reg, (u16)(reg & 0x7F) | 0x8000u);
    for (int i = 0; i < 1000; i++) {
        if (!(inw(nam_base + NAM_CAS) & 1)) return inw(nam_base + reg);
        io_wait();
    }
    return 0xFFFF;
}

int ac97_init(void) {
    ac97_ok = 0;
    if (pci_count() == 0) pci_init();

    PciDev *p = pci_find(0x8086, 0x2415);       /* Intel 82801AA (QEMU AC97) */
    if (!p) {
        /* buscar cualquier controladora multimedia clase 04/01 */
        for (int i = 0; i < pci_count(); i++) {
            PciDev *d = pci_get(i);
            if (d->class_code == 0x04 && d->subclass == 0x01) { p = d; break; }
        }
    }
    if (!p) {
        klogw("AC97", "sin controladora AC97 (prueba -device AC97)");
        return -1;
    }

    ac97_bus = p->bus; ac97_dev = p->dev; ac97_fn = p->func;
    u32 bar0 = p->bar[0], bar1 = p->bar[1];
    if (!(bar0 & 1) || !(bar1 & 1)) {
        klogw("AC97", "BARs de E/S no disponibles");
        return -1;
    }
    nam_base  = (u16)(bar0 & 0xFFFC);
    nabm_base = (u16)(bar1 & 0xFFFC);

    /* activar E/S + bus master para el DMA */
    u32 cmd = pci_read(ac97_bus, ac97_dev, ac97_fn, PCI_CMD);
    cmd |= 0x05;
    pci_write(ac97_bus, ac97_dev, ac97_fn, PCI_CMD, cmd);

    /* reset frío del motor DMA (GLOB_CNT bit1) y del códec */
    u32 gcs = inl(nabm_base + 0x2C);
    outl(nabm_base + 0x2C, gcs | 0x02);
    for (volatile int i = 0; i < 100000; i++) io_wait();
    outl(nabm_base + 0x2C, gcs & ~0x02u);
    for (volatile int i = 0; i < 100000; i++) io_wait();

    /* reset del códec: escritura al registro 0 */
    outw(nam_base + NAM_RESET, 0xFFFF);
    for (volatile int i = 0; i < 50000; i++) io_wait();

    /* volúmenes a un nivel razonable (attenuación 12 dB aprox) */
    codec_write(NAM_MASTER, 0x0808);
    codec_write(NAM_HEADPH, 0x0808);
    codec_write(NAM_PCM,    0x0808);

    /* frecuencia: activar VRA y fijar 48 kHz */
    u16 ext = codec_read(NAM_EXTID);
    if (ext != 0xFFFF) codec_write(NAM_EXTID, (u16)(ext | 0x01));
    codec_write(NAM_RATE, 48000);

    /* parar el motor de salida por si acaso */
    outb(nabm_base + NABM_CR, 0x00);

    ac97_ok = 1;
    klogf(LOG_INFO, "AC97", "AC97 listo: PCI %02x:%02x.%x, NAM %x NABM %x, 48 kHz",
          ac97_bus, ac97_dev, ac97_fn, nam_base, nabm_base);
    return 0;
}

int ac97_present(void) { return ac97_ok; }
u32 ac97_played_frames(void) { return ac97_played; }
u32 ac97_buffers_done(void) { return ac97_bd_done; }
u16 ac97_io_base(void) { return nabm_base; }

/* reproduce nframes estéreo 16-bit (intercalado L,R). BLOQUEANTE.
 * pcm: puntero a memoria ident-mapeada (kmalloc/pmm: vale para DMA). */
int ac97_play(const i16 *pcm, u32 nframes) {
    if (!ac97_ok || !pcm || !nframes) return -1;
    if (nframes < FRAMES_PER_BUF) return -1;    /* usar búferes completos */

    u32 nbuf = nframes / FRAMES_PER_BUF;
    if (nbuf > MAX_BD) nbuf = MAX_BD;

    /* BDL: MAX_BD entradas de 8 bytes, alineadas a 8 */
    static u8 bdl[MAX_BD * 8] __attribute__((aligned(8)));
    for (u32 i = 0; i < nbuf; i++) {
        wr32l(bdl + i * 8, (u32)((uintptr_t)(pcm + (u64)i * FRAMES_PER_BUF)));
        wr16l(bdl + i * 8 + 4, FRAMES_PER_BUF);  /* marcos estéreo de 4 B */
        bdl[i * 8 + 6] = (i == nbuf - 1) ? 1 : 0;   /* BUP en el último */
        bdl[i * 8 + 7] = 0;
    }

    outb(nabm_base + NABM_CR, 0x00);            /* parar */
    /* limpiar estado INCLUYENDO DCH (bit0): si queda a 1 de la
     * reproducción anterior, el motor no rearranca (hang v1.4→v1.4.1) */
    outb(nabm_base + NABM_STS, 0x1D);
    outl(nabm_base + NABM_BDBAR, (u32)(uintptr_t)bdl);
    outb(nabm_base + NABM_LVI, (u8)(nbuf - 1));
    outb(nabm_base + NABM_CR, 0x01);            /* RUN */

    /* esperar fin: DCH (bit0 de STS) o timeout 10 s */
    u64 deadline = pit_ticks + 400;
    while (pit_ticks < deadline) {
        u8 sts = inb(nabm_base + NABM_STS);
        u8 cr = inb(nabm_base + NABM_CR);
        if (sts & 0x01 || !(cr & 0x01)) {
            ac97_bd_done += nbuf;
            ac97_played += nbuf * FRAMES_PER_BUF;
            outb(nabm_base + NABM_CR, 0x00);
            outb(nabm_base + NABM_STS, 0x1D);
            return 0;
        }
        pit_sleep_ticks(1);
    }
    outb(nabm_base + NABM_CR, 0x00);
    return -2;                                  /* el DMA no terminó */
}
