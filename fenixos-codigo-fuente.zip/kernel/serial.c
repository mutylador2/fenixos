/* FenixOS — serial.c: puerto COM1 para registro de arranque y depuración */
#include "fenixos.h"

#define COM1 0x3F8

void serial_init(void) {
    outb(COM1 + 1, 0x00);    /* sin interrupciones */
    outb(COM1 + 3, 0x80);    /* DLAB=1 */
    outb(COM1 + 0, 0x01);    /* divisor 1 => 115200 baudios */
    outb(COM1 + 1, 0x00);
    outb(COM1 + 3, 0x03);    /* 8N1 */
    outb(COM1 + 2, 0xC7);    /* FIFO activado y limpio */
    outb(COM1 + 4, 0x0B);    /* RTS/DSR */
}

void serial_putc(char c) {
    if (c == '\n') serial_putc('\r');
    for (int i = 0; i < 100000; i++) {
        if (inb(COM1 + 5) & 0x20) break;
    }
    outb(COM1, (u8)c);
}

void serial_write(const char *s) {
    while (*s) serial_putc(*s++);
}
/* klog() vive en klog.c desde la v1.2 (anillo en RAM + niveles) */
