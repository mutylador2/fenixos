/* FenixOS — fb.c: capa HAL gráfica sobre el framebuffer lineal VBE.
 * Doble búfer: se dibuja en backbuffer (RAM) y se vuelca al framebuffer. */
#include "fenixos.h"

FbInfo fb;
u32 *backbuffer = NULLP;

/* glifos generados en font.c */
extern const unsigned char font8x16[95][16];

u32 fb_rgb(u8 r, u8 g, u8 b) {
    return ((u32)r << 16) | ((u32)g << 8) | (u32)b;
}

void fb_init(BootInfo *bi) {
    fb.paddr = bi->fb_paddr;
    fb.pitch = bi->fb_pitch;
    fb.width = bi->fb_width;
    fb.height = bi->fb_height;
    fb.bpp = bi->fb_bpp;
}

static inline u32 *fb_at(i32 x, i32 y) {
    return (u32 *)((u8 *)(u64)fb.paddr + (u64)y * fb.pitch + (u64)x * 4);
}

static inline u16 rgb565(u32 c) {
    return (u16)(((c >> 11) & 0x1F) << 11 | ((c >> 10) & 0x3F) << 5 | ((c >> 3) & 0x1F));
}

void fb_pixel(i32 x, i32 y, u32 color) {
    if (x < 0 || y < 0 || x >= (i32)fb.width || y >= (i32)fb.height) return;
    if (fb.bpp >= 24) *fb_at(x, y) = color;
    else *(u16 *)((u8 *)(u64)fb.paddr + (u64)y * fb.pitch + (u64)x * 2) = rgb565(color);
}

void fb_fill_rect(i32 x, i32 y, i32 w, i32 h, u32 color) {
    if (fb.bpp < 24) {
        for (i32 yy = y; yy < y + h; yy++)
            for (i32 xx = x; xx < x + w; xx++) fb_pixel(xx, yy, color);
        return;
    }
    i32 x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
    i32 x1 = x + w > (i32)fb.width ? (i32)fb.width : x + w;
    i32 y1 = y + h > (i32)fb.height ? (i32)fb.height : y + h;
    if (x1 <= x0 || y1 <= y0) return;
    for (i32 yy = y0; yy < y1; yy++) {
        u32 *row = fb_at(x0, yy);
        for (i32 xx = x0; xx < x1; xx++) *row++ = color;
    }
}

void fb_rect(i32 x, i32 y, i32 w, i32 h, u32 color) {
    fb_fill_rect(x, y, w, 1, color);
    fb_fill_rect(x, y + h - 1, w, 1, color);
    fb_fill_rect(x, y, 1, h, color);
    fb_fill_rect(x + w - 1, y, 1, h, color);
}

void fb_fill(u32 color) {
    fb_fill_rect(0, 0, (i32)fb.width, (i32)fb.height, color);
}

/* glifo dibujado directamente en el framebuffer (consola de arranque) */
void fb_char(i32 x, i32 y, char c, u32 fg, u32 bg) {
    u8 ch = (u8)c;
    if (ch < 32 || ch > 126) return;
    const u8 *g = font8x16[ch - 32];
    for (i32 row = 0; row < 16; row++) {
        u8 bits = g[row];
        for (i32 col = 0; col < 8; col++) {
            fb_pixel(x + col, y + row, (bits & (0x80u >> col)) ? fg : bg);
        }
    }
}

void fb_text(i32 x, i32 y, const char *s, u32 fg, u32 bg) {
    while (*s) {
        fb_char(x, y, *s, fg, bg);
        x += FONT_W;
        s++;
    }
}

/* ---------------------- backbuffer (siempre 32bpp) ---------------------- */
static inline u32 *bb_at(i32 x, i32 y) {
    return backbuffer + (u64)y * fb.width + x;
}

void bb_pixel(i32 x, i32 y, u32 c) {
    if (x < 0 || y < 0 || x >= (i32)fb.width || y >= (i32)fb.height) return;
    *bb_at(x, y) = c;
}

void bb_fill_rect(i32 x, i32 y, i32 w, i32 h, u32 c) {
    i32 x0 = x < 0 ? 0 : x, y0 = y < 0 ? 0 : y;
    i32 x1 = x + w > (i32)fb.width ? (i32)fb.width : x + w;
    i32 y1 = y + h > (i32)fb.height ? (i32)fb.height : y + h;
    if (x1 <= x0 || y1 <= y0) return;
    for (i32 yy = y0; yy < y1; yy++) {
        u32 *row = bb_at(x0, yy);
        for (i32 xx = x0; xx < x1; xx++) *row++ = c;
    }
}

void bb_rect(i32 x, i32 y, i32 w, i32 h, u32 c) {
    bb_fill_rect(x, y, w, 1, c);
    bb_fill_rect(x, y + h - 1, w, 1, c);
    bb_fill_rect(x, y, 1, h, c);
    bb_fill_rect(x + w - 1, y, 1, h, c);
}

void bb_fill(u32 c) {
    bb_fill_rect(0, 0, (i32)fb.width, (i32)fb.height, c);
}

/* glifo de font.c: 16 bytes, bit 7 = píxel más a la izquierda */
extern const unsigned char font8x16[95][16];

static void bb_glyph(i32 x, i32 y, u8 ch, u32 fg, u32 bg) {
    if (ch < 32 || ch > 126) return;
    const u8 *g = font8x16[ch - 32];
    for (i32 row = 0; row < 16; row++) {
        u8 bits = g[row];
        u32 *line = bb_at(x, y + row);
        for (i32 col = 0; col < 8; col++) {
            line[col] = (bits & (0x80u >> col)) ? fg : bg;
        }
    }
}

void bb_char(i32 x, i32 y, char c, u32 fg, u32 bg) {
    bb_glyph(x, y, (u8)c, fg, bg);
}

void bb_text(i32 x, i32 y, const char *s, u32 fg, u32 bg) {
    while (*s) {
        bb_glyph(x, y, (u8)*s, fg, bg);
        x += FONT_W;
        s++;
    }
}

/* glifo con fondo transparente (UI sobre superficies ya pintadas) */
static void bb_glyph_t(i32 x, i32 y, u8 ch, u32 fg) {
    if (ch < 32 || ch > 126) return;
    const u8 *g = font8x16[ch - 32];
    for (i32 row = 0; row < 16; row++) {
        u8 bits = g[row];
        u32 *line = bb_at(x, y + row);
        for (i32 col = 0; col < 8; col++) {
            if (bits & (0x80u >> col)) line[col] = fg;
        }
    }
}

void bb_text_t(i32 x, i32 y, const char *s, u32 fg) {
    while (*s) {
        bb_glyph_t(x, y, (u8)*s, fg);
        x += FONT_W;
        s++;
    }
}

void fb_blit_backbuffer(void) {
    if (!backbuffer) return;
    u32 *src = backbuffer;
    if (fb.bpp >= 24) {
        for (u32 y = 0; y < fb.height; y++) {
            u32 *dst = fb_at(0, (i32)y);
            memcpy(dst, src, (size_t)fb.width * 4);
            src += fb.width;
        }
    } else {
        for (u32 y = 0; y < fb.height; y++) {
            u16 *dst = (u16 *)((u8 *)(u64)fb.paddr + (u64)y * fb.pitch);
            for (u32 x = 0; x < fb.width; x++) dst[x] = rgb565(src[x]);
            src += fb.width;
        }
    }
}
