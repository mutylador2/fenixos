/* FenixOS — pci.c: enumeración del bus PCI (v1.2)
 *
 * Acceso al espacio de configuración por los puertos 0xCF8/0xCFC.
 * Escanea los buses 0-2 en función 0 (suficiente para QEMU/VirtualBox)
 * y guarda hasta 16 dispositivos con sus BAR para los drivers
 * (e1000, controladoras USB...). */
#include "fenixos.h"

#define PCI_ADDR_PORT 0xCF8
#define PCI_DATA_PORT 0xCFC

#define MAX_PCI_DEVICES 16
static PciDev pci_devices[MAX_PCI_DEVICES];
static int pci_dev_count = 0;

static u32 pci_config_read(u8 bus, u8 dev, u8 func, u8 offset) {
    u32 addr = 0x80000000u
             | ((u32)bus << 16)
             | ((u32)dev << 11)
             | ((u32)func << 8)
             | (offset & 0xFC);
    outl(PCI_ADDR_PORT, addr);
    return inl(PCI_DATA_PORT);
}

static void pci_config_write(u8 bus, u8 dev, u8 func, u8 offset, u32 val) {
    u32 addr = 0x80000000u
             | ((u32)bus << 16)
             | ((u32)dev << 11)
             | ((u32)func << 8)
             | (offset & 0xFC);
    outl(PCI_ADDR_PORT, addr);
    outl(PCI_DATA_PORT, val);
}

static u16 pci_read16(u8 bus, u8 dev, u8 func, u8 offset) {
    u32 v = pci_config_read(bus, dev, func, offset);
    return (u16)((v >> ((offset & 2) * 8)) & 0xFFFF);
}

static void pci_add_device(u8 bus, u8 dev, u8 func) {
    if (pci_dev_count >= MAX_PCI_DEVICES) return;
    PciDev *d = &pci_devices[pci_dev_count];
    u32 id = pci_config_read(bus, dev, func, 0x00);
    u32 class = pci_config_read(bus, dev, func, 0x08);
    d->bus = bus; d->dev = dev; d->func = func;
    d->vendor = (u16)(id & 0xFFFF);
    d->device = (u16)(id >> 16);
    d->class_code = (u8)(class >> 24);
    d->subclass = (u8)(class >> 16);
    d->prog_if = (u8)(class >> 8);
    for (int i = 0; i < 6; i++)
        d->bar[i] = pci_config_read(bus, dev, func, (u8)(0x10 + i * 4));
    u32 irq = pci_config_read(bus, dev, func, 0x3C);
    d->irq_line = (u8)(irq & 0xFF);
    d->irq_pin = (u8)((irq >> 8) & 0xFF);
    pci_dev_count++;

    /* habilitar espacio de memoria y maestro de bus para el dispositivo */
    u32 cmd = pci_config_read(bus, dev, func, 0x04);
    cmd |= 0x02 | 0x04;                     /* MEM | BUS MASTER */
    cmd &= ~(u32)0x400;                     /* desactivar decodificación VGA */
    pci_config_write(bus, dev, func, 0x04, cmd);
}

static const char *pci_class_name(u8 c) {
    switch (c) {
    case 0x00: return "otro";
    case 0x01: return "almacenamiento";
    case 0x02: return "red";
    case 0x03: return "video";
    case 0x04: return "multimedia";
    case 0x06: return "puente";
    case 0x0C: return "serial/USB";
    default:   return "clase?";
    }
}

const char *pci_class_desc(u8 c) { return pci_class_name(c); }

int pci_init(void) {
    pci_dev_count = 0;
    for (u8 bus = 0; bus < 3; bus++) {
        for (u8 dev = 0; dev < 32; dev++) {
            u16 vend = pci_read16(bus, dev, 0, 0x00);
            if (vend == 0xFFFF) continue;
            pci_add_device(bus, dev, 0);
        }
    }
    char tmp[64];
    ksnprintf(tmp, sizeof(tmp), "PCI: %d dispositivos en buses 0-2", pci_dev_count);
    klog("PCI", tmp);
    return pci_dev_count;
}

int pci_count(void) { return pci_dev_count; }
PciDev *pci_get(int idx) {
    if (idx < 0 || idx >= pci_dev_count) return NULLP;
    return &pci_devices[idx];
}
PciDev *pci_find(u16 vendor, u16 device) {
    for (int i = 0; i < pci_dev_count; i++)
        if (pci_devices[i].vendor == vendor && pci_devices[i].device == device)
            return &pci_devices[i];
    return NULLP;
}
