/* FenixOS — rtc.c: reloj de tiempo real CMOS (puertos 0x70/0x71) */
#include "fenixos.h"

volatile u32 rtc_sec, rtc_min, rtc_hour, rtc_day, rtc_month, rtc_year, rtc_wday;

static const char *months[12] = {
    "ene", "feb", "mar", "abr", "may", "jun",
    "jul", "ago", "sep", "oct", "nov", "dic"
};
static const char *days[7] = {
    "dom", "lun", "mar", "mie", "jue", "vie", "sab"
};

static u8 cmos_read(u8 reg) {
    outb(0x70, reg);
    return inb(0x71);
}

static int update_in_progress(void) {
    outb(0x70, 0x0A);
    return inb(0x71) & 0x80;
}

/* día de la semana (algoritmo de Sakamoto) */
static u32 day_of_week(u32 y, u32 m, u32 d) {
    static const u32 t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
    if (m < 3) y -= 1;
    return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
}

void rtc_read_datetime(void) {
    while (update_in_progress()) ;
    u8 sec = cmos_read(0x00);
    u8 min = cmos_read(0x02);
    u8 hour = cmos_read(0x04);
    u8 day = cmos_read(0x07);
    u8 month = cmos_read(0x08);
    u8 year = cmos_read(0x09);
    u8 regb = cmos_read(0x0B);

    if (!(regb & 0x04)) {                     /* valores en BCD */
        sec = (u8)((sec & 0x0F) + (sec >> 4) * 10);
        min = (u8)((min & 0x0F) + (min >> 4) * 10);
        hour = (u8)(((hour & 0x0F) + ((hour & 0x70) >> 4) * 10) | (hour & 0x80));
        day = (u8)((day & 0x0F) + (day >> 4) * 10);
        month = (u8)((month & 0x0F) + (month >> 4) * 10);
        year = (u8)((year & 0x0F) + (year >> 4) * 10);
    }
    if (!(regb & 0x02) && (hour & 0x80))      /* formato 12h -> 24h */
        hour = (u8)(((hour & 0x7F) + 12) % 24);

    rtc_sec = sec;
    rtc_min = min;
    rtc_hour = hour & 0x3F;
    rtc_day = day;
    rtc_month = month;
    rtc_year = 2000 + year;
    rtc_wday = day_of_week(rtc_year, rtc_month, rtc_day);
}

const char *rtc_month_name(u32 m) {
    return (m >= 1 && m <= 12) ? months[m - 1] : "???";
}

const char *rtc_day_name(u32 wd) {
    return (wd <= 6) ? days[wd] : "???";
}
