/* FenixOS — win.c: FenixCompat, análisis de ejecutables MZ/PE (v1.2)
 *
 * "Compatibilidad básica con apps de Windows": FenixOS no ejecuta binarios
 * PE/EXE de Windows (requeriría una capa de traducción de syscalls enorme),
 * pero FenixCompat DETECTA, VALIDA y CLASIFICA los archivos .exe/.dll:
 *   - cabecera DOS (MZ), offset de la cabecera PE
 *   - máquina destino (i386, x64, ARM64), nº de secciones, timestamp
 *   - subsistema (GUI o consola), punto de entrada, image base
 * y lo comunica con claridad. La ruta futura sería un emulador x86
 * (bochs-like) + winelib: documentado en el README.
 *
 * Incluye muestra.exe (MZ/PE mínimo válido) para probar la orden. */
#include "fenixos.h"

/* muestra.exe: MZ + PE mínimo (PE32+ x64, subsistema consola) */
static const u8 sample_exe[] = {
    'M','Z', 0x00,0x00, 0,0,0,0, 0,0,0,0, 0,0,0,0,      /* firma DOS */
    0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
    0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,                 /* 0x20 */
    0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
    0,0,0,0, 0,0,0,0, 0x00,0x00,0x00,0x00,               /* 0x30-0x3B */
    0x40,0x00,0x00,0x00,                                 /* 0x3C: e_lfanew = 0x40 */
    'P','E',0x00,0x00,                                   /* firma PE */
    0x64,0x86,                                           /* máquina: x86-64 */
    0x01,0x00,                                           /* 1 sección */
    0x00,0x00,0x00,0x00,                                 /* timestamp 0 */
    0,0,0,0, 0,0,0,0,                                    /* símbolos */
    0xF0,0x00,                                           /* opcional: 240 B */
    0x22,0x00,                                           /* características */
    0x0B,0x02,                                           /* opt magic: PE32+ */
    0x14,0x00,                                           /* linker 1.20 */
    0x00,0x10,0x00,0x00,                                 /* size of code */
    0,0,0,0, 0,0,0,0, 0,0,0,0,                           /* entry/init/term */
    0x00,0x00,0x10,0x00,                                 /* entry point RVA */
    0,0,0,0,
    0x00,0x00,0x40,0x00,                                 /* image base 0x400000 */
    0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0,
    0x10,0x00,0x00,0x00,                                 /* alineación secciones */
    0,0,0,0, 0,0,0,0, 0x06,0x00,                         /* versión subsistema 6 */
    0x03,0x00,                                           /* SUBSISTEMA: consola */
    0x04,0x00,0x00,0x00,                                 /* stack reserve 4KB */
    0x04,0x00,0x00,0x00,                                 /* stack commit */
    0x04,0x00,0x00,0x00,                                 /* heap reserve */
    0x04,0x00,0x00,0x00,                                 /* heap commit */
    0,0,0,0,                                             /* loader flags */
    0x10,0x00,0x00,0x00,                                 /* NumberOfRvaAndSizes */
    /* directorios de datos (16 x 8) para completar la cabecera opcional */
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0,0,0,0,0,
};

void win_sample_install(void) {
    if (!ramfs_exists("muestra.exe"))
        ramfs_write("muestra.exe", (const char *)sample_exe, sizeof(sample_exe));
}

/* salidas en la terminal (mismo modelo de celdas que shell/fx) */
#define WC_ATR_WHITE  0
#define WC_ATR_ACCENT 6
#define WC_ATR_GRAY   5
#define WC_ATR_YELLOW 3
#define WC_ATR_RED    4

static void wc_scroll(Window *w) {
    memcpy(w->cells, w->cells + w->cols, (u32)(w->cols * (w->rows - 1)) * sizeof(u16));
    u16 *last = w->cells + w->cols * (w->rows - 1);
    for (int i = 0; i < w->cols; i++) last[i] = ' ';
    w->ccy = w->rows - 1;
}
static void wc_nl(Window *w) {
    w->ccx = 0;
    w->ccy++;
    if (w->ccy >= w->rows) wc_scroll(w);
}
static void wc_puts(Window *w, const char *s, u8 attr) {
    while (*s) {
        if (w->ccy >= w->rows) wc_scroll(w);
        if (*s == '\n') { wc_nl(w); s++; continue; }
        w->cells[w->ccy * w->cols + w->ccx] = (u16)(u8)*s | ((u16)attr << 8);
        w->ccx++;
        if (w->ccx >= w->cols) wc_nl(w);
        s++;
    }
}
static void wc_printf(Window *w, u8 attr, const char *fmt, ...) {
    char buf[320];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    wc_puts(w, buf, attr);
}

static const char *machine_name(u16 m) {
    switch (m) {
    case 0x014C: return "i386 (x86 32-bit)";
    case 0x8664: return "x86-64 (x64)";
    case 0x01C0: return "ARM";
    case 0xAA64: return "ARM64";
    default:     return "desconocida";
    }
}

static const char *subsystem_name(u16 s) {
    switch (s) {
    case 2:  return "GUI (ventanas)";
    case 3:  return "consola (texto)";
    case 1:  return "nativo (driver)";
    case 9:  return "CE";
    default: return "otro";
    }
}

int win_analyze(const char *fname, Window *w) {
    static u8 data[RAMFS_BUF];
    int n = ramfs_read(fname, (char *)data, RAMFS_BUF);
    if (n < 0) return -1;
    if (n < 64 || data[0] != 'M' || data[1] != 'Z') {
        if (n >= 4 && data[0] == 0x7F && data[1] == 'E' && data[2] == 'L' && data[3] == 'F') {
            wc_printf(w, WC_ATR_YELLOW, "'%s' es ELF (formato de Linux): FenixCompat no lo ejecuta\n", fname);
            return 0;
        }
        return -2;
    }

    u32 lfanew = (u32)data[0x3C] | ((u32)data[0x3D] << 8)
               | ((u32)data[0x3E] << 16) | ((u32)data[0x3F] << 24);
    klogf(LOG_INFO, "COMPAT", "analisis de '%s' (%d bytes)", fname, n);
    wc_printf(w, WC_ATR_ACCENT, "FenixCompat: analisis de '%s' (%d bytes)\n", fname, n);
    wc_printf(w, WC_ATR_WHITE, "  cabecera DOS : valida (MZ), PE en offset 0x%X\n", lfanew);
    if (lfanew + 24 > (u32)n || data[lfanew] != 'P' || data[lfanew + 1] != 'E'
        || data[lfanew + 2] != 0 || data[lfanew + 3] != 0) {
        wc_puts(w, "  tipo         : ejecutable DOS/MBR sin cabecera PE\n", WC_ATR_YELLOW);
        wc_puts(w, "  veredicto    : no ejecutable en FenixOS (solo analisis)\n", WC_ATR_GRAY);
        return 0;
    }
    const u8 *coff = data + lfanew + 4;
    u16 machine = (u16)(coff[0] | (coff[1] << 8));
    u16 nsec    = (u16)(coff[2] | (coff[3] << 8));
    u16 optsize = (u16)(coff[20] | (coff[21] << 8));
    wc_printf(w, WC_ATR_WHITE, "  maquina      : %s\n", machine_name(machine));
    wc_printf(w, WC_ATR_WHITE, "  secciones    : %u, cabecera opcional %u B\n", nsec, optsize);
    if (optsize >= 70 && lfanew + 24 + 70 <= (u32)n) {
        const u8 *opt = coff + 20;
        u16 magic = (u16)(opt[0] | (opt[1] << 8));
        u32 entry = (u32)opt[16] | ((u32)opt[17] << 8) | ((u32)opt[18] << 16) | ((u32)opt[19] << 24);
        u32 base;
        if (magic == 0x20B) base = (u32)opt[24] | ((u32)opt[25] << 8) | ((u32)opt[26] << 16) | ((u32)opt[27] << 24);
        else base = (u32)opt[28] | ((u32)opt[29] << 8) | ((u32)opt[30] << 16) | ((u32)opt[31] << 24);
        u16 subsys = (u16)(opt[68] | (opt[69] << 8));
        wc_printf(w, WC_ATR_WHITE, "  formato      : %s\n",
                  (magic == 0x20B) ? "PE32+ (64-bit)" :
                  (magic == 0x10B) ? "PE32 (32-bit)" : "desconocido");
        wc_printf(w, WC_ATR_WHITE, "  entrada      : RVA 0x%X, base 0x%X\n", entry, base);
        wc_printf(w, WC_ATR_WHITE, "  subsistema   : %s\n", subsystem_name(subsys));
    }
    wc_puts(w, "  veredicto    : ejecutable Windows reconocido\n", WC_ATR_YELLOW);
    wc_puts(w, "  FenixOS no lo ejecuta: haria falta una capa Win32 completa.\n", WC_ATR_GRAY);
    wc_puts(w, "  Plan (README 10): emulador x86 + traduccion de syscalls.\n", WC_ATR_GRAY);
    return 0;
}
