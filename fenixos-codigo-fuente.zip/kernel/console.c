/* FenixOS — console.c: terminal de arranque sobre framebuffer.
 * Se usa antes de que arranque el subsistema gráfico. */
#include "fenixos.h"

static int cx = 0, cy = 0;
static u32 con_fg = 0xFFD8D8D8, con_bg = 0xFF10141A;

void console_init(void) {
    cx = 0;
    cy = 0;
    console_clear();
}

void console_clear(void) {
    fb_fill(con_bg);
    cx = 0;
    cy = 0;
}

static void scroll(void) {
    u32 rowbytes = (u32)fb.width * 4;
    u32 rows = fb.height / FONT_H;
    for (u32 r = 1; r < rows; r++) {
        memcpy((void *)((u64)fb.paddr + (u64)(r - 1) * FONT_H * fb.pitch),
               (const void *)((u64)fb.paddr + (u64)r * FONT_H * fb.pitch),
               rowbytes * FONT_H);
    }
    fb_fill_rect(0, (i32)((rows - 1) * FONT_H), (i32)fb.width, FONT_H, con_bg);
}

void console_putc(char c) {
    if (!fb.bpp) return;
    if (c == '\n') { cx = 0; cy++; }
    else if (c == '\r') { cx = 0; }
    else {
        fb_char(cx * FONT_W, cy * FONT_H, c, con_fg, con_bg);
        cx++;
        if (cx >= (i32)(fb.width / FONT_W)) { cx = 0; cy++; }
    }
    if (cy >= (i32)(fb.height / FONT_H)) { scroll(); cy = (i32)(fb.height / FONT_H) - 1; }
}

void console_puts(const char *s) {
    while (*s) console_putc(*s++);
}
