/* FenixOS — fx.c: FenixScript, el lenguaje de extensiones del sistema (v1.2)
 *
 * Permite PROGRAMAR DENTRO de FenixOS: los usuarios escriben scripts .fx
 * en el editor o con 'escribir', los guardan en el RAMFS y los ejecutan
 * con 'fx script.fx'. Cada archivo .fx es una "extensión" que cualquier
 * otro usuario puede compartir (compatibilidad con extensiones ajenas).
 *
 * Sintaxis (BASIC-like, líneas numeradas):
 *   10 #ext: autor | version | descripcion   (1ª línea, metadatos)
 *   20 PRINT Hola $nombre!                   (imprime; $var se sustituye)
 *   30 LET x = 5                             (asignación numérica)
 *   40 LET y = x * 2 + 1                     (expresión: + - x / )
 *   50 IF x > 3 GOTO 80                      (salto condicional)
 *   60 GOTO 20                               (salto)
 *   70 EXEC echo hola desde el script        (orden de FenixShell)
 *   80 FIN                                   (fin del script)
 *
 * Límite de seguridad: 5000 instrucciones (evita bucles infinitos). */
#include "fenixos.h"

#define FX_MAX_LINES 64
#define FX_MAX_VARS  8
#define FX_VAR_NAME  8
#define FX_MAX_STEPS 5000

typedef struct {
    u32 num;                      /* número de línea */
    char text[112];               /* resto de la línea */
} FxLine;

typedef struct {
    char name[FX_VAR_NAME];
    i64 value;
} FxVar;

static FxVar vars[FX_MAX_VARS];
static int var_count = 0;
static Window *fxw = NULLP;       /* ventana de salida (la terminal) */

/* colores del shell (índices idénticos a shell.c) */
#define FX_ATR_WHITE   0
#define FX_ATR_ACCENT  6
#define FX_ATR_YELLOW  3
#define FX_ATR_RED     4

/* --- salida en la ventana terminal (mismo modelo de celdas) --- */
static void fx_scroll(Window *w) {
    memcpy(w->cells, w->cells + w->cols, (u32)(w->cols * (w->rows - 1)) * sizeof(u16));
    u16 *last = w->cells + w->cols * (w->rows - 1);
    for (int i = 0; i < w->cols; i++) last[i] = ' ';
    w->ccy = w->rows - 1;
}

static void fx_nl(Window *w) {
    w->ccx = 0;
    w->ccy++;
    if (w->ccy >= w->rows) fx_scroll(w);
}

static void fx_putc(Window *w, char c, u8 attr) {
    if (c == '\n') { fx_nl(w); return; }
    w->cells[w->ccy * w->cols + w->ccx] = (u16)(u8)c | ((u16)attr << 8);
    w->ccx++;
    if (w->ccx >= w->cols) fx_nl(w);
}

static void fx_puts(Window *w, const char *s, u8 attr) {
    while (*s) fx_putc(w, *s++, attr);
}

static void fx_printf_attr(u8 attr, const char *fmt, ...) {
    char buf[320];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (fxw) fx_puts(fxw, buf, attr);
}

/* --- variables --- */
static FxVar *var_find(const char *name) {
    for (int i = 0; i < var_count; i++)
        if (!strcmp(vars[i].name, name)) return &vars[i];
    return NULLP;
}

static FxVar *var_create(const char *name) {
    if (var_count >= FX_MAX_VARS) return NULLP;
    FxVar *v = &vars[var_count++];
    strncpy(v->name, name, FX_VAR_NAME - 1);
    v->name[FX_VAR_NAME - 1] = 0;
    v->value = 0;
    return v;
}

/* término: número | $var | var  (devuelve 1 ok) */
static int fx_term(const char **ps, i64 *out) {
    const char *s = *ps;
    while (*s == ' ') s++;
    if (*s == '$') s++;                   /* $opcional: n y $n equivalen */
    if ((*s >= 'a' && *s <= 'z') || (*s >= 'A' && *s <= 'Z')) {
        char name[FX_VAR_NAME];
        u32 n = 0;
        while ((*s >= 'a' && *s <= 'z') || (*s >= 'A' && *s <= 'Z') ||
               (*s >= '0' && *s <= '9') || *s == '_') {
            if (n < FX_VAR_NAME - 1) name[n++] = *s;
            s++;
        }
        name[n] = 0;
        FxVar *v = var_find(name);
        *out = v ? v->value : 0;
        *ps = s;
        return 1;
    }
    if (*s == '-' || (*s >= '0' && *s <= '9')) {
        int neg = 0;
        if (*s == '-') { neg = 1; s++; }
        i64 v = 0;
        while (*s >= '0' && *s <= '9') v = v * 10 + (*s++ - '0');
        *out = neg ? -v : v;
        *ps = s;
        return 1;
    }
    return 0;
}

/* expresión: term (op term)* — de izquierda a derecha, con encadenado */
static int fx_expr(const char **ps, i64 *out) {
    i64 a;
    if (!fx_term(ps, &a)) return 0;
    const char *s = *ps;
    for (;;) {
        while (*s == ' ') s++;
        if (*s != '+' && *s != '-' && *s != 'x' && *s != '*' && *s != '/') break;
        char op = (*s == '*') ? 'x' : *s;
        const char *next = s + 1;
        i64 b;
        if (!fx_term(&next, &b)) break;   /* operador sin término: parar */
        switch (op) {
        case '+': a += b; break;
        case '-': a -= b; break;
        case 'x': a *= b; break;
        case '/': if (b) a /= b; else a = 0; break;
        }
        s = next;
    }
    *ps = s;
    *out = a;
    return 1;
}

/* PRINT con sustitución de $variables */
static void fx_print(const char *text) {
    char buf[200];
    u32 n = 0;
    for (const char *s = text; *s && n < sizeof(buf) - 2; s++) {
        if (*s == '$') {
            s++;
            char name[FX_VAR_NAME];
            u32 k = 0;
            while ((*s >= 'a' && *s <= 'z') || (*s >= 'A' && *s <= 'Z') ||
                   (*s >= '0' && *s <= '9') || *s == '_') {
                if (k < FX_VAR_NAME - 1) name[k++] = *s;
                s++;
            }
            s--;                          /* el bucle exterior avanza */
            name[k] = 0;
            FxVar *v = var_find(name);
            if (v) {
                char num[24];
                ksnprintf(num, sizeof(num), "%ld", v->value);
                for (char *p = num; *p && n < sizeof(buf) - 2; p++) buf[n++] = *p;
            }
            continue;
        }
        buf[n++] = *s;
    }
    buf[n] = 0;
    fx_printf_attr(FX_ATR_WHITE, "%s\n", buf);
}

/* comparaciones del IF */
static int fx_compare(i64 a, const char *op, i64 b) {
    if (!strncmp(op, "==", 2)) return a == b;
    if (!strncmp(op, "!=", 2)) return a != b;
    if (!strncmp(op, "<=", 2)) return a <= b;
    if (!strncmp(op, ">=", 2)) return a >= b;
    if (op[0] == '<') return a < b;
    if (op[0] == '>') return a > b;
    return 0;
}

/* ---------------- metadatos de extensiones ---------------- */
static int fx_is_script(const char *name) {
    u32 l = strlen(name);
    return l > 3 && name[l - 3] == '.' && name[l - 2] == 'f' && name[l - 1] == 'x';
}

int fx_list(int idx, const char **name, const char **meta) {
    /* recorre el RAMFS buscando scripts; devuelve nombre + metadatos */
    const char *fname;
    u32 size;
    int seen = 0;
    static char metabuf[8][96];
    static int metabuf_init = 0;
    for (int i = 0; i < ramfs_slots(); i++) {
        if (!ramfs_get(i, &fname, &size)) continue;
        if (!fx_is_script(fname)) continue;
        if (idx == seen) {
            if (name) *name = fname;
            if (meta) {
                int slot = idx % 8;
                if (!metabuf_init) { memset(metabuf, 0, sizeof(metabuf)); metabuf_init = 1; }
                char head[96];
                head[0] = 0;
                int n = ramfs_read(fname, head, sizeof(head) - 1);
                if (n > 0) head[n] = 0;
                char *m = head;
                if (!strncmp(m, "#ext:", 5)) {
                    m += 5;
                    while (*m == ' ') m++;
                    char *nl = m;
                    while (*nl && *nl != '\n') nl++;
                    *nl = 0;
                    for (char *p = m; *p; p++) if (*p == '|') *p = '-';
                    ksnprintf(metabuf[slot], sizeof(metabuf[0]), "%s", m);
                } else {
                    ksnprintf(metabuf[slot], sizeof(metabuf[0]), "(sin metadatos)");
                }
                *meta = metabuf[slot];
            }
            return 1;
        }
        seen++;
    }
    return 0;
}

/* ---------------- intérprete ---------------- */
int fx_run(const char *fname, Window *out) {
    static char src[RAMFS_BUF + 8];
    int len = ramfs_read(fname, src, RAMFS_BUF);
    if (len < 0) return -1;

    /* trocear en líneas numeradas */
    FxLine lines[FX_MAX_LINES];
    int nlines = 0;
    char *p = src;
    while (*p && nlines < FX_MAX_LINES) {
        while (*p == ' ' || *p == '\r' || *p == '\n') p++;
        if (!*p) break;
        u32 num = 0;
        int hasnum = 0;
        while (*p >= '0' && *p <= '9') { num = num * 10 + (u32)(*p++ - '0'); hasnum = 1; }
        while (*p == ' ') p++;
        if (!hasnum) {                  /* línea sin número: saltarla */
            while (*p && *p != '\n') p++;
            continue;
        }
        char *start = p;
        while (*p && *p != '\n') p++;
        u32 tlen = (u32)(p - start);
        if (tlen > sizeof(lines[0].text) - 1) tlen = sizeof(lines[0].text) - 1;
        memcpy(lines[nlines].text, start, tlen);
        lines[nlines].text[tlen] = 0;
        lines[nlines].num = num;
        nlines++;
        if (p) p++;
    }
    if (!nlines) return -2;

    fxw = out ? out : gui_shell_window();
    var_count = 0;
    int pc = 0;
    int steps = 0;
    int finished = -1;                  /* -1 = sigue */

    while (pc >= 0 && pc < nlines && finished < 0) {
        if (++steps > FX_MAX_STEPS) {
            fx_printf_attr(FX_ATR_YELLOW, "[fx] limite de %d pasos alcanzado\n", FX_MAX_STEPS);
            return -3;
        }
        FxLine *L = &lines[pc];
        char *t = L->text;
        while (*t == ' ') t++;

        if (*t == '#') { pc++; continue; }                  /* comentario */
        if (!strncasecmp_fenix(t, "FIN", 3)) { finished = pc; break; }

        if (!strncasecmp_fenix(t, "PRINT", 5)) {
            fx_print(t + 5);
        } else if (!strncasecmp_fenix(t, "LET", 3)) {
            char *s = t + 3;
            while (*s == ' ') s++;
            char name[FX_VAR_NAME];
            u32 n = 0;
            while ((*s >= 'a' && *s <= 'z') || (*s >= 'A' && *s <= 'Z') ||
                   (*s >= '0' && *s <= '9') || *s == '_') {
                if (n < FX_VAR_NAME - 1) name[n++] = *s;
                s++;
            }
            name[n] = 0;
            while (*s == ' ') s++;
            if (*s == '=') {
                s++;
                i64 v = 0;
                if (fx_expr((const char **)&s, &v)) {
                    FxVar *v2 = var_find(name);
                    if (!v2) v2 = var_create(name);
                    if (v2) v2->value = v;
                    else fx_printf_attr(FX_ATR_RED, "[fx] sin ranuras de variables\n");
                } else {
                    fx_printf_attr(FX_ATR_RED, "[fx] linea %u: expresion invalida\n", L->num);
                }
            } else {
                fx_printf_attr(FX_ATR_RED, "[fx] linea %u: falta '=' en LET\n", L->num);
            }
        } else if (!strncasecmp_fenix(t, "IF", 2)) {
            /* IF <expr> <op> <expr> GOTO <n> */
            char *s = t + 2;
            i64 a = 0, b = 0;
            if (fx_expr((const char **)&s, &a)) {
                while (*s == ' ') s++;
                char op[3] = { 0, 0, 0 };
                if ((*s == '=' || *s == '!' || *s == '<' || *s == '>') && s[1] == '=') {
                    op[0] = *s; op[1] = '=';
                    s += 2;
                } else if (*s == '<' || *s == '>') {
                    op[0] = *s++;
                } else {
                    fx_printf_attr(FX_ATR_RED, "[fx] linea %u: operador invalido\n", L->num);
                    pc++;
                    continue;
                }
                if (fx_expr((const char **)&s, &b)) {
                    while (*s == ' ') s++;
                    if (!strncasecmp_fenix(s, "GOTO", 4)) {
                        s += 4;
                        u32 target = 0;
                        while (*s == ' ') s++;
                        while (*s >= '0' && *s <= '9') target = target * 10 + (u32)(*s++ - '0');
                        if (fx_compare(a, op, b)) {
                            int found = -1;
                            for (int i = 0; i < nlines; i++)
                                if (lines[i].num == target) { found = i; break; }
                            if (found < 0) {
                                fx_printf_attr(FX_ATR_RED, "[fx] linea %u: destino %u inexistente\n", L->num, target);
                                found = pc + 1;
                            }
                            pc = found;
                            continue;
                        }
                    }
                }
            }
        } else if (!strncasecmp_fenix(t, "GOTO", 4)) {
            u32 target = 0;
            char *s = t + 4;
            while (*s == ' ') s++;
            while (*s >= '0' && *s <= '9') target = target * 10 + (u32)(*s++ - '0');
            int found = -1;
            for (int i = 0; i < nlines; i++)
                if (lines[i].num == target) { found = i; break; }
            if (found < 0) {
                fx_printf_attr(FX_ATR_RED, "[fx] linea %u: destino %u inexistente\n", L->num, target);
                pc++;
            } else {
                pc = found;
            }
            continue;
        } else if (!strncasecmp_fenix(t, "EXEC", 4)) {
            char *cmd = t + 4;
            while (*cmd == ' ') cmd++;
            if (*cmd) shell_exec_hook(cmd);
        } else {
            fx_printf_attr(FX_ATR_RED, "[fx] linea %u: instruccion desconocida\n", L->num);
        }
        pc++;
    }
    fxw = NULLP;
    return 0;
}
