/* FenixOS — power.c: reinicio (controlador 8042) y apagado ACPI (intentos) */
#include "fenixos.h"

void power_reboot(void) {
    cli_irq();
    /* esperar a que el búfer de salida del 8042 esté vacío */
    for (int i = 0; i < 100000 && (inb(0x64) & 1); i++) inb(0x60);
    for (int i = 0; i < 100000 && (inb(0x64) & 2); i++) ;
    outb(0x64, 0xFE);                  /* pulso de reset */
    /* fallback: reinicio por triple fallo */
    struct { u16 limit; u64 base; } nullidt = { 0, 0 };
    __asm__ volatile("lidt %0; int3" :: "m"(nullidt));
    for (;;) hlt_cpu();
}

void power_shutdown(void) {
    /* apagado ACPI QEMU/Bochs/VBox: puertos PM1a conocidos, SLP_EN|SLP_TYP(0) */
    klog("POWER", "apagado ACPI solicitado");
    outw(0x604, 0x2000);               /* QEMU moderno */
    outw(0xB004, 0x2000);              /* Bochs / QEMU antiguo */
    outw(0x400, 0x2000);               /* VirtualBox estilo Bochs */
    outw(0x600, 0x2000);               /* algunos builds recientes */
    for (int i = 0; i < 3000000; i++) io_wait();
    /* si seguimos vivos, avisar */
    klog("POWER", "el equipo no se apagó; usa Machine > ACPI Shutdown");
}
