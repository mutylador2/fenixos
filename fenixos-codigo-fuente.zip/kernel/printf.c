/* FenixOS — printf.c: mini vsnprintf (enteros, cadenas; sin floats) */
#include "fenixos.h"

static void put(char *buf, size_t size, size_t *i, char c) {
    if (*i + 1 < size) buf[*i] = c;
    (*i)++;
}

static void puts_n(char *buf, size_t size, size_t *i, const char *s) {
    while (*s) put(buf, size, i, *s++);
}

static void putu(char *buf, size_t size, size_t *i, u64 v, u32 base, int upper, int width, char pad) {
    char tmp[24];
    const char *dig = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    int n = 0;
    if (v == 0) tmp[n++] = '0';
    while (v) { tmp[n++] = dig[v % base]; v /= base; }
    int total = (width > n) ? width : n;
    for (int k = n; k < total; k++) put(buf, size, i, pad);
    while (n--) put(buf, size, i, tmp[n]);
}

static void putd(char *buf, size_t size, size_t *i, i64 v, int width, char pad) {
    if (v < 0) {
        put(buf, size, i, '-');
        if (width > 0) width--;
        putu(buf, size, i, (u64)(-(v + 1)) + 1, 10, 0, width, pad);
    } else {
        putu(buf, size, i, (u64)v, 10, 0, width, pad);
    }
}

int kvsnprintf(char *buf, size_t size, const char *fmt, va_list ap) {
    size_t i = 0;
    if (size) buf[0] = 0;
    for (; *fmt; fmt++) {
        if (*fmt != '%') { put(buf, size, &i, *fmt); continue; }
        fmt++;
        /* banderas y ancho: %-[0-9]s / %[0-9]d ... */
        int left = 0, width = 0;
        char pad = ' ';
        if (*fmt == '-') { left = 1; fmt++; }
        if (*fmt == '0') { pad = '0'; fmt++; }
        while (*fmt >= '0' && *fmt <= '9') { width = width * 10 + (*fmt - '0'); fmt++; }
        switch (*fmt) {
        case 's': {
            const char *sv = va_arg(ap, const char *);
            if (!sv) sv = "(null)";
            int len = (int)strlen(sv);
            if (!left) for (int k = len; k < width; k++) put(buf, size, &i, ' ');
            puts_n(buf, size, &i, sv);
            if (left) for (int k = len; k < width; k++) put(buf, size, &i, ' ');
            break;
        }
        case 'c': {
            char c = (char)va_arg(ap, int);
            if (!left) for (int k = 1; k < width; k++) put(buf, size, &i, ' ');
            put(buf, size, &i, c);
            if (left) for (int k = 1; k < width; k++) put(buf, size, &i, ' ');
            break;
        }
        case 'd': case 'i': {
            i64 v = va_arg(ap, i32);
            char tmp[16];
            int n = 0, neg = v < 0;
            if (neg) v = -v;
            if (v == 0) tmp[n++] = '0';
            while (v) { tmp[n++] = (char)('0' + (v % 10)); v /= 10; }
            if (neg) tmp[n++] = '-';
            if (!left) for (int k = n; k < width; k++) put(buf, size, &i, pad);
            while (n--) put(buf, size, &i, tmp[n]);
            if (left) for (int k = (int)strlen(tmp); k < width; k++) put(buf, size, &i, ' ');
            break;
        }
        case 'l': {
            fmt++;
            if (*fmt == 'd' || *fmt == 'i') putd(buf, size, &i, va_arg(ap, i64), width, pad);
            else if (*fmt == 'u') putu(buf, size, &i, va_arg(ap, u64), 10, 0, width, pad);
            else if (*fmt == 'x') putu(buf, size, &i, va_arg(ap, u64), 16, 0, width, pad);
            else if (*fmt == 'X') putu(buf, size, &i, va_arg(ap, u64), 16, 1, width, pad);
            else { put(buf, size, &i, '%'); put(buf, size, &i, 'l'); fmt--; }
            break;
        }
        case 'u': putu(buf, size, &i, va_arg(ap, u32), 10, 0, width, pad); break;
        case 'x': putu(buf, size, &i, va_arg(ap, u32), 16, 0, width, pad); break;
        case 'X': putu(buf, size, &i, va_arg(ap, u32), 16, 1, width, pad); break;
        case 'p': {
            puts_n(buf, size, &i, "0x");
            putu(buf, size, &i, (u64)va_arg(ap, void *), 16, 1, 16, '0');
            break;
        }
        case '%': put(buf, size, &i, '%'); break;
        default:  put(buf, size, &i, '%'); put(buf, size, &i, *fmt); break;
        }
    }
    if (i < size) buf[i] = 0;
    else if (size) buf[size - 1] = 0;
    return (int)i;
}

int ksnprintf(char *buf, size_t size, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int r = kvsnprintf(buf, size, fmt, ap);
    va_end(ap);
    return r;
}

void kprintf(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    serial_write(buf);
}
