/* FenixOS — ramfs.c: sistema de archivos en memoria (RAMFS)
 *
 * Subsistema simple de ficheros residente en el monton del kernel.
 * - hasta 16 archivos, nombres de hasta 23 caracteres
 * - hasta 2KB de datos por archivo (reservados al crear)
 * - viene precargado con leeme.txt y notas.txt para que el escritorio
 *   tenga contenido desde el primer arranque
 *
 * Sin permisos ni directorios: es un RAMFS didactico, pero con
 * semantica real de crear/sobrescribir/leer/borrar/listar. */
#include "fenixos.h"

#define RAMFS_MAX_FILES 32
#define RAMFS_NAME_LEN  24
#define RAMFS_FILE_MAX  4096

typedef struct {
    int used;
    char name[RAMFS_NAME_LEN];
    u32 size;
    u8 *data;                    /* RAMFS_FILE_MAX bytes desde kmalloc */
} RamFile;

static RamFile files[RAMFS_MAX_FILES];

/* nombre valido: 1..23 chars imprimibles, sin espacios ni '/' */
static int name_ok(const char *n) {
    if (!n || !*n) return 0;
    u32 len = 0;
    for (const char *p = n; *p; p++, len++) {
        if (*p <= ' ' || *p > 126 || *p == '/') return 0;
    }
    return len < RAMFS_NAME_LEN;
}

static RamFile *find_file(const char *name) {
    for (int i = 0; i < RAMFS_MAX_FILES; i++)
        if (files[i].used && !strcmp(files[i].name, name)) return &files[i];
    return NULLP;
}

void ramfs_init(void) {
    for (int i = 0; i < RAMFS_MAX_FILES; i++) {
        files[i].used = 0;
        files[i].name[0] = 0;
        files[i].size = 0;
        files[i].data = NULLP;
    }
    /* contenido precargado del sistema */
    static const char f_leeme[] =
        "Bienvenido a FenixOS 1.2 \"Horizonte\"\n"
        "-------------------------------------\n"
        "Novedades v1.2: usuarios y roles, registro de eventos,\n"
        "configuracion persistente en disco, red TCP/IP (ping y\n"
        "navegador FenixNav), calculadora y visor graficos, y el\n"
        "lenguaje FenixScript para programar dentro del sistema.\n\n"
        "Cuentas: admin/fenix - usuario/1234 - invitado (sin clave)\n\n"
        "Prueba esto:\n"
        "  ayuda              lista completa de ordenes\n"
        "  login admin fenix  cambia de sesion\n"
        "  ping 10.0.2.2      prueba la red (QEMU/VBox NAT)\n"
        "  nav http://example.com   navegador web integrado\n"
        "  calculadora        abrela y toca sus botones\n"
        "  ext                ver extensiones FenixScript\n"
        "  fx hola.fx         ejecutar una extension\n"
        "  logs               registro de eventos del sistema\n"
        "  config guardar     persistir tu configuracion\n";
    static const char f_notas[] =
        "Mis notas de FenixOS\n"
        "--------------------\n"
        "1. mover ventanas con el raton\n"
        "2. probar el tema vapor\n"
        "3. escuchar 'musica' en el altavoz\n"
        "4. escribir un script con 'editor' y correrlo con fx\n";
    static const char f_hola[] =
        "#ext: Equipo Fenix | 1.0 | saluda y demuestra variables\n"
        "10 PRINT === Extension Hola de FenixScript ===\n"
        "20 LET n = 3\n"
        "30 PRINT Hola desde FenixScript! n = $n\n"
        "40 LET n = n * 2 + 1\n"
        "50 PRINT tras calcular, n = $n\n"
        "60 IF n > 6 GOTO 80\n"
        "70 PRINT esto nunca deberia imprimirse\n"
        "80 FIN\n";
    static const char f_cuenta[] =
        "#ext: Equipo Fenix | 1.0 | cuenta de 5 a 1 con GOTO\n"
        "10 PRINT cuenta atras de FenixScript\n"
        "20 LET i = 5\n"
        "30 PRINT quedan $i...\n"
        "40 LET i = i - 1\n"
        "50 IF i > 0 GOTO 30\n"
        "60 PRINT despegue!\n"
        "70 FIN\n";
    static const char f_sistema[] =
        "#ext: Equipo Fenix | 1.0 | informa del sistema via EXEC\n"
        "10 PRINT informe rapido del sistema\n"
        "20 EXEC info\n"
        "30 PRINT fin del informe\n"
        "40 FIN\n";
    ramfs_write("leeme.txt",    f_leeme,  (u32)strlen(f_leeme));
    ramfs_write("notas.txt",    f_notas,  (u32)strlen(f_notas));
    ramfs_write("hola.fx",      f_hola,   (u32)strlen(f_hola));
    ramfs_write("cuenta.fx",    f_cuenta, (u32)strlen(f_cuenta));
    ramfs_write("sistema.fx",   f_sistema,(u32)strlen(f_sistema));
    klog("RAMFS", "sistema de archivos en memoria listo (32 archivos x 4KB)");
}

/* escribe (crea o sobrescribe). len==0 crea archivo vacio.
 * devuelve 0 ok, -1 sin ranuras, -2 sin memoria, -3 nombre invalido, -4 largo */
int ramfs_write(const char *name, const char *data, u32 len) {
    if (!name_ok(name)) return -3;
    if (len > RAMFS_FILE_MAX) return -4;

    RamFile *f = find_file(name);
    if (!f) {
        int slot = -1;
        for (int i = 0; i < RAMFS_MAX_FILES; i++)
            if (!files[i].used) { slot = i; break; }
        if (slot < 0) return -1;
        f = &files[slot];
        f->data = (u8 *)kmalloc(RAMFS_FILE_MAX);
        if (!f->data) return -2;
        strncpy(f->name, name, RAMFS_NAME_LEN - 1);
        f->name[RAMFS_NAME_LEN - 1] = 0;
        f->used = 1;
    }
    if (len) memcpy(f->data, data, len);
    f->size = len;
    return 0;
}

/* lee hasta max-1 bytes y deja terminacion nula; devuelve bytes o -1 si no existe */
int ramfs_read(const char *name, char *buf, u32 max) {
    RamFile *f = find_file(name);
    if (!f || !max) return -1;
    u32 n = f->size;
    if (n > max - 1) n = max - 1;
    if (n) memcpy(buf, f->data, n);
    buf[n] = 0;
    return (int)n;
}

int ramfs_exists(const char *name) { return find_file(name) != NULLP; }

int ramfs_delete(const char *name) {
    RamFile *f = find_file(name);
    if (!f) return -1;
    if (f->data) kfree(f->data);
    f->data = NULLP;
    f->used = 0;
    f->size = 0;
    f->name[0] = 0;
    return 0;
}

/* iteracion para 'archivos': devuelve 1 mientras haya entrada idx */
int ramfs_get(int idx, const char **name, u32 *size) {
    if (idx < 0 || idx >= RAMFS_MAX_FILES) return 0;
    if (!files[idx].used) return 0;
    if (name) *name = files[idx].name;
    if (size) *size = files[idx].size;
    return 1;
}

int ramfs_count(void) {
    int n = 0;
    for (int i = 0; i < RAMFS_MAX_FILES; i++) if (files[i].used) n++;
    return n;
}

u32 ramfs_bytes_used(void) {
    u32 b = 0;
    for (int i = 0; i < RAMFS_MAX_FILES; i++) if (files[i].used) b += files[i].size;
    return b;
}

u32 ramfs_file_max(void) { return RAMFS_FILE_MAX; }

int ramfs_slots(void) { return RAMFS_MAX_FILES; }
