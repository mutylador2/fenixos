/* FenixOS — pic.c: 8259A remapeado a vectores 32-47 */
#include "fenixos.h"

#define PIC1_CMD 0x20
#define PIC1_DAT 0x21
#define PIC2_CMD 0xA0
#define PIC2_DAT 0xA1

#define ICW1_INIT 0x11
#define ICW4_8086 0x01

void pic_remap(void) {
    outb(PIC1_CMD, ICW1_INIT); io_wait();
    outb(PIC2_CMD, ICW1_INIT); io_wait();
    outb(PIC1_DAT, 0x20); io_wait();   /* IRQ0 -> vector 32 */
    outb(PIC2_DAT, 0x28); io_wait();   /* IRQ8 -> vector 40 */
    outb(PIC1_DAT, 0x04); io_wait();   /* esclavo en IRQ2 */
    outb(PIC2_DAT, 0x02); io_wait();
    outb(PIC1_DAT, ICW4_8086); io_wait();
    outb(PIC2_DAT, ICW4_8086); io_wait();
    /* enmascarar todo excepto IRQ0 (timer), IRQ1 (teclado), IRQ2 (cascada) */
    outb(PIC1_DAT, 0xF8);
    outb(PIC2_DAT, 0xFF);
    pic_set_mask(12, 0);               /* ratón */
}

void pic_eoi(u8 irq) {
    if (irq >= 8) outb(PIC2_CMD, 0x20);
    outb(PIC1_CMD, 0x20);
}

void pic_set_mask(u8 irq, int masked) {
    u16 port = (irq < 8) ? PIC1_DAT : PIC2_DAT;
    u8 bit = (u8)(1u << (irq & 7));
    u8 cur = inb(port);
    outb(port, masked ? (cur | bit) : (cur & ~bit));
}
