/* FenixOS — idt.c: IDT completa, dispatcher central y panic */
#include "fenixos.h"

typedef struct {
    u16 offset_lo;
    u16 selector;
    u8  ist;
    u8  flags;
    u16 offset_mid;
    u32 offset_hi;
    u32 reserved;
} __attribute__((packed)) IdtEntry;

static IdtEntry idt[256];
static struct { u16 limit; u64 base; } __attribute__((packed)) idt_desc;

extern const u64 isr_stub_table[256];

static const char *exc_names[32] = {
    "DivByZero", "Debug", "NMI", "Breakpoint", "Overflow", "BoundRange",
    "InvalidOpcode", "NoDevice", "DoubleFault", "CoprocSeg", "InvalidTSS",
    "SegNotPresent", "StackFault", "GeneralProt", "PageFault", "Reserved",
    "x87FP", "AlignCheck", "MachineCheck", "SIMDFP", "VirtEx", "CtrlProt",
    "Res22", "Res23", "Res24", "Res25", "Res26", "Res27", "Res28", "Res29",
    "Sec30", "Res31"
};

void idt_init(void) {
    for (int v = 0; v < 256; v++) {
        u64 addr = isr_stub_table[v];
        idt[v].offset_lo = (u16)(addr & 0xFFFF);
        idt[v].selector = 0x08;
        idt[v].ist = 0;
        idt[v].flags = 0x8E;             /* presente, anillo 0, gate de interrupción */
        idt[v].offset_mid = (u16)((addr >> 16) & 0xFFFF);
        idt[v].offset_hi = (u32)((addr >> 32) & 0xFFFFFFFF);
        idt[v].reserved = 0;
    }
    idt_desc.limit = sizeof(idt) - 1;
    idt_desc.base = (u64)idt;
    __asm__ volatile("lidt %0" :: "m"(idt_desc) : "memory");
}

/* Excepciones de CPU: pantalla roja y parada total */
void panic(const char *reason, u64 vector, u64 rip, u64 fault_rsp) {
    cli_irq();
    char line1[96], line2[96];
    ksnprintf(line1, sizeof(line1), "FENIXOS PANIC: %s", reason ? reason : "desconocido");
    ksnprintf(line2, sizeof(line2), "vector=%u rip=%X rsp=%X", (u32)vector, rip, (u32)fault_rsp);
    klog("PANIC", line1);
    klog("PANIC", line2);
    /* volcado de pila para depuración (alrededor del rsp de la falla) */
    u64 base = (fault_rsp ? fault_rsp : 0x80000) - 128;
    for (u64 a = base; a < base + 512; a += 32) {
        char line[96];
        u64 *row = (u64 *)a;
        ksnprintf(line, sizeof(line), "  %X: %X %X %X %X",
                  (u32)a, row[0], row[1], row[2], row[3]);
        klog("STK", line);
    }
    if (fb.bpp) {
        u32 red = fb_rgb(0xB3, 0x1B, 0x1B);
        u32 white = fb_rgb(0xFF, 0xFF, 0xFF);
        fb_fill(red);
        fb_fill_rect(0, 100, fb.width, 4, white);
        fb_text(24, 140, line1, white, red);
        fb_text(24, 170, line2, white, red);
        fb_text(24, 220, "El sistema se ha detenido. Reinicia la maquina virtual.", white, red);
    }
    for (;;) hlt_cpu();
}

static void panic_frame(Frame *f) {
    char buf[64];
    const char *name = (f->vector < 32) ? exc_names[f->vector] : "Excepcion";
    ksnprintf(buf, sizeof(buf), "excepcion %u (%s) err=%u", (u32)f->vector, name, (u32)f->err);
    panic(buf, f->vector, f->rip, f->rsp);
}

/* Despachador central llamado desde todos los stubs de isr.asm.
 * Devuelve la dirección del frame a restaurar (permite cambiar de tarea). */
u64 isr_dispatch(u64 frame_addr) {
    Frame *f = (Frame *)frame_addr;
    switch (f->vector) {
    case 32: {                          /* IRQ0: timer */
        pit_tick();
        pic_eoi(0);
        return task_switch_schedule(frame_addr);
    }
    case 33:                            /* IRQ1: teclado */
        kbd_handler();
        pic_eoi(1);
        return frame_addr;
    case 44:                            /* IRQ12: ratón */
        mouse_handler();
        pic_eoi(12);
        return frame_addr;
    default:
        if (f->vector < 32) panic_frame(f);
        /* IRQs no gestionadas: EOI genérico para desbloquear el PIC */
        if (f->vector >= 40) outb(0xA0, 0x20);
        if (f->vector >= 32) outb(0x20, 0x20);
        return frame_addr;
    }
}
