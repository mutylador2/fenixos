/* FenixOS — kbd.c: driver de teclado PS/2 (IRQ1, scancode set 1) */
#include "fenixos.h"

#define KBD_DATA 0x60
#define KBD_STAT 0x64

#define BUF_SIZE 256
static volatile int buf[BUF_SIZE];
static volatile int buf_head = 0, buf_tail = 0;

static int shift = 0, ext = 0;

/* teclas extendidas E0 -> tokens */
static int ext_map[256] = {
    [0x48] = KEY_UP, [0x50] = KEY_DOWN, [0x4B] = KEY_LEFT, [0x4D] = KEY_RIGHT,
    [0x47] = KEY_HOME, [0x4F] = KEY_END, [0x53] = KEY_DEL,
};

static const char map_lo[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0, 'a','s','d','f','g','h','j','k','l',';','\'','`',
    0, '\\','z','x','c','v','b','n','m',',','.','/', 0, '*', 0, ' ',
};
static const char map_hi[128] = {
    0, 27, '!','@','#','$','%','^','&','*','(',')','_','+','\b',
    '\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',
    0, 'A','S','D','F','G','H','J','K','L',':','"','~',
    0, '|','Z','X','C','V','B','N','M','<','>','?', 0, '*', 0, ' ',
};

void kbd_init(void) {
    buf_head = buf_tail = 0;
    shift = 0;
    ext = 0;
    /* habilitar interfaz de teclado */
    outb(KBD_STAT, 0xAE);
    while (inb(KBD_STAT) & 2) ;
    outb(KBD_DATA, 0xF4);        /* enable scanning */
}

static void push(int c) {
    int next = (buf_head + 1) % BUF_SIZE;
    if (next == buf_tail) return;             /* buffer lleno */
    buf[buf_head] = c;
    buf_head = next;
    /* despertar a la shell si estaba bloqueada */
    for (int i = 0; i < MAX_TASKS; i++) {
        if (tasks[i].state == T_BLOCKED && tasks[i].id >= 0) {
            /* solo se despierta a la tarea que espera entrada */
            tasks[i].state = T_READY;
        }
    }
}

void kbd_handler(void) {
    u8 sc = inb(KBD_DATA);

    if (sc == 0xE0) { ext = 1; return; }

    int release = sc & 0x80;
    u8 code = sc & 0x7F;

    if (ext) {
        ext = 0;
        if (!release && ext_map[code]) push(ext_map[code]);
        return;
    }

    switch (code) {
    case 0x2A: case 0x36: shift = !release; return;
    case 0x3A: return;                    /* caps lock ignorado */
    default: break;
    }
    if (release) return;

    if (code < 128) {
        char c = shift ? map_hi[code] : map_lo[code];
        if (c) push((u8)c);
    }
}

int kbd_available(void) {
    return buf_head != buf_tail;
}

int kbd_getc(void) {
    if (buf_head == buf_tail) return -1;
    int c = buf[buf_tail];
    buf_tail = (buf_tail + 1) % BUF_SIZE;
    return c;
}
