/* FenixOS — config.c: configuración persistente del sistema (v1.2)
 *
 * Tabla clave=valor en RAM respaldada en DISCO (capa de bloques ATA/AHCI)
 * al final de la zona de instalación (partición FenixOS o disco entero)
 * y reflejada en el RAMFS (config.txt) para consulta cómoda.
 *
 * Formato en disco (un sector de 512 B en el LBA reservado por blk.c):
 *   [0..7]  "FNXCFG01"      firma + versión
 *   [8..]   "clave=valor\n" repetido hasta rellenar o terminar
 *
 * Claves conocidas: tema, hostname, autologin, ip, gw, dns. */
#include "fenixos.h"

#define CFG_MAX_PAIRS 16
#define CFG_KEY_MAX   16
#define CFG_VAL_MAX   32
#define CFG_MAGIC     "FNXCFG01"

typedef struct {
    char key[CFG_KEY_MAX];
    char val[CFG_VAL_MAX];
} CfgPair;

static CfgPair cfg[CFG_MAX_PAIRS];
static char hostname_buf[CFG_VAL_MAX] = "fenixos";

const char *config_get(const char *key) {
    if (!key) return NULLP;
    for (int i = 0; i < CFG_MAX_PAIRS; i++)
        if (cfg[i].key[0] && !strcmp(cfg[i].key, key)) return cfg[i].val;
    return NULLP;
}

int config_set(const char *key, const char *val) {
    if (!key || !*key || strlen(key) >= CFG_KEY_MAX) return -1;
    if (val && strlen(val) >= CFG_VAL_MAX) return -2;
    for (int i = 0; i < CFG_MAX_PAIRS; i++) {
        if (cfg[i].key[0] && !strcmp(cfg[i].key, key)) {
            if (!val || !*val) {            /* valor vacío: borrar par */
                cfg[i].key[0] = 0;
                cfg[i].val[0] = 0;
            } else {
                strncpy(cfg[i].val, val, CFG_VAL_MAX - 1);
                cfg[i].val[CFG_VAL_MAX - 1] = 0;
            }
            return 0;
        }
    }
    if (!val || !*val) return 0;            /* borrar clave inexistente: ok */
    for (int i = 0; i < CFG_MAX_PAIRS; i++) {
        if (!cfg[i].key[0]) {
            strncpy(cfg[i].key, key, CFG_KEY_MAX - 1);
            cfg[i].key[CFG_KEY_MAX - 1] = 0;
            strncpy(cfg[i].val, val, CFG_VAL_MAX - 1);
            cfg[i].val[CFG_VAL_MAX - 1] = 0;
            return 0;
        }
    }
    return -3;                              /* tabla llena */
}

int config_pair(int idx, const char **key, const char **val) {
    if (idx < 0 || idx >= CFG_MAX_PAIRS) return 0;
    if (!cfg[idx].key[0]) return 0;
    if (key) *key = cfg[idx].key;
    if (val) *val = cfg[idx].val;
    return 1;
}

/* aplica los valores cargados sobre el sistema vivo */
static void config_apply(void) {
    const char *t = config_get("tema");
    if (t) {
        int th = -1;
        if (!strcmp(t, "fuego"))  th = THEME_FUEGO;
        if (!strcmp(t, "azul"))   th = THEME_AZUL;
        if (!strcmp(t, "bosque")) th = THEME_BOSQUE;
        if (!strcmp(t, "vapor"))  th = THEME_VAPOR;
        if (th >= 0) {
            gui_set_theme(th);
            klogf(LOG_INFO, "CFG", "tema aplicado: %s", t);
        }
    }
    const char *h = config_get("hostname");
    if (h && *h) {
        strncpy(hostname_buf, h, sizeof(hostname_buf) - 1);
        hostname_buf[sizeof(hostname_buf) - 1] = 0;
    }
    /* la red se configura en net_init() leyendo ip/gw/dns */
}

/* carga desde DISCO si existe configuración válida */
int config_load_disk(void) {
    for (int i = 0; i < CFG_MAX_PAIRS; i++) { cfg[i].key[0] = 0; cfg[i].val[0] = 0; }
    if (!blk_present()) {
        klogw("CFG", "sin disco: configuración por defecto");
        return -1;
    }
    static u8 sector[512];
    u32 lba = blk_config_lba();
    if (blk_read(lba, sector) != 0) {
        kloge("CFG", "fallo de lectura del sector de configuración");
        return -2;
    }
    if (memcmp(sector, CFG_MAGIC, 8) != 0) {
        klog("CFG", "sector de configuración vacío: valores por defecto");
        config_defaults();                 /* recargar defaults: la tabla se limpió arriba */
        return 1;                          /* primer arranque, no es error */
    }
    char *p = (char *)sector + 8;
    int loaded = 0;
    while (*p && p < (char *)sector + 510 && loaded < CFG_MAX_PAIRS) {
        char *eq = p;
        while (*eq && *eq != '=' && *eq != '\n') eq++;
        if (*eq != '=') break;
        char *nl = eq;
        while (*nl && *nl != '\n') nl++;
        u32 klen = (u32)(eq - p);
        u32 vlen = (u32)(nl - eq - 1);
        if (klen > 0 && klen < CFG_KEY_MAX && vlen < CFG_VAL_MAX) {
            char key[CFG_KEY_MAX], val[CFG_VAL_MAX];
            memcpy(key, p, klen); key[klen] = 0;
            memcpy(val, eq + 1, vlen); val[vlen] = 0;
            config_set(key, val);
            loaded++;
        }
        p = (*nl) ? nl + 1 : nl;
    }
    config_apply();
    char tmp[64];
    ksnprintf(tmp, sizeof(tmp), "configuración cargada del disco (%d claves, LBA %u)",
              loaded, lba);
    klog("CFG", tmp);
    return 0;
}

/* serializa la tabla y escribe al disco + reflejo en el RAMFS */
int config_save_disk(void) {
    if (!blk_present()) return -1;
    static u8 sector[512];
    memset(sector, 0, sizeof(sector));
    memcpy(sector, CFG_MAGIC, 8);
    u32 off = 8;
    for (int i = 0; i < CFG_MAX_PAIRS && off < 500; i++) {
        if (!cfg[i].key[0]) continue;
        u32 klen = strlen(cfg[i].key), vlen = strlen(cfg[i].val);
        if (off + klen + vlen + 2 >= 510) break;
        memcpy(sector + off, cfg[i].key, klen); off += klen;
        sector[off++] = '=';
        memcpy(sector + off, cfg[i].val, vlen); off += vlen;
        sector[off++] = '\n';
    }
    u32 lba = blk_config_lba();
    int r = blk_write(lba, sector);
    if (r != 0) {
        kloge("CFG", "fallo de escritura en el disco");
        return -2;
    }
    /* reflejo legible en el RAMFS */
    static char mirror[600];
    u32 mlen = 0;
    mirror[mlen++] = '#'; mirror[mlen++] = ' ';
    const char *hdr = "FenixOS config (persistente en disco)\n";
    for (const char *p = hdr; *p; p++) mirror[mlen++] = *p;
    for (int i = 0; i < CFG_MAX_PAIRS && mlen < sizeof(mirror) - 40; i++) {
        if (!cfg[i].key[0]) continue;
        for (const char *p = cfg[i].key; *p; p++) mirror[mlen++] = *p;
        mirror[mlen++] = '=';
        for (const char *p = cfg[i].val; *p; p++) mirror[mlen++] = *p;
        mirror[mlen++] = '\n';
    }
    mirror[mlen] = 0;
    ramfs_write("config.txt", mirror, mlen);
    klogf(LOG_INFO, "CFG", "configuración guardada en disco (LBA %u)", lba);
    return 0;
}

/* volcado inicial por defecto la primera vez (sin config en disco) */
void config_defaults(void) {
    for (int i = 0; i < CFG_MAX_PAIRS; i++) { cfg[i].key[0] = 0; cfg[i].val[0] = 0; }
    config_set("tema", "fuego");
    config_set("hostname", "fenixos");
    config_set("autologin", "admin");
    config_set("ip", "10.0.2.15");
    config_set("gw", "10.0.2.2");
    config_set("dns", "10.0.2.3");
}

const char *config_hostname(void) { return hostname_buf; }

/* re-aplica el hostname desde la tabla (tras 'config hostname x') */
void config_refresh_hostname(void) {
    const char *h = config_get("hostname");
    if (h && *h) {
        strncpy(hostname_buf, h, sizeof(hostname_buf) - 1);
        hostname_buf[sizeof(hostname_buf) - 1] = 0;
    }
}
