; =====================================================================
; FenixOS Kernel — entry.asm: punto de entrada en modo largo
; Stage2 salta a 0x100000 (inicio de .entry) con RDI = bootinfo
; =====================================================================
BITS 64

section .entry
global _start
extern kmain
extern bss_start
extern bss_end

KERNEL_STACK_TOP equ 0x90000

_start:
    cli
    cld
    mov rsp, KERNEL_STACK_TOP
    xor ebp, ebp

    ; limpiar .bss
    mov rdi, bss_start
    mov rcx, bss_end
    sub rcx, rdi
    shr rcx, 3
    xor rax, rax
    rep stosq

    ; recargar selectores de datos (GDT provisional de stage2 sigue válida)
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov fs, ax
    mov gs, ax

    mov rdi, 0x500                       ; BootInfo
    call kmain

.hang:
    cli
    hlt
    jmp .hang
