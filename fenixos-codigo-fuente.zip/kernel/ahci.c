/* FenixOS — ahci.c: driver SATA AHCI para discos modernos (v1.3)
 *
 * Complementa al driver ATA PIO (v1.2) para cubrir el controlador
 * que usan por defecto VirtualBox (Intel ICH9) y los equipos reales
 * con SATA. QEMU: -device ahci -drive ... (8086:2922 o similar).
 *
 * Diseño:
 *  - Localiza el HBA por clase PCI 0x0106 (prog_if 1 = AHCI 1.0).
 *  - BAR5 = ABAR (MMIO). Como el primer GB de la memoria PCI cae en
 *    el GB 3 del espacio físico, stage2 ya lo mapea con identidad
 *    (PD_FB cubre el GB entero); si el BAR no está en un GB mapeado
 *    el driver se degrada con elegancia.
 *  - Un puerto activo por disco (hasta 8), command list de 1 ranura,
 *    transferencias por DMA de 1..8 sectores con READ/WRITE DMA EXT
 *    (LBA48). Todo por sondeo: sin acoplar el driver al IDT.
 *  - Estructuras DMA tomadas del PMM (identidad física==virtual). */
#include "fenixos.h"

#define AHCI_MAX_PORTS   8

/* registros GHC (ABAR) */
#define R_CAP     0x00
#define R_GHC     0x04
#define R_PI      0x0C
#define GHC_HR    (1u << 0)
#define GHC_AE    (1u << 1)

/* registros de puerto (base 0x100 + 0x80*n) */
#define P_CLB     0x00
#define P_CLBU    0x04
#define P_FB      0x08
#define P_FBU     0x0C
#define P_CMD     0x18
#define P_TFD     0x20
#define P_SIG     0x24
#define P_SSTS    0x28
#define P_CI      0x38
#define CMD_ST    (1u << 0)
#define CMD_FRE   (1u << 4)
#define CMD_CR    (1u << 15)
#define CMD_FR    (1u << 14)
#define SSTS_DET  0x0F           /* DET en bits 0-3; 3 = presente+comunicando */

/* comandos ATA */
#define CMD_READ_DMA_EXT  0x25
#define CMD_WRITE_DMA_EXT 0x35
#define CMD_IDENTIFY      0xEC

typedef struct {
    int     active;
    u32     abar;                 /* base MMIO del HBA */
    int     idx;                  /* índice de puerto en el HBA */
    u32     cl_phys;              /* command list (1 KB) */
    u32     fis_phys;             /* received FIS (256 B) */
    u32     ct_phys;              /* command table (128 B + PRDT) */
    u32     buf_phys;             /* buffer DMA (4 KB) */
    u32     sectors;
    char    model[41];
} AhciPort;

static AhciPort ports[AHCI_MAX_PORTS];
static int      port_count = 0;
static int      ahci_ok = 0;

static inline volatile u32 *preg(u32 abar, u32 off) {
    return (volatile u32 *)(u64)(abar + off);
}
static inline u32 rd32(u32 abar, u32 off)      { return *preg(abar, off); }
static inline void wr32(u32 abar, u32 off, u32 v) { *preg(abar, off) = v; }

/* espera activa: NO usa pit (se llama antes del timer) */
static int wait_cleared(volatile u32 *reg, u32 mask, u32 loops) {
    for (u32 i = 0; i < loops; i++)
        if (!(*reg & mask)) return 0;
    return -1;
}

/* emite un comando DMA en el puerto y espera a que termine */
static int ahci_issue(AhciPort *p, int write, u8 cmd, u64 lba,
                      u32 count, u32 buf_phys) {
    volatile u32 *pp = preg(p->abar, 0x100 + 0x80 * p->idx);
    /* cabecera de comando 0: CFL=5 dwords, W según escritura, PRDT x1 */
    volatile u32 *hdr = (volatile u32 *)(u64)p->cl_phys;
    u32 prdt_count = (count + 7) / 8;          /* 8 sectores (4KB) por PRDT */
    if (prdt_count == 0) prdt_count = 1;
    if (prdt_count > 1) prdt_count = 1;        /* simplificación: máx 8 sectores */
    hdr[0] = (5u /*CFL*/) | (write ? (1u << 6) : 0) | (1u << 16) /*PRDTL*/;
    hdr[1] = 0;                                /* PRDBC (se actualiza a 0) */
    hdr[2] = p->ct_phys;
    hdr[3] = 0;
    /* command table: CFIS H2D (64 B) */
    volatile u8 *cfis = (volatile u8 *)(u64)p->ct_phys;
    for (int i = 0; i < 64; i++) cfis[i] = 0;
    cfis[0] = 0x27;                            /* tipo: Host-to-Device */
    cfis[1] = 0x80;                            /* C = comando */
    cfis[2] = cmd;
    cfis[3] = 0;                               /* features */
    cfis[4] = (u8)(lba & 0xFF);
    cfis[5] = (u8)((lba >> 8) & 0xFF);
    cfis[6] = (u8)((lba >> 16) & 0xFF);
    cfis[7] = 0x40 | (u8)((lba >> 24) & 0x0F); /* LBA mode + bits 24-27 */
    /* LBA48: bytes 8-10 = LBA 31:39:47; 11 = features 15:8; 12-13 = count */
    cfis[8] = (u8)((lba >> 24) & 0xFF);
    cfis[9] = (u8)((lba >> 32) & 0xFF);
    cfis[10] = (u8)((lba >> 40) & 0xFF);
    cfis[11] = 0;
    cfis[12] = (u8)(count & 0xFF);
    cfis[13] = (u8)((count >> 8) & 0xFF);
    cfis[14] = 0;
    cfis[15] = 0;
    /* PRDT: un elemento de hasta 4 KB */
    volatile u32 *prdt = (volatile u32 *)(u64)(p->ct_phys + 128);
    u32 bytes = count * 512;
    if (bytes > 4096) bytes = 4096;
    prdt[0] = buf_phys;
    prdt[1] = 0;
    prdt[2] = 0;
    prdt[3] = (bytes - 1);                     /* DBC sin IOC */
    /* emitir */
    pp[P_CI / 4] = 1;
    if (wait_cleared(&pp[P_CI / 4], 1, 4000000) != 0) {
        char dbg[72];
        ksnprintf(dbg, sizeof(dbg), "issue: PxCI no clear (cmd 0x%X lba %lu)", cmd, (u64)lba);
        klogw("AHCI", dbg);
        return -1;
    }
    if (pp[P_TFD / 4] & 0x0001) {
        char dbg[72];
        ksnprintf(dbg, sizeof(dbg), "issue: TFD err 0x%X (cmd 0x%X)", pp[P_TFD / 4], cmd);
        klogw("AHCI", dbg);
        return -2;                             /* ERR en TFD */
    }
    return 0;
}

static int ahci_port_setup(AhciPort *p) {
    volatile u32 *pp = preg(p->abar, 0x100 + 0x80 * p->idx);
    /* parar el motor si estaba activo (firmware/BIOS) */
    u32 cmd = pp[P_CMD / 4];
    if (cmd & (CMD_ST | CMD_CR)) {
        cmd &= ~CMD_ST;
        pp[P_CMD / 4] = cmd;
        wait_cleared(&pp[P_CMD / 4], CMD_CR, 2000000);
    }
    if (pp[P_CMD / 4] & (CMD_FRE | CMD_FR)) {
        cmd &= ~CMD_FRE;
        pp[P_CMD / 4] = cmd;
        wait_cleared(&pp[P_CMD / 4], CMD_FR, 2000000);
    }
    pp[P_CLB / 4] = p->cl_phys;
    pp[P_CLBU / 4] = 0;
    pp[P_FB / 4] = p->fis_phys;
    pp[P_FBU / 4] = 0;
    /* arrancar el motor ANTES del primer comando (ST + FRE) */
    cmd = pp[P_CMD / 4];
    pp[P_CMD / 4] = (cmd | CMD_FRE) | CMD_ST;
    /* IDENTIFY DEVICE por DMA */
    int r = ahci_issue(p, 0, CMD_IDENTIFY, 0, 1, p->buf_phys);
    if (r != 0) {
        char dbg[64];
        ksnprintf(dbg, sizeof(dbg), "IDENTIFY fallo en puerto %d (r=%d)", p->idx, r);
        klogw("AHCI", dbg);
        return -1;
    }
    const u16 *id = (const u16 *)(u64)p->buf_phys;
    p->sectors = (u32)id[100] | ((u32)id[101] << 16);   /* LBA48 */
    if (!p->sectors)
        p->sectors = (u32)id[60] | ((u32)id[61] << 16); /* LBA28 */
    if (!p->sectors) return -2;
    for (int i = 0; i < 40; i += 2) {
        p->model[i]     = (char)(id[27 + i / 2] >> 8);
        p->model[i + 1] = (char)(id[27 + i / 2] & 0xFF);
    }
    p->model[40] = 0;
    for (int i = 39; i >= 0 && p->model[i] == ' '; i--) p->model[i] = 0;
    return 0;
}

int ahci_init(void) {
    port_count = 0;
    ahci_ok = 0;
    if (pci_count() == 0) return 0;

    /* buscar controladora SATA AHCI (clase 01, subclase 06, prog_if 1) */
    PciDev *dev = NULLP;
    for (int i = 0; i < pci_count(); i++) {
        PciDev *d = pci_get(i);
        if (d->class_code == 0x01 && d->subclass == 0x06 && (d->prog_if & 0x0F) == 1) {
            dev = d;
            break;
        }
    }
    if (!dev) {
        klog("AHCI", "sin controladora SATA AHCI (clase PCI 0106)");
        return 0;
    }
    u32 abar = dev->bar[5] & 0xFFFFFC00u;
    if (dev->bar[5] == 0) {
        klogw("AHCI", "BAR5 sin dirección MMIO");
        return 0;
    }
    /* solo si el ABAR está en el GB mapeado por identidad (GB del fb) */
    u32 fb_gb = (fb.paddr >> 30) & 0x3;
    if ((abar >> 30) != fb_gb) {
        klogf(LOG_WARN, "AHCI", "ABAR 0x%X fuera del GB mapeado (0x%X): driver inactivo",
              abar, fb_gb << 30);
        return 0;
    }
    if (dev->bar[5] & 0x04) {                 /* BAR de 64 bits: usar parte baja */
        klogw("AHCI", "BAR5 de 64 bits: se usa solo la parte baja");
    }

    /* reinicio del HBA */
    u32 ghc = rd32(abar, R_GHC);
    wr32(abar, R_GHC, ghc | GHC_HR);
    if (wait_cleared(preg(abar, R_GHC), GHC_HR, 2000000) != 0) {
        klogw("AHCI", "el HBA no completó el reinicio");
        return 0;
    }
    wr32(abar, R_GHC, GHC_AE);
    u32 pi = rd32(abar, R_PI);

    char tmp[96];
    ksnprintf(tmp, sizeof(tmp), "HBA AHCI en 0x%X, puertos implementados 0x%X",
              abar, pi);
    klog("AHCI", tmp);

    for (int n = 0; n < AHCI_MAX_PORTS && port_count < 4; n++) {
        if (!(pi & (1u << n))) continue;
        u32 ssts = rd32(abar, 0x100 + 0x80 * n + P_SSTS);
        u32 sig = rd32(abar, 0x100 + 0x80 * n + P_SIG);
        char dbg[80];
        ksnprintf(dbg, sizeof(dbg), "puerto %d: SSTS=0x%X SIG=0x%X", n, ssts, sig);
        klog("AHCI", dbg);
        if ((ssts & SSTS_DET) != 3) continue;
        AhciPort *p = &ports[port_count];
        memset(p, 0, sizeof(AhciPort));
        p->abar = abar;
        p->idx = n;
        /* estructuras DMA contiguas: 2 páginas por puerto */
        u64 phys = pmm_alloc_contig(2);
        if (!phys) {
            klogw("AHCI", "sin memoria para estructuras DMA");
            break;
        }
        p->cl_phys  = (u32)phys;              /* 1 KB alineado a 1 KB */
        p->fis_phys = (u32)phys + 1024;       /* 256 B */
        p->ct_phys  = (u32)phys + 2048;       /* command table + PRDT */
        p->buf_phys = (u32)phys + 4096;       /* 4 KB de datos DMA */
        if (ahci_port_setup(p) != 0) continue;
        port_count++;
        ksnprintf(tmp, sizeof(tmp), "SATA %d: '%s', %u MB, LBA48",
                  n, p->model, p->sectors >> 11);
        klog("AHCI", tmp);
    }
    ahci_ok = (port_count > 0);
    return port_count;
}

int  ahci_present(void)     { return ahci_ok; }
int  ahci_port_count(void)  { return port_count; }
const char *ahci_port_model(int port) {
    if (port < 0 || port >= port_count) return "";
    return ports[port].model;
}
u32  ahci_port_sectors(int port) {
    if (port < 0 || port >= port_count) return 0;
    return ports[port].sectors;
}

int ahci_read(int port, u32 lba, void *buf) {
    if (port < 0 || port >= port_count) return -1;
    AhciPort *p = &ports[port];
    if (lba + 1 > p->sectors) return -1;
    int r = ahci_issue(p, 0, CMD_READ_DMA_EXT, lba, 1, p->buf_phys);
    volatile u32 *hdr = (volatile u32 *)(u64)p->cl_phys;
    u32 prdbc = hdr[1];
    if (r != 0) {
        char dbg[72];
        ksnprintf(dbg, sizeof(dbg), "read r=%d lba=%u PRDBC=%u", r, lba, prdbc);
        klogw("AHCI", dbg);
        return -2;
    }
    if (lba < 3 || lba > 40000) {
        char dbg[80];
        const u8 *d = (const u8 *)(u64)p->buf_phys;
        ksnprintf(dbg, sizeof(dbg), "read lba=%u PRDBC=%u b0=%02X%02X%02X%02X",
                  lba, prdbc, d[0], d[1], d[2], d[3]);
        klog("AHCI", dbg);
    }
    memcpy(buf, (const void *)(u64)p->buf_phys, 512);
    return 0;
}

int ahci_write(int port, u32 lba, const void *buf) {
    if (port < 0 || port >= port_count) return -1;
    AhciPort *p = &ports[port];
    if (lba + 1 > p->sectors) return -1;
    memcpy((void *)(u64)p->buf_phys, buf, 512);
    int r = ahci_issue(p, 1, CMD_WRITE_DMA_EXT, lba, 1, p->buf_phys);
    if (r != 0) {
        char dbg[72];
        ksnprintf(dbg, sizeof(dbg), "write r=%d lba=%u", r, lba);
        klogw("AHCI", dbg);
        return -2;
    }
    if (lba < 3) {
        char dbg[72];
        ksnprintf(dbg, sizeof(dbg), "write lba=%u ok", lba);
        klog("AHCI", dbg);
    }
    return 0;
}
