/* FenixOS — gui.c: subsistema gráfico (Executive)
 * Escritorio con fondo por temas, iconos, ventanas arrastrables,
 * barra de tareas con reloj y cursor de ratón. Compositor a ~33 fps. */
#include "fenixos.h"

int gui_ready = 0;
int demo_running = 0;
int demo_task_id = -1;

Theme current_theme;
static int theme_id = THEME_FUEGO;

static const Theme themes[4] = {
    /* FUEGO (por defecto): negro -> granate, acento naranja fenix */
    { 0xFF0D0A08, 0xFF40150C, 0xFFFF7A18, 0xFF14181D, 0xFFFF7A18,
      0xFF10141B, 0xFFB35310, 0xFF39424D },
    /* AZUL: noche -> azul profundo, acento cian */
    { 0xFF070B14, 0xFF0E2247, 0xFF18A0E0, 0xFF10141D, 0xFF18A0E0,
      0xFF0D1117, 0xFF1668A8, 0xFF39424D },
    /* BOSQUE: verde oscuro, acento verde lima */
    { 0xFF070D08, 0xFF12331C, 0xFF5FBF6A, 0xFF101812, 0xFF5FBF6A,
      0xFF0D130F, 0xFF2F7A3A, 0xFF39424D },
    /* VAPOR: morado -> rosa, acento rosa pastel */
    { 0xFF100A18, 0xFF3A1C3F, 0xFFE86FA4, 0xFF161020, 0xFFE86FA4,
      0xFF130E1C, 0xFF9A3F6E, 0xFF453A52 },
};

const char *theme_name(int t) {
    switch (t) {
    case THEME_FUEGO:  return "fuego";
    case THEME_AZUL:   return "azul";
    case THEME_BOSQUE: return "bosque";
    case THEME_VAPOR:  return "vapor";
    default: return "?";
    }
}

void gui_set_theme(int t) {
    if (t < 0 || t > 3) return;
    theme_id = t;
    current_theme = themes[t];
}

/* ------------------------- gestor de ventanas ------------------------- */
static Window wins[MAX_WINDOWS];
static int focus_idx = -1;
static int drag_idx = -1;
static i32 drag_dx = 0, drag_dy = 0;

/* iconos del escritorio */
typedef struct { const char *label; WinType type; } Icon;
static const Icon icons[8] = {
    { "Terminal", WIN_SHELL }, { "Demo", WIN_DEMO },
    { "Editor", WIN_EDITOR },  { "Calculadora", WIN_CALC },
    { "Visor", WIN_VIEWER },   { "Sistema", WIN_VIEWER },
    { "Instalador", WIN_INST },{ "Acerca", WIN_ABOUT }
};
#define ICON_COUNT 8
#define ICON_SIZE 76

/* geometría de la calculadora (coinciden en render y clicks) */
#define CALC_BTN_W  56
#define CALC_BTN_H  52
#define CALC_DISP_H 36
static const char calc_keys[16] = {
    '7','8','9','/',
    '4','5','6','x',
    '1','2','3','-',
    '0','C','=','+'
};

/* geometría del editor (coinciden en render y en los clicks) */
#define ED_BTN_SAVE_W  66
#define ED_BTN_CLEAR_W 62
#define ED_BTN_H       18
#define ED_STATUS_H    26

static Window *win_find(WinType t) {
    for (int i = 0; i < MAX_WINDOWS; i++)
        if (wins[i].used && wins[i].type == t) return &wins[i];
    return NULLP;
}

static Window *win_alloc(void) {
    for (int i = 0; i < MAX_WINDOWS; i++)
        if (!wins[i].used) { memset(&wins[i], 0, sizeof(Window)); wins[i].used = 1; return &wins[i]; }
    return NULLP;
}

static Window *win_open(WinType type) {
    Window *w = win_find(type);
    if (w) {
        w->visible = 1;
        focus_idx = (int)(w - wins);
        return w;
    }
    w = win_alloc();
    if (!w) return NULLP;
    w->type = type;
    w->visible = 1;
    focus_idx = (int)(w - wins);
    if (type == WIN_SHELL) {
        strcpy(w->title, "FenixShell");
        w->w = 620; w->h = 400;
        w->x = 60; w->y = 48;
        w->cols = (w->w - 16) / FONT_W;
        w->rows = (w->h - 28 - 12) / FONT_H;
        w->cells = (u16 *)kcalloc((u32)(w->cols * w->rows) * sizeof(u16));
    } else if (type == WIN_DEMO) {
        strcpy(w->title, "FenixDemo");
        w->w = 300; w->h = 280;
        w->x = (i32)fb.width - 340; w->y = 60;
        w->bx = w->x + 40; w->by = w->y + 80;
        w->bvx = 3; w->bvy = 2;
    } else if (type == WIN_EDITOR) {
        strcpy(w->title, "Editor");
        w->w = 540; w->h = 344;
        w->x = ((i32)fb.width - w->w) / 2 + 60;
        w->y = 56;
        w->cols = (w->w - 16) / FONT_W;              /* 65 */
        w->rows = (w->h - 28 - ED_STATUS_H) / FONT_H; /* 18 filas de contenido */
        w->cells = (u16 *)kcalloc((u32)(w->cols * w->rows) * sizeof(u16));
    } else if (type == WIN_CALC) {
        strcpy(w->title, "Calculadora");
        w->w = 16 + 4 * CALC_BTN_W + 3 * 4;
        w->h = 28 + CALC_DISP_H + 8 + 4 * CALC_BTN_H + 3 * 4 + 8;
        w->x = (i32)fb.width - w->w - 24;
        w->y = (i32)fb.height - TB_HEIGHT - w->h - 12;
        strcpy(w->c_disp, "0");
        w->c_acc = 0; w->c_op = 0; w->c_fresh = 1;
    } else if (type == WIN_VIEWER) {
        strcpy(w->title, "Visor");
        w->w = 560; w->h = 380;
        w->x = ((i32)fb.width - w->w) / 2 + 40;
        w->y = 48;
        w->cols = (w->w - 16) / FONT_W;
        w->rows = (w->h - 28 - 24) / FONT_H;
        w->view_buf = NULLP; w->view_len = 0; w->view_top = 0; w->view_lines = 1;
    } else if (type == WIN_INST) {
        strcpy(w->title, "Instalador de FenixOS");
        w->w = 600; w->h = 420;
        w->x = ((i32)fb.width - w->w) / 2 + 20;
        w->y = 44;
    } else {
        strcpy(w->title, "Acerca de FenixOS");
        w->w = 420; w->h = 270;
        w->x = ((i32)fb.width - w->w) / 2;
        w->y = ((i32)fb.height - TB_HEIGHT - w->h) / 2;
    }
    return w;
}

void wm_open_shell(void) { win_open(WIN_SHELL); }
void wm_open_demo(void)  { win_open(WIN_DEMO); }
void wm_open_about(void) { win_open(WIN_ABOUT); }
void wm_open_calc(void)  { win_open(WIN_CALC); }

/* helper para installer.c (evita exponer win_open) */
Window *gui_win_open_inst(void) { return win_open(WIN_INST); }

/* líneas visibles de un texto con ajuste a 'cols' columnas */
static int text_count_lines(const char *buf, u32 len, int cols) {
    if (!buf || !len) return 1;
    int lines = 1, col = 0;
    for (u32 i = 0; i < len; i++) {
        char c = buf[i];
        if (c == '\n') { lines++; col = 0; }
        else { col++; if (col >= cols) { lines++; col = 0; } }
    }
    return lines;
}

/* abre (o reutiliza) el visor sobre un archivo del RAMFS */
Window *wm_open_viewer(const char *fname) {
    Window *w = win_open(WIN_VIEWER);
    if (!w) return NULLP;
    if (!fname || !*fname) fname = "leeme.txt";
    if (w->view_buf && w->fname[0] && !strcmp(w->fname, fname) && w->view_len) {
        focus_idx = (int)(w - wins);
        return w;                     /* ya está mostrado */
    }
    if (w->view_buf) { kfree(w->view_buf); w->view_buf = NULLP; }
    w->view_top = 0;
    strncpy(w->fname, fname, sizeof(w->fname) - 1);
    w->fname[sizeof(w->fname) - 1] = 0;
    char tbuf[28];
    ksnprintf(tbuf, sizeof(tbuf), "Visor: %s", w->fname);
    strncpy(w->title, tbuf, sizeof(w->title) - 1);
    w->title[sizeof(w->title) - 1] = 0;

    u32 size = 0;
    for (int i = 0; i < ramfs_slots(); i++) {
        const char *nm; u32 sz;
        if (ramfs_get(i, &nm, &sz) && !strcmp(nm, w->fname)) { size = sz; break; }
    }
    if (!size) {
        static const char vacio[] = "(archivo vacio o inexistente)";
        w->view_buf = (char *)kmalloc(sizeof(vacio));
        if (w->view_buf) { strcpy(w->view_buf, vacio); w->view_len = sizeof(vacio) - 1; }
    } else {
        w->view_buf = (char *)kmalloc(size + 1);
        if (w->view_buf) {
            int n = ramfs_read(w->fname, w->view_buf, size + 1);
            w->view_len = (n > 0) ? (u32)n : 0;
        }
    }
    w->view_lines = text_count_lines(w->view_buf, w->view_len, w->cols);
    focus_idx = (int)(w - wins);
    return w;
}

/* visor con contenido arbitrario (navegador): toma propiedad del buffer */
Window *wm_open_nav(const char *title, char *buf, u32 len) {
    Window *w = win_open(WIN_VIEWER);
    if (!w) return NULLP;
    if (w->view_buf) kfree(w->view_buf);
    w->view_buf = buf;                 /* puede ser NULL (error) */
    w->view_len = buf ? len : 0;
    w->view_top = 0;
    w->fname[0] = 0;
    w->view_lines = text_count_lines(w->view_buf, w->view_len, w->cols);
    strncpy(w->title, title, sizeof(w->title) - 1);
    w->title[sizeof(w->title) - 1] = 0;
    focus_idx = (int)(w - wins);
    return w;
}

void viewer_close_free(Window *w) {
    if (w && w->view_buf) { kfree(w->view_buf); w->view_buf = NULLP; }
    w->view_len = 0;
}

/* abre (o reutiliza) la ventana Editor sobre un archivo del RAMFS.
 * fname NULL -> archivo nuevo "sin-titulo.txt"; load -> rellena el contenido */
void wm_open_editor(const char *fname, int load) {
    Window *w = win_open(WIN_EDITOR);
    if (!w) return;
    const char *nm = fname ? fname : "sin-titulo.txt";
    /* si ya existía y es el mismo archivo, no recargar: se perdería lo tecleado */
    int reload = (load || !w->fname[0] || strcmp(w->fname, nm) != 0);
    strncpy(w->fname, nm, sizeof(w->fname) - 1);
    w->fname[sizeof(w->fname) - 1] = 0;
    char tbuf[28];
    ksnprintf(tbuf, sizeof(tbuf), "Editor: %s", w->fname);
    strncpy(w->title, tbuf, sizeof(w->title) - 1);
    w->title[sizeof(w->title) - 1] = 0;
    if (reload) {
        char buf[RAMFS_BUF];
        for (int i = 0; i < w->cols * w->rows; i++) w->cells[i] = ' ';
        w->ccx = w->ccy = 0;
        w->ed_saved = 0;
        if (load && ramfs_read(w->fname, buf, sizeof(buf)) >= 0) {
            int r = 0, c = 0;
            for (char *p = buf; *p && r < w->rows; p++) {
                if (*p == '\n') { r++; c = 0; continue; }
                if (c < w->cols) w->cells[r * w->cols + c] = (u16)(u8)*p;
                c++;
            }
        }
    }
}

Window *gui_shell_window(void) { return win_find(WIN_SHELL); }
Window *gui_demo_window(void)  { return win_find(WIN_DEMO); }
Window *gui_focused_window(void) {
    if (focus_idx >= 0 && focus_idx < MAX_WINDOWS && wins[focus_idx].used)
        return &wins[focus_idx];
    return NULLP;
}
int gui_get_theme(void)        { return theme_id; }

/* ------------------------- render del escritorio ------------------------- */
static void render_wallpaper(void) {
    /* gradiente vertical precalculado por líneas (mezcla fija 0..255) */
    u32 top = current_theme.wp_top, bot = current_theme.wp_bottom;
    i32 r0 = (top >> 16) & 0xFF, g0 = (top >> 8) & 0xFF, b0 = top & 0xFF;
    i32 r1 = (bot >> 16) & 0xFF, g1 = (bot >> 8) & 0xFF, b1 = bot & 0xFF;
    i32 wh = (i32)fb.height;
    for (i32 y = 0; y < wh; y++) {
        i32 t = y * 255 / (wh > 1 ? wh - 1 : 1);
        u32 c = ((u32)((r0 + (r1 - r0) * t / 255)) << 16)
              | ((u32)((g0 + (g1 - g0) * t / 255)) << 8)
              | (u32)(b0 + (b1 - b0) * t / 255);
        u32 *row = backbuffer + (u64)y * fb.width;
        for (u32 x = 0; x < fb.width; x++) row[x] = c;
    }
    /* patrón sutil de rejilla */
    u32 grid = ((current_theme.accent & 0xFEFEFE) >> 1) | 0xFF202020;
    for (i32 y = 0; y < wh; y += 48)
        for (i32 x = (y / 48) % 2 ? 24 : 0; x < (i32)fb.width; x += 48)
            bb_fill_rect(x, y, 1, 1, grid);

    /* marca de agua */
    char wm[48];
    ksnprintf(wm, sizeof(wm), "FenixOS 1.3 x86_64");
    bb_text_t((i32)fb.width - (i32)strlen(wm) * FONT_W - 12, wh - TB_HEIGHT - FONT_H - 8,
              wm, 0xFF6E6A66);
}

static void draw_icon(i32 x, i32 y, int idx, u32 accent) {
    /* caja del icono */
    bb_fill_rect(x + 4, y + 4, ICON_SIZE - 16, 44, 0xFF14181D);
    bb_rect(x + 4, y + 4, ICON_SIZE - 16, 44, accent);
    if (idx == 0) {                       /* terminal: >_ */
        bb_text_t(x + 16, y + 18, ">_", accent);
    } else if (idx == 1) {                /* demo: pelota */
        bb_fill_rect(x + 24, y + 14, 20, 20, accent);
        bb_fill_rect(x + 28, y + 18, 8, 8, 0xFF14181D);
    } else if (idx == 2) {                /* editor: lápiz */
        bb_fill_rect(x + 22, y + 26, 6, 14, accent);       /* cuerpo */
        bb_fill_rect(x + 22, y + 40, 6, 3, 0xFFE6E6E6);    /* punta */
        bb_fill_rect(x + 28, y + 14, 4, 14, 0xFFE6E6E6);   /* goma */
    } else if (idx == 3) {                /* calculadora: rejilla */
        for (int r = 0; r < 2; r++)
            for (int c = 0; c < 2; c++)
                bb_fill_rect(x + 22 + c * 12, y + 14 + r * 12, 9, 9,
                             (r == 0 && c == 0) ? 0xFFE6E6E6 : accent);
    } else if (idx == 4) {                /* visor: página con líneas */
        bb_fill_rect(x + 24, y + 12, 18, 24, 0xFFE6E6E6);
        for (int l = 0; l < 4; l++)
            bb_fill_rect(x + 27, y + 16 + l * 5, 12, 2, accent);
    } else if (idx == 5) {                /* sistema: monitor con chispa */
        bb_fill_rect(x + 20, y + 14, 26, 18, accent);
        bb_fill_rect(x + 24, y + 18, 18, 10, 0xFF14181D);
        bb_fill_rect(x + 30, y + 32, 6, 4, accent);
        bb_fill_rect(x + 24, y + 36, 18, 3, 0xFFE6E6E6);
    } else if (idx == 6) {                /* instalador: disco con flecha */
        bb_fill_rect(x + 22, y + 14, 22, 22, 0xFFE6E6E6);
        bb_fill_rect(x + 25, y + 17, 16, 4, accent);
        bb_fill_rect(x + 30, y + 25, 6, 6, accent);
        bb_fill_rect(x + 32, y + 8, 3, 5, 0xFF7EE787);
        bb_fill_rect(x + 30, y + 12, 3, 4, 0xFF7EE787);
        bb_fill_rect(x + 34, y + 12, 3, 4, 0xFF7EE787);
    } else {                              /* acerca: i */
        bb_text_t(x + 30, y + 18, "i", accent);
    }
    bb_text_t(x + 6, y + 52, icons[idx].label, 0xFFE6E6E6);
}

static void render_icons(void) {
    u32 accent = current_theme.accent;
    for (int i = 0; i < ICON_COUNT; i++)
        draw_icon(16, 16 + i * (ICON_SIZE + 18), i, accent);
}

static int icon_hit(i32 mx, i32 my) {
    for (int i = 0; i < ICON_COUNT; i++) {
        i32 x = 16, y = 16 + i * (ICON_SIZE + 18);
        if (mx >= x && mx < x + ICON_SIZE && my >= y && my < y + ICON_SIZE + 10)
            return i;
    }
    return -1;
}

static void render_window(Window *w, int idx) {
    if (!w->used || !w->visible) return;
    int focused = (idx == focus_idx);
    u32 tbar = focused ? current_theme.win_title_focus : current_theme.win_title_unfocus;
    u32 accent = focused ? current_theme.accent : 0xFF5A6068;

    /* sombra */
    bb_fill_rect(w->x + 3, w->y + 3, w->w, w->h, 0xFF000000);
    /* cuerpo */
    bb_fill_rect(w->x, w->y, w->w, w->h, current_theme.win_bg);
    /* barra de título */
    bb_fill_rect(w->x, w->y, w->w, 28, tbar);
    bb_fill_rect(w->x, w->y, w->w, 2, accent);
    bb_text_t(w->x + 10, w->y + 7, w->title, 0xFFFFFFFF);
    /* botón de cerrar */
    bb_fill_rect(w->x + w->w - 22, w->y + 6, 16, 16, 0xFFC0392B);
    bb_text_t(w->x + w->w - 19, w->y + 7, "x", 0xFFFFFFFF);
    /* borde */
    bb_rect(w->x, w->y, w->w, w->h, accent);

    /* contenido según tipo */
    if (w->type == WIN_SHELL && w->cells) {
        for (int r = 0; r < w->rows; r++) {
            for (int c = 0; c < w->cols; c++) {
                u16 cell = w->cells[r * w->cols + c];
                char ch = (char)(cell & 0xFF);
                u32 fg = shell_attr_color(cell >> 8);
                if (ch == ' ') continue;
                bb_char(w->x + 8 + c * FONT_W, w->y + 28 + r * FONT_H, ch, fg, current_theme.win_bg);
            }
        }
        /* cursor parpadeante */
        if (focused && ((pit_ticks / 25) & 1)) {
            i32 cxp = w->x + 8 + w->ccx * FONT_W;
            i32 cyp = w->y + 28 + w->ccy * FONT_H;
            bb_fill_rect(cxp, cyp, FONT_W - 1, FONT_H - 1, 0xFF7EE787);
        }
    } else if (w->type == WIN_DEMO) {
        bb_fill_rect(w->x + 1, w->y + 28, w->w - 2, w->h - 29, 0xFF0A0E12);
        bb_fill_rect(w->bx - 10, w->by - 10, 20, 20, current_theme.accent);
        bb_fill_rect(w->bx - 5, w->by - 5, 8, 8, 0xFFFFFFFF);
        bb_text_t(w->x + 8, w->y + w->h - 24, "ps: escribe 'demo off'", 0xFF8A9199);
    } else if (w->type == WIN_ABOUT) {
        char l1[64], l2[64], l3[64], l4[64];
        ksnprintf(l1, sizeof(l1), "FenixOS 1.3 \"Titan\"");
        ksnprintf(l2, sizeof(l2), "Kernel propio x86_64 desde cero");
        ksnprintf(l3, sizeof(l3), "Multiboot, AHCI, instalador grafico");
        ksnprintf(l4, sizeof(l4), "Arquitectura: HAL/Kernel/Executive");
        bb_text_t(w->x + 16, w->y + 48, l1, current_theme.accent);
        bb_text_t(w->x + 16, w->y + 78, l2, 0xFFE6E6E6);
        bb_text_t(w->x + 16, w->y + 100, l3, 0xFFE6E6E6);
        bb_text_t(w->x + 16, w->y + 128, l4, 0xFF9AA4AE);
        bb_text_t(w->x + 16, w->y + 156, "Escribe 'ayuda' en la terminal", 0xFF9AA4AE);
    } else if (w->type == WIN_INST) {
        installer_render(w);
    } else if (w->type == WIN_EDITOR && w->cells) {
        /* contenido: filas de texto */
        for (int r = 0; r < w->rows; r++)
            for (int c = 0; c < w->cols; c++) {
                u16 cell = w->cells[r * w->cols + c];
                char ch = (char)(cell & 0xFF);
                if (ch == ' ' || ch == 0) continue;
                bb_char(w->x + 8 + c * FONT_W, w->y + 28 + r * FONT_H, ch,
                        0xFFE6EDF3, current_theme.win_bg);
            }
        /* barra de estado con botones */
        i32 sy = w->y + w->h - ED_STATUS_H;
        bb_fill_rect(w->x + 1, sy, w->w - 2, ED_STATUS_H - 1, 0xFF0D1117);
        bb_text_t(w->x + 8, sy + 5, "archivo:", 0xFF8B949E);
        bb_text_t(w->x + 70, sy + 5, w->fname, 0xFFE3B341);
        if (w->ed_saved)
            bb_text_t(w->x + 190, sy + 5, "guardado", current_theme.accent);
        /* botones Guardar / Limpiar */
        bb_fill_rect(w->x + w->w - 8 - ED_BTN_SAVE_W - 8 - ED_BTN_CLEAR_W, sy + 4,
                     ED_BTN_CLEAR_W, ED_BTN_H, 0xFF1B2126);
        bb_rect(w->x + w->w - 8 - ED_BTN_SAVE_W - 8 - ED_BTN_CLEAR_W, sy + 4,
                ED_BTN_CLEAR_W, ED_BTN_H, 0xFF5A6068);
        bb_text_t(w->x + w->w - 8 - ED_BTN_SAVE_W - 8 - ED_BTN_CLEAR_W + 8, sy + 8,
                  "Limpiar", 0xFFD9DEE3);
        bb_fill_rect(w->x + w->w - 8 - ED_BTN_SAVE_W, sy + 4,
                     ED_BTN_SAVE_W, ED_BTN_H, current_theme.accent);
        bb_text_t(w->x + w->w - 8 - ED_BTN_SAVE_W + 10, sy + 8,
                  "Guardar", 0xFFFFFFFF);
        /* cursor parpadeante */
        if (focused && ((pit_ticks / 25) & 1) && w->ccy < w->rows && w->ccx < w->cols) {
            i32 cxp = w->x + 8 + w->ccx * FONT_W;
            i32 cyp = w->y + 28 + w->ccy * FONT_H;
            bb_fill_rect(cxp, cyp, FONT_W - 1, FONT_H - 1, 0xFF79C0FF);
        }
    } else if (w->type == WIN_CALC) {
        /* visor del resultado */
        bb_fill_rect(w->x + 1, w->y + 28, w->w - 2, CALC_DISP_H, 0xFF0A0E12);
        i32 dw = (i32)strlen(w->c_disp) * FONT_W;
        bb_text_t(w->x + w->w - 10 - dw, w->y + 38, w->c_disp, 0xFF7EE787);
        /* rejilla 4x4 de botones */
        i32 gy = w->y + 28 + CALC_DISP_H + 8;
        for (int i = 0; i < 16; i++) {
            int r = i / 4, c = i % 4;
            i32 bx = w->x + 8 + c * (CALC_BTN_W + 4);
            i32 by = gy + r * (CALC_BTN_H + 4);
            char k = calc_keys[i];
            u32 bgc = 0xFF1B2126;
            if (k == '=') bgc = current_theme.accent;
            else if (k == 'C') bgc = 0xFF5A2521;
            else if (k == '+' || k == '-' || k == 'x' || k == '/') bgc = 0xFF2A3138;
            bb_fill_rect(bx, by, CALC_BTN_W, CALC_BTN_H, bgc);
            bb_rect(bx, by, CALC_BTN_W, CALC_BTN_H, 0xFF39424D);
            char s[2] = { k, 0 };
            bb_text_t(bx + CALC_BTN_W / 2 - 4, by + CALC_BTN_H / 2 - 8, s,
                      (k == '=') ? 0xFFFFFFFF : 0xFFD9DEE3);
        }
    } else if (w->type == WIN_VIEWER) {
        /* contenido con desplazamiento */
        i32 ty = w->y + 28;
        int row = 0, col = 0;
        int line = 0;
        const char *p = w->view_buf;
        u32 left = w->view_len;
        /* saltar las líneas anteriores a view_top */
        while (left && p && line < w->view_top) {
            if (*p == '\n') line++;
            else { col++; if (col >= w->cols) { line++; col = 0; } }
            p++; left--;
        }
        col = 0;
        while (left && row < w->rows && p) {
            char ch = *p;
            if (ch == '\n') { row++; col = 0; }
            else {
                if (ch >= 32 && ch < 127)
                    bb_char(w->x + 8 + col * FONT_W, ty + row * FONT_H, ch,
                            0xFFE6EDF3, current_theme.win_bg);
                col++;
                if (col >= w->cols) { row++; col = 0; }
            }
            p++; left--;
        }
        /* barra de estado */
        i32 sy = w->y + w->h - 24;
        bb_fill_rect(w->x + 1, sy, w->w - 2, 23, 0xFF0D1117);
        char sb[64];
        ksnprintf(sb, sizeof(sb), "linea %d de %d  (flechas arriba/abajo)",
                  w->view_top + 1, w->view_lines);
        bb_text_t(w->x + 8, sy + 4, sb, 0xFF8B949E);
    }
}

static void render_taskbar(void) {
    i32 y = (i32)fb.height - TB_HEIGHT;
    bb_fill_rect(0, y, (i32)fb.width, TB_HEIGHT, current_theme.taskbar_bg);
    bb_fill_rect(0, y, (i32)fb.width, 2, current_theme.taskbar_border);

    /* botón inicio */
    bb_fill_rect(6, y + 5, 96, TB_HEIGHT - 10, current_theme.accent);
    bb_text_t(14, y + 11, "FenixOS", 0xFFFFFFFF);

    /* botones de ventana */
    i32 bx = 112;
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (!wins[i].used || !wins[i].visible) continue;
        u32 bgc = (i == focus_idx) ? 0xFF2A3138 : 0xFF1B2126;
        bb_fill_rect(bx, y + 5, 130, TB_HEIGHT - 10, bgc);
        bb_fill_rect(bx, y + 5, 2, TB_HEIGHT - 10, current_theme.accent);
        bb_text_t(bx + 8, y + 11, wins[i].title, 0xFFD9DEE3);
        bx += 138;
        if (bx > (i32)fb.width - 200) break;
    }

    /* reloj */
    char tbuf[24];
    ksnprintf(tbuf, sizeof(tbuf), "%2u:%2u:%2u", rtc_hour, rtc_min, rtc_sec);
    for (char *p = tbuf; *p; p++) if (*p == ' ') *p = '0';
    i32 tx = (i32)fb.width - (i32)strlen(tbuf) * FONT_W - 12;
    bb_fill_rect(tx - 10, y + 5, (i32)strlen(tbuf) * FONT_W + 18, TB_HEIGHT - 10, 0xFF0D1117);
    bb_text_t(tx, y + 11, tbuf, 0xFF7EE787);
}

static const u8 cursor_arrow[16][10] = {
    {1,0,0,0,0,0,0,0,0,0},
    {1,1,0,0,0,0,0,0,0,0},
    {1,15,1,0,0,0,0,0,0,0},
    {1,15,15,1,0,0,0,0,0,0},
    {1,15,15,15,1,0,0,0,0,0},
    {1,15,15,15,15,1,0,0,0,0},
    {1,15,15,15,15,15,1,0,0,0},
    {1,15,15,15,15,15,15,1,0,0},
    {1,15,15,15,15,15,15,15,1,0},
    {1,15,15,15,15,15,1,1,1,1},
    {1,15,15,1,15,15,1,0,0,0},
    {1,15,1,0,1,15,15,1,0,0},
    {1,1,0,0,1,15,15,1,0,0},
    {1,0,0,0,0,1,15,15,1,0},
    {0,0,0,0,0,1,15,15,1,0},
    {0,0,0,0,0,0,1,1,0,0},
};

static void render_cursor(void) {
    i32 mx = mouse_x, my = mouse_y;
    for (int r = 0; r < 16; r++)
        for (int c = 0; c < 10; c++) {
            u8 v = cursor_arrow[r][c];
            if (!v) continue;
            u32 col = (v == 1) ? 0xFF101010 : 0xFFF2F2F2;
            bb_pixel(mx + c, my + r, col);
        }
}

static void gui_render(void) {
    if (!backbuffer) return;
    render_wallpaper();
    render_icons();
    for (int i = 0; i < MAX_WINDOWS; i++)
        if (wins[i].used && wins[i].visible && i != focus_idx) render_window(&wins[i], i);
    if (focus_idx >= 0 && focus_idx < MAX_WINDOWS)
        render_window(&wins[focus_idx], focus_idx);
    render_taskbar();
    render_cursor();
    fb_blit_backbuffer();
}

/* ------------------------- entradas del ratón ------------------------- */
static i32 last_buttons = 0;

static void click_close(Window *w) {
    w->visible = 0;
    if (w->type == WIN_VIEWER) viewer_close_free(w);
    if (w->type == WIN_DEMO) {
        demo_running = 0;
        /* cerrar con la X tambien termina la tarea, para que un
         * 'demo on' posterior pueda relanzarla */
        if (demo_task_id >= 0) {
            task_kill(demo_task_id);
            demo_task_id = -1;
        }
    }
    if (focus_idx >= 0 && &wins[focus_idx] == w) focus_idx = -1;
}

void gui_mouse_update(void) {
    i32 mx = mouse_x, my = mouse_y;
    i32 btn = mouse_buttons;
    int pressed = (btn & 1) && !(last_buttons & 1);
    int released = !(btn & 1) && (last_buttons & 1);
    last_buttons = btn;

    if (pressed) {
        /* 1) botones de la barra de tareas */
        i32 y = (i32)fb.height - TB_HEIGHT;
        if (my >= y) {
            if (mx >= 6 && mx < 102) { wm_open_about(); return; }
            i32 bx = 112;
            for (int i = 0; i < MAX_WINDOWS; i++) {
                if (!wins[i].used || !wins[i].visible) continue;
                if (mx >= bx && mx < bx + 130) {
                    focus_idx = i;
                    return;
                }
                bx += 138;
                if (bx > (i32)fb.width - 200) break;
            }
            return;
        }
        /* 2) iconos del escritorio */
        int ic = icon_hit(mx, my);
        if (ic >= 0) {
            if (ic == 0) { wm_open_shell(); }
            else if (ic == 1) {
                /* lanzar la tarea si no existe (y relanzarla si fue
                 * cerrada antes con la X) */
                if (demo_task_id < 0)
                    demo_task_id = task_create("fenixdemo", demo_task, 1);
                wm_open_demo();
            }
            else if (ic == 2) { wm_open_editor(NULLP, 1); }
            else if (ic == 3) { wm_open_calc(); }
            else if (ic == 4) { wm_open_viewer("leeme.txt"); }
            else if (ic == 5) { sysinfo_open_window(); }
            else if (ic == 6) { wm_open_installer(); }
            else { wm_open_about(); }
            return;
        }
        /* 3) ventanas: cerrar / arrastrar / foco / botones del editor */
        for (int i = MAX_WINDOWS - 1; i >= 0; i--) {
            Window *w = &wins[i];
            if (!w->used || !w->visible) continue;
            if (mx >= w->x && mx < w->x + w->w && my >= w->y && my < w->y + w->h) {
                focus_idx = i;
                if (mx >= w->x + w->w - 22 && mx <= w->x + w->w - 6 &&
                    my >= w->y + 6 && my <= w->y + 22) {
                    click_close(w);
                } else if (my < w->y + 28) {
                    drag_idx = i;
                    drag_dx = mx - w->x;
                    drag_dy = my - w->y;
                } else if (w->type == WIN_EDITOR &&
                           editor_button_click(w, mx, my)) {
                    return;      /* Guardar/Limpiar ya gestionados */
                } else if (w->type == WIN_CALC &&
                           calc_button_click(w, mx, my)) {
                    return;      /* tecla de la calculadora */
                } else if (w->type == WIN_INST &&
                           installer_click(w, mx, my)) {
                    return;      /* botones del instalador */
                }
                return;
            }
        }
    }

    if (btn & 1) {
        if (drag_idx >= 0 && drag_idx < MAX_WINDOWS && wins[drag_idx].used) {
            Window *w = &wins[drag_idx];
            i32 nx = mx - drag_dx, ny = my - drag_dy;
            if (nx < 0) nx = 0;
            if (ny < 0) ny = 0;
            if (nx + w->w > (i32)fb.width) nx = (i32)fb.width - w->w;
            if (ny + w->h > (i32)fb.height - TB_HEIGHT) ny = (i32)fb.height - TB_HEIGHT - w->h;
            w->x = nx; w->y = ny;
        }
    } else {
        drag_idx = -1;
    }
    (void)released;
}

/* ------------------------- editor (subsistema de texto) ------------------------- */

/* ¿el punto (mx,my) toca un botón del editor? Si es así, lo ejecuta.
 * Devuelve 1 si consumió el click. */
int editor_button_click(Window *w, i32 mx, i32 my) {
    i32 sy = w->y + w->h - ED_STATUS_H;
    if (my < sy + 4 || my > sy + 4 + ED_BTN_H) return 0;
    /* Guardar (derecha, color de acento) */
    i32 sx = w->x + w->w - 8 - ED_BTN_SAVE_W;
    if (mx >= sx && mx < sx + ED_BTN_SAVE_W) {
        editor_save(w);
        return 1;
    }
    /* Limpiar (a su izquierda) */
    sx = w->x + w->w - 8 - ED_BTN_SAVE_W - 8 - ED_BTN_CLEAR_W;
    if (mx >= sx && mx < sx + ED_BTN_CLEAR_W) {
        editor_clear(w);
        return 1;
    }
    return 0;
}

/* vuelca el contenido de la ventana al RAMFS */
void editor_save(Window *w) {
    if (!w->cells || !w->fname[0]) return;
    static char buf[RAMFS_BUF];
    u32 len = 0;
    for (int r = 0; r < w->rows && len < sizeof(buf) - 2; r++) {
        int last = 0;
        for (int c = 0; c < w->cols; c++) {
            char ch = (char)(w->cells[r * w->cols + c] & 0xFF);
            if (ch && ch != ' ') last = c + 1;
        }
        for (int c = 0; c < last && len < sizeof(buf) - 2; c++)
            buf[len++] = (char)(w->cells[r * w->cols + c] & 0xFF);
        if (r < w->rows - 1) buf[len++] = '\n';
    }
    buf[len] = 0;
    if (ramfs_write(w->fname, buf, len) == 0)
        w->ed_saved = 1;
    klog("EDT", "archivo guardado en RAMFS");
}

/* borra todo el contenido */
void editor_clear(Window *w) {
    if (!w->cells) return;
    for (int i = 0; i < w->cols * w->rows; i++) w->cells[i] = ' ';
    w->ccx = w->ccy = 0;
    w->ed_saved = 0;
}

static void ed_scroll(Window *w) {
    memcpy(w->cells, w->cells + w->cols, (u32)(w->cols * (w->rows - 1)) * sizeof(u16));
    u16 *last = w->cells + w->cols * (w->rows - 1);
    for (int i = 0; i < w->cols; i++) last[i] = ' ';
    w->ccy = w->rows - 1;
}

/* teclas enviadas desde la tarea shell cuando la ventana editor tiene foco */
void editor_feed_key(Window *w, int key) {
    if (!w->cells) return;
    w->ed_saved = 0;

    if (key == '\n' || key == '\r') {
        w->ccx = 0;
        w->ccy++;
        if (w->ccy >= w->rows) ed_scroll(w);
        return;
    }
    if (key == '\b' || key == 127) {
        if (w->ccx > 0) w->ccx--;
        else if (w->ccy > 0) { w->ccy--; w->ccx = w->cols - 1; }
        if (w->ccy < w->rows && w->ccx < w->cols)
            w->cells[w->ccy * w->cols + w->ccx] = ' ';
        return;
    }
    switch (key) {
    case KEY_LEFT:  if (w->ccx > 0) w->ccx--; return;
    case KEY_RIGHT: if (w->ccx < w->cols - 1) w->ccx++; return;
    case KEY_UP:    if (w->ccy > 0) w->ccy--; return;
    case KEY_DOWN:  if (w->ccy < w->rows - 1) w->ccy++; return;
    case KEY_HOME:  w->ccx = 0; return;
    case KEY_END:   w->ccx = w->cols - 1; return;
    default: break;
    }
    if (key >= 0x100 || key < 32) return;
    if (w->ccy >= w->rows) { ed_scroll(w); }
    if (w->ccx >= w->cols) { w->ccx = 0; w->ccy++; if (w->ccy >= w->rows) ed_scroll(w); }
    w->cells[w->ccy * w->cols + w->ccx] = (u16)(u8)key | (u16)(0 << 8);
    w->ccx++;
    if (w->ccx >= w->cols) { w->ccx = 0; w->ccy++; if (w->ccy >= w->rows) ed_scroll(w); }
}

/* ------------------------- calculadora gráfica ------------------------- */

static void calc_show(Window *w, i64 v) {
    ksnprintf(w->c_disp, sizeof(w->c_disp), "%ld", v);
}

static void calc_apply(Window *w) {
    i64 v = 0;
    for (char *p = w->c_disp; *p >= '0' && *p <= '9'; p++) v = v * 10 + (*p - '0');
    switch (w->c_op) {
    case '+': w->c_acc += v; break;
    case '-': w->c_acc -= v; break;
    case 'x': w->c_acc *= v; break;
    case '/':
        if (v == 0) {
            strcpy(w->c_disp, "ERROR div/0");
            w->c_op = 0; w->c_fresh = 1; w->c_acc = 0;
            klogw("CALC", "division entre cero");
            return;
        }
        w->c_acc /= v;
        break;
    default: w->c_acc = v; break;
    }
    calc_show(w, w->c_acc);
    w->c_op = 0;
    w->c_fresh = 1;
}

static void calc_press(Window *w, char k) {
    if (k >= '0' && k <= '9') {
        if (w->c_fresh) {
            w->c_disp[0] = k; w->c_disp[1] = 0;
            w->c_fresh = 0;
        } else if (strlen(w->c_disp) < 14) {
            int l = (int)strlen(w->c_disp);
            w->c_disp[l] = k;
            w->c_disp[l + 1] = 0;
        }
        return;
    }
    if (k == 'C') {
        strcpy(w->c_disp, "0");
        w->c_acc = 0; w->c_op = 0; w->c_fresh = 1;
        return;
    }
    if (k == '=') {
        if (w->c_op) calc_apply(w);
        return;
    }
    if (k == '+' || k == '-' || k == 'x' || k == '/') {
        if (w->c_op && !w->c_fresh) calc_apply(w);   /* encadenar 2+3x4 */
        else {
            i64 v = 0;
            for (char *p = w->c_disp; *p >= '0' && *p <= '9'; p++) v = v * 10 + (*p - '0');
            w->c_acc = v;
        }
        w->c_op = k;
        w->c_fresh = 1;
    }
}

int calc_button_click(Window *w, i32 mx, i32 my) {
    i32 gy = w->y + 28 + CALC_DISP_H + 8;
    if (mx < w->x + 8 || my < gy) return 0;
    int c = (mx - (w->x + 8)) / (CALC_BTN_W + 4);
    int r = (my - gy) / (CALC_BTN_H + 4);
    if (c < 0 || c > 3 || r < 0 || r > 3) return 0;
    i32 bx = w->x + 8 + c * (CALC_BTN_W + 4);
    i32 by = gy + r * (CALC_BTN_H + 4);
    if (mx >= bx + CALC_BTN_W || my >= by + CALC_BTN_H) return 0;
    calc_press(w, calc_keys[r * 4 + c]);
    return 1;
}

void calc_feed_key(Window *w, int key) {
    if (key >= '0' && key <= '9') { calc_press(w, (char)key); return; }
    switch (key) {
    case '+': case '-': case 'x': case '*': calc_press(w, (key == '*') ? 'x' : (char)key); break;
    case '/': calc_press(w, '/'); break;
    case '=': case '\r': case '\n': calc_press(w, '='); break;
    case 'c': case 'C': case 27:    calc_press(w, 'C'); break;
    default: break;
    }
}

/* ------------------------- teclado del visor ------------------------- */

void viewer_feed_key(Window *w, int key) {
    int max_top = w->view_lines - w->rows;
    if (max_top < 0) max_top = 0;
    switch (key) {
    case KEY_UP:   if (w->view_top > 0) w->view_top--; break;
    case KEY_DOWN: if (w->view_top < max_top) w->view_top++; break;
    case KEY_HOME: w->view_top = 0; break;
    case KEY_END:  w->view_top = max_top; break;
    default: break;
    }
}

/* ------------------------- tareas del sistema ------------------------- */
void gui_task(void) {
    /* repinta la escena ~33 veces por segundo (sin depender de la fase
     * del planificador: con % N el residuo puede quedar bloqueado) */
    u64 last = 0;
    for (;;) {
        if (pit_ticks - last >= 3) {
            gui_mouse_update();
            gui_render();
            last = pit_ticks;
        }
        hlt_cpu();
    }
}

void demo_task(void) {
    demo_running = 1;
    Window *w = win_find(WIN_DEMO);
    u64 last = 0;
    while (demo_running) {
        if (pit_ticks - last >= 2) {
            last = pit_ticks;
            w = win_find(WIN_DEMO);
            if (!w || !w->visible) break;
            w->bx += w->bvx;
            w->by += w->bvy;
            if (w->bx - 12 < w->x + 2 || w->bx + 12 > w->x + w->w - 2) w->bvx = -w->bvx;
            if (w->by - 12 < w->y + 30 || w->by + 12 > w->y + w->h - 2) w->bvy = -w->bvy;
        }
        hlt_cpu();
    }
    demo_running = 0;
    for (;;) hlt_cpu();
}

void clock_task(void) {
    u64 last = (u64)-1;
    for (;;) {
        if ((pit_ticks / 100) != last) {
            last = pit_ticks / 100;
            rtc_read_datetime();
        }
        hlt_cpu();
    }
}

void gui_init(void) {
    for (int i = 0; i < MAX_WINDOWS; i++) wins[i].used = 0;
    gui_set_theme(theme_id);
    gui_ready = 1;
}
