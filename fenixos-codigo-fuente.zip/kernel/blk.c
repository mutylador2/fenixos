/* FenixOS — blk.c: capa de bloques unificada ATA PIO / AHCI (v1.3)
 *
 * Unifica los dos drivers de disco para consumidores (config persistente,
 * usuarios persistentes, sector del gestor de arranque, instalador):
 *  - AHCI (v1.3): SATA, el estándar en VirtualBox y equipos reales.
 *  - ATA PIO (v1.2): IDE, canal primario maestro (QEMU por defecto).
 *
 * También conoce la "zona de instalación" de FenixOS (partición 0x63 o
 * disco entero, según lo que comunicó stage2 en la BootInfo), para
 * colocar la configuración y el sector del menú multiboot. */
#include "fenixos.h"

#define BK_NONE 0
#define BK_ATA  1
#define BK_AHCI 2

static int backend = BK_NONE;
static u32 inst_base = 0;      /* base de la partición FenixOS (0 = disco) */
static u32 inst_sectors = 0;   /* tamaño de la zona (0 = desconocido) */
static u32 boot_flags = 0;     /* banderas de arranque (BootInfo) */

int blk_init(BootInfo *bi) {
    if (bi) {
        inst_base = bi->part_base_lba;
        inst_sectors = bi->part_sectors;
        boot_flags = bi->boot_flags;
    }
    /* AHCI localiza su HBA por PCI: garantizar la enumeración aquí
     * (net_init la reutiliza después; es idempotente) */
    if (pci_count() == 0) pci_init();
    ata_init();
    ahci_init();
    if (ahci_present()) {
        backend = BK_AHCI;
        klog("BLK", "backend de bloques: AHCI (SATA)");
    } else if (ata_present()) {
        backend = BK_ATA;
        klog("BLK", "backend de bloques: ATA PIO (IDE primario maestro)");
    } else {
        backend = BK_NONE;
        klogw("BLK", "sin discos ATA/AHCI utilizables");
    }
    return backend != BK_NONE ? 0 : -1;
}

void blk_set_install_area(u32 base, u32 sectors) {
    inst_base = base;
    inst_sectors = sectors;
}
u32 blk_part_base(void)    { return inst_base; }
u32 blk_part_sectors(void) { return inst_sectors; }
u32 blk_bootflags(void)    { return boot_flags; }

int blk_present(void) { return backend != BK_NONE; }

const char *blk_backend(void) {
    switch (backend) {
    case BK_AHCI: return "AHCI";
    case BK_ATA:  return "ATA-PIO";
    default:      return "-";
    }
}

const char *blk_model(void) {
    if (backend == BK_AHCI) return ahci_port_model(0);
    if (backend == BK_ATA)  return ata_model_name();
    return "";
}

u32 blk_sectors(void) {
    if (backend == BK_AHCI) return ahci_port_sectors(0);
    if (backend == BK_ATA)  return ata_sectors_count();
    return 0;
}

int blk_read(u32 lba, void *buf) {
    if (backend == BK_AHCI) return ahci_read(0, lba, buf);
    if (backend == BK_ATA)  return ata_read_sector(lba, buf);
    return -1;
}

int blk_write(u32 lba, const void *buf) {
    if (backend == BK_AHCI) return ahci_write(0, lba, buf);
    if (backend == BK_ATA)  return ata_write_sector(lba, buf);
    return -1;
}

/* LBA absoluto del sector de configuración del sistema: final de la
 * zona de instalación (partición o disco) menos un margen. */
static u32 area_end(void) {
    if (inst_sectors) return inst_base + inst_sectors;
    return blk_sectors();
}

u32 blk_config_lba(void) {
    u32 end = area_end();
    return end ? end - 8 : 0;
}

u32 blk_users_lba(void) {
    u32 lba = blk_config_lba();
    return lba ? lba - 1 : 0;
}

/* ---------- sector del gestor de arranque (menú multiboot) ---------- */

int blk_write_bootconfig(u8 def_opt, u8 timeout) {
    if (!blk_present()) return -1;
    if (boot_flags & BF_CD_BOOT) return -2;       /* desde CD no hay medio */
    static u8 sector[512];
    memset(sector, 0, sizeof(sector));
    memcpy(sector, BOOTCFG_MAGIC, 8);
    sector[BOOTCFG_OFF_OPT] = (def_opt >= 1 && def_opt <= 5) ? def_opt : 1;
    sector[BOOTCFG_OFF_TMO] = timeout > 9 ? 9 : timeout;
    u32 lba = inst_base + BOOTCFG_REL_LBA;
    int wr = blk_write(lba, sector);
    if (wr != 0) {
        klogf(LOG_WARN, "BLK", "escritura bootcfg fallo (r=%d) en LBA %u", wr, lba);
        return -3;
    }
    klogf(LOG_INFO, "BLK", "config de arranque escrita: opcion %u, %u s (LBA %u)",
          sector[BOOTCFG_OFF_OPT], sector[BOOTCFG_OFF_TMO], lba);
    return 0;
}

int blk_read_bootconfig(u8 *def_opt, u8 *timeout) {
    if (!blk_present()) return -1;
    static u8 sector[512];
    if (blk_read(inst_base + BOOTCFG_REL_LBA, sector) != 0) return -2;
    if (memcmp(sector, BOOTCFG_MAGIC, 8) != 0) return 1;   /* sin sector */
    if (def_opt) *def_opt = sector[BOOTCFG_OFF_OPT];
    if (timeout) *timeout = sector[BOOTCFG_OFF_TMO];
    return 0;
}
