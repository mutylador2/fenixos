/* FenixOS — mouse.c: driver de ratón PS/2 (IRQ12, paquetes de 3 bytes)
 *
 * Bug corregido (v1.0.1): los comandos de dispositivo (0xF6/0xF4) se
 * escribían directamente en 0x60 SIN el prefijo 0xD4, así que los
 * recibía el TECLADO — que además los confirma con ACK, haciendo que
 * todo pareciera correcto. El ratón nunca activaba el reporte de
 * datos y por eso la flecha no se movía.
 *
 * Regla PS/2: todo byte destinado al ratón debe ir precedido de
 * 0xD4 escrito en el puerto 0x64 (registro de comandos). */
#include "fenixos.h"

#define PS2_DATA 0x60
#define PS2_STAT 0x64

volatile int mouse_x = 0, mouse_y = 0, mouse_buttons = 0;

static int cycle = 0;
static u8 pkt[3];
static int inited = 0;

static int wait_write(void) {
    for (int i = 0; i < 100000; i++)
        if (!(inb(PS2_STAT) & 2)) return 1;
    return 0;
}

static int wait_read(void) {
    for (int i = 0; i < 100000; i++)
        if (inb(PS2_STAT) & 1) return 1;
    return 0;
}

static void flush_output(void) {
    /* drena bytes pendientes en el búfer de salida (ACKs rezagados, etc.) */
    for (int i = 0; i < 64 && (inb(PS2_STAT) & 1); i++)
        (void)inb(PS2_DATA);
}

/* Espera el ACK (0xFA) del ratón.
 * Ruta estándar: OBF en el registro de estado (hardware real y VirtualBox
 * lo usan). Ruta alternativa descubierta en QEMU 10: el ACK queda en la
 * cola del canal PS/2 SIN levantar OBF mientras IF=0, pero una lectura
 * directa de 0x60 lo recupera (modelo "pull").
 * Devuelve 1 = ACK, 0 = resend (0xFE), -1 = nada. */
static int ack_wait(void) {
    for (int i = 0; i < 60000; i++) {
        if (inb(PS2_STAT) & 1) {
            u8 v = inb(PS2_DATA);
            if (v == 0xFA) return 1;
            if (v == 0xFE) return 0;
            /* otro byte (ruido): descartado y seguimos */
        }
    }
    /* sin OBF tras el tiempo límite: sondeo directo (comportamiento QEMU) */
    u8 v = inb(PS2_DATA);
    if (v == 0xFA) return 1;
    if (v == 0xFE) return 0;
    return -1;
}

/* Enviar un comando AL RATÓN (con prefijo 0xD4) y esperar su ACK.
 * Reintenta hasta 3 veces si el dispositivo pide reenvío (0xFE). */
static int mouse_cmd(u8 cmd) {
    for (int intento = 0; intento < 3; intento++) {
        if (!wait_write()) return 0;
        outb(PS2_STAT, 0xD4);            /* "el próximo byte es para el ratón" */
        if (!wait_write()) return 0;
        outb(PS2_DATA, cmd);

        int r = ack_wait();
        if (r == 1) return 1;            /* ACK */
        if (r != 0) break;               /* timeout: sin ACK */
        /* r == 0: el dispositivo pidió reenvío -> otro intento */
    }
    return 0;
}

void mouse_init(void) {
    inited = 0;
    cycle = 0;
    mouse_x = (int)fb.width / 2;
    mouse_y = (int)fb.height / 2;
    mouse_buttons = 0;

    flush_output();

    /* habilitar el puerto auxiliar (el ratón): comando de CONTROLADOR,
     * va a 0x64 sin ACK */
    wait_write();
    outb(PS2_STAT, 0xA8);

    /* byte de configuración del controlador: IRQ12 habilitada (bit 1),
     * reloj del ratón habilitado (bit 5 a cero). El bit de traducción
     * (0x40) NO se toca: pertenece al puerto del teclado. */
    wait_write();
    outb(PS2_STAT, 0x20);
    wait_read();
    u8 cfg = inb(PS2_DATA);
    cfg |= 0x02;
    cfg &= (u8)~0x20;
    wait_write();
    outb(PS2_STAT, 0x60);
    wait_write();
    outb(PS2_DATA, cfg);

    /* dispositivo: valores por defecto y activar reporte de datos.
     * El 0xF4 es el que hace que el ratón empiece a enviar paquetes. */
    int ok_f6 = mouse_cmd(0xF6);
    int ok_f4 = mouse_cmd(0xF4);

    pic_set_mask(12, 0);
    inited = 1;

    if (ok_f6 && ok_f4)
        klog("HW", "raton PS/2 habilitado (ACK ok, IRQ12 activa)");
    else
        klog("HW", "raton PS/2 activo (comandos enviados, ACK no visible en este emulador)");
}

/* Procesa un byte del paquete estándar de 3 bytes:
 *   pkt[0]: bit3=1 siempre, bit0 izq, bit1 der, bit2 central,
 *           bit4 signo X, bit5 signo Y
 *   pkt[1]: delta X (9 bits con el signo), pkt[2]: delta Y */
static void mouse_feed(u8 d) {
    if (cycle == 0) {
        if (d == 0xFA || d == 0xFE) return;   /* ACK/resend tardío: descartar */
        if (!(d & 0x08)) return;              /* resincronizar: bit3 = 1 */
    }

    pkt[cycle++] = d;
    if (cycle < 3) return;
    cycle = 0;

    int dx = (int)pkt[1];
    int dy = (int)pkt[2];
    if (pkt[0] & 0x10) dx -= 256;             /* signo X (9 bits) */
    if (pkt[0] & 0x20) dy -= 256;             /* signo Y (9 bits) */

    mouse_x += dx;
    mouse_y -= dy;                            /* eje Y invertido en pantalla */

    if (mouse_x < 0) mouse_x = 0;
    if (mouse_y < 0) mouse_y = 0;
    if (mouse_x >= (int)fb.width) mouse_x = (int)fb.width - 1;
    if (mouse_y >= (int)fb.height) mouse_y = (int)fb.height - 1;

    mouse_buttons = pkt[0] & 0x07;
}

void mouse_handler(void) {
    if (!inited) { (void)inb(PS2_DATA); return; }

    /* drena TODOS los bytes disponibles: si el emulador agrupa
     * interrupciones, los 3 bytes pueden llegar juntas */
    while (inb(PS2_STAT) & 1)
        mouse_feed(inb(PS2_DATA));
}
