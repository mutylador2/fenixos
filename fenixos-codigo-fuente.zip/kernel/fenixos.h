/* =====================================================================
 * FenixOS — fenixos.h
 * Declaraciones globales del kernel (tipos, bootinfo, APIs de módulos)
 * Arquitectura por capas: HAL -> Kernel -> Executive -> Subsistemas
 * ===================================================================== */
#ifndef FENIXOS_H
#define FENIXOS_H

#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdbool.h>

/* ---------------- Tipos ---------------- */
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t   i8;
typedef int16_t  i16;
typedef int32_t  i32;
typedef int64_t  i64;

#define FENIX_MAGIC  0x314E5846u   /* 'FNX1' */
#define PAGE_SIZE 4096u
#define NULLP ((void*)0)

/* ---------------- Estructura de arranque (llenada por stage2) ----------------
 * v1.3: añade banderas de arranque (menú multiboot), geometría de la
 * instalación (partición FenixOS o disco completo) y datos de la GPU
 * (cadenas OEM del VBE) para el panel de Información del Sistema. */
typedef struct BootInfo {
    u32 magic;          /* 0x00: FNX1 */
    u32 fb_paddr;       /* 0x04: dirección física del framebuffer */
    u32 fb_pitch;       /* 0x08: bytes por línea */
    u32 fb_width;       /* 0x0C: ancho en píxeles */
    u32 fb_height;      /* 0x10: alto en píxeles */
    u32 fb_bpp;         /* 0x14: bits por píxel (32 o 16) */
    u32 e820_count;     /* 0x18: nº de entradas del mapa de memoria */
    u32 e820_ptr;       /* 0x1C: dirección física del mapa e820 */
    u32 kernel_sectors; /* 0x20: sectores ocupados por el kernel */
    u32 boot_drive;     /* 0x24: unidad de arranque BIOS */
    u32 stage2_ok;      /* 0x28: modo de lectura de stage1 (0 LBA/1 CHS/2 CD) */
    u32 boot_flags;     /* 0x2C: bit0 = modo seguro, bit1 = arranque desde CD */
    u32 kernel_src_lba; /* 0x30: si != 0, LBA absoluto del kernel (ISO híbrido) */
    u32 part_base_lba;  /* 0x34: base de la partición FenixOS (0 = disco entero) */
    u32 part_sectors;   /* 0x38: tamaño de la partición (0 = desconocido) */
    u32 vbe_mem64k;     /* 0x3C: TotalMemory del VBE (unidades de 64 KB) */
    char gpu_vendor[28];   /* 0x40: OEMVendorName del VBE */
    char gpu_product[28];  /* 0x5C: OEMProductName del VBE */
    u32 reserved[2];    /* 0x78 */
} BootInfo;

/* banderas de arranque (BootInfo.boot_flags) */
#define BF_SAFE_MODE 0x1u   /* menú opt 2: sin red/ratón/sonido, VBE reducido */
#define BF_CD_BOOT   0x2u   /* el kernel llegó desde el blob del CD (sin menú) */

/* sector de configuración del gestor de arranque (menú multiboot, v1.3)
 * LBA = part_base_lba + 41; firma + opción por defecto + timeout */
#define BOOTCFG_MAGIC     "FNXBOOT1"
#define BOOTCFG_OFF_OPT   8       /* u8: opción por defecto 1..5 */
#define BOOTCFG_OFF_TMO   9       /* u8: segundos de autoarranque (0 = esperar) */
#define BOOTCFG_DEF_OPT   1
#define BOOTCFG_DEF_TMO   8
/* dentro de la partición/de la zona FenixOS: LBA relativo del sector */
#define BOOTCFG_REL_LBA   41
#define STAGE2_REL_SECT   1       /* stage2 en base+1..base+40 (40 sectores) */
#define STAGE2_SECTORS    40
#define KERNEL_REL_LBA    128     /* kernel en base+128 */

typedef struct E820Entry {
    u64 base;
    u64 len;
    u32 type;           /* 1 = usable */
    u32 acpi;           /* extended attributes */
} E820Entry;

#define E820_USABLE 1
#define MEM_LIMIT_1GB 0x40000000u

/* ---------------- E/S (HAL) ---------------- */
static inline void outb(u16 port, u8 val)  { __asm__ volatile("outb %0, %1" :: "a"(val), "Nd"(port)); }
static inline void outw(u16 port, u16 val) { __asm__ volatile("outw %0, %1" :: "a"(val), "Nd"(port)); }
static inline void outl(u16 port, u32 val) { __asm__ volatile("outl %0, %1" :: "a"(val), "Nd"(port)); }
static inline u8 inb(u16 port)             { u8 r; __asm__ volatile("inb %1, %0" : "=a"(r) : "Nd"(port)); return r; }
static inline u16 inw(u16 port)            { u16 r; __asm__ volatile("inw %1, %0" : "=a"(r) : "Nd"(port)); return r; }
static inline u32 inl(u16 port)            { u32 r; __asm__ volatile("inl %1, %0" : "=a"(r) : "Nd"(port)); return r; }
static inline void io_wait(void)           { outb(0x80, 0); }
static inline void cli_irq(void)           { __asm__ volatile("cli" ::: "memory"); }
static inline void sti_irq(void)           { __asm__ volatile("sti" ::: "memory"); }
static inline void hlt_cpu(void)           { __asm__ volatile("hlt"); }

/* ---------------- serial.c (COM1, registro de arranque/depuración) -------- */
void serial_init(void);
void serial_putc(char c);
void serial_write(const char *s);

/* ---------------- klog.c (registro de eventos y errores, v1.2) ------------- */
#define LOG_INFO  0
#define LOG_WARN  1
#define LOG_ERROR 2
void klog(const char *tag, const char *msg);          /* nivel INFO */
void klogw(const char *tag, const char *msg);         /* nivel WARN */
void kloge(const char *tag, const char *msg);         /* nivel ERROR */
void klogf(u8 level, const char *tag, const char *fmt, ...);
int  klog_count(void);
int  klog_get(int idx, u32 *secs, u8 *level, char *tag, char *msg);
void klog_clear(void);
int  klog_save(void);                                  /* snapshot -> RAMFS */

/* ---------------- string.c ---------------- */
void *memset(void *dst, int v, size_t n);
void *memcpy(void *dst, const void *src, size_t n);
void *memmove(void *dst, const void *src, size_t n);
int  memcmp(const void *a, const void *b, size_t n);
size_t strlen(const char *s);
int  strcmp(const char *a, const char *b);
int  strncmp(const char *a, const char *b, size_t n);
char *strcpy(char *dst, const char *src);
char *strncpy(char *dst, const char *src, size_t n);
char *strcat(char *dst, const char *src);
char *strstr(const char *hay, const char *needle);
int  strncasecmp_fenix(const char *a, const char *b, u32 n);

/* ---------------- printf.c (mini, sin floats) ---------------- */
int kvsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
int ksnprintf(char *buf, size_t size, const char *fmt, ...);
void kprintf(const char *fmt, ...);          /* a serial */

/* ---------------- gdt.c ---------------- */
void gdt_init(void);

/* ---------------- idt.c ---------------- */
void idt_init(void);
void panic(const char *reason, u64 vector, u64 rip, u64 fault_rsp);
u64  isr_dispatch(u64 frame_addr);           /* usado por isr.asm */

/* ---------------- pic.c ---------------- */
void pic_remap(void);
void pic_eoi(u8 irq);
void pic_set_mask(u8 irq, int masked);

/* ---------------- pit.c ---------------- */
void pit_init(u32 hz);
void pit_tick(void);
extern volatile u64 pit_ticks;
void pit_sleep_ticks(u64 n);

/* ---------------- kbd.c (teclado PS/2) ---------------- */
void kbd_init(void);
void kbd_handler(void);            /* llamado desde IRQ1 */
int  kbd_available(void);
int  kbd_getc(void);               /* -1 si vacío; devuelve ASCII o token >=0x100 */
#define KEY_UP    0x110
#define KEY_DOWN  0x111
#define KEY_LEFT  0x112
#define KEY_RIGHT 0x113
#define KEY_HOME  0x114
#define KEY_END   0x115
#define KEY_DEL   0x116

/* ---------------- mouse.c (ratón PS/2) ---------------- */
void mouse_init(void);
void mouse_handler(void);          /* llamado desde IRQ12 */
extern volatile int mouse_x, mouse_y, mouse_buttons; /* bit0 izq, bit1 der */

/* ---------------- ramfs.c (sistema de archivos en memoria) ---------------- */
#define RAMFS_BUF 4096                 /* tamaño de búfer de lectura estándar */
void ramfs_init(void);
int  ramfs_write(const char *name, const char *data, u32 len); /* 0 ok */
int  ramfs_read(const char *name, char *buf, u32 max);         /* bytes o -1 */
int  ramfs_exists(const char *name);
int  ramfs_delete(const char *name);                           /* 0 ok, -1 no existe */
int  ramfs_get(int idx, const char **name, u32 *size);         /* iterar archivos */
int  ramfs_count(void);
u32  ramfs_bytes_used(void);
u32  ramfs_file_max(void);
int  ramfs_slots(void);                       /* capacidad total (v1.2) */

/* ---------------- ata.c (driver de disco ATA PIO, v1.2) --------------------
 * v1.4: canal secundario para discos de datos (p.ej. FAT32) */
int  ata_init(void);
int  ata_present(void);
u32  ata_sectors_count(void);
const char *ata_model_name(void);
int  ata_read_sector(u32 lba, void *buf);
int  ata_write_sector(u32 lba, const void *buf);
u32  ata_config_lba(void);
int  ata2_init(void);                          /* canal secundario (v1.4) */
int  ata2_present(void);
u32  ata2_sectors_count(void);
const char *ata2_model_name(void);
int  ata2_read_sector(u32 lba, void *buf);
int  ata2_write_sector(u32 lba, const void *buf);

/* ---------------- ahci.c (driver SATA AHCI para discos modernos, v1.3) ----- */
int  ahci_init(void);
int  ahci_present(void);
int  ahci_port_count(void);
const char *ahci_port_model(int port);
u32  ahci_port_sectors(int port);
int  ahci_read(int port, u32 lba, void *buf);
int  ahci_write(int port, u32 lba, const void *buf);

/* ---------------- blk.c (capa de bloques unificada ATA/AHCI, v1.3) --------- */
int  blk_init(BootInfo *bi);               /* inicializa ata + ahci + bootinfo */
int  blk_present(void);                    /* ¿hay algún disco utilizable? */
const char *blk_backend(void);             /* "AHCI", "ATA-PIO" o "-" */
const char *blk_model(void);
u32  blk_sectors(void);
int  blk_read(u32 lba, void *buf);
int  blk_write(u32 lba, const void *buf);
u32  blk_config_lba(void);                 /* sector de config al final del área */
u32  blk_users_lba(void);                  /* sector de usuarios, junto al de config */
void blk_set_install_area(u32 base, u32 sectors); /* partición FenixOS (bootinfo) */
u32  blk_part_base(void);
u32  blk_part_sectors(void);
u32  blk_bootflags(void);
int  blk_write_bootconfig(u8 def_opt, u8 timeout);  /* sector del menú multiboot */
int  blk_read_bootconfig(u8 *def_opt, u8 *timeout);

/* ---------------- config.c (configuración persistente, v1.2) --------------- */
void config_defaults(void);
int  config_load_disk(void);
int  config_save_disk(void);
const char *config_get(const char *key);
int  config_set(const char *key, const char *val);
int  config_pair(int idx, const char **key, const char **val);
const char *config_hostname(void);
void config_refresh_hostname(void);

/* ---------------- users.c (usuarios, roles y permisos, v1.2) ----------------
 * v1.3: las cuentas se persisten en disco (sector blk_users_lba) para
 * que 'user_add' sobreviva al reinicio. */
#define ROL_INVITADO 0
#define ROL_USUARIO  1
#define ROL_ADMIN    2
void users_init(void);
int  user_login(const char *name, const char *pass);   /* 0 ok */
int  user_logout(void);
const char *user_current_name(void);
int  user_current_role(void);
const char *role_name(int r);
int  user_list(int idx, const char **name, int *role);
int  user_perm_ok(int required);
int  user_add(const char *name, const char *pass, int role);
u32  user_hash(const char *s);
int  users_save_disk(void);
int  users_load_disk(void);

/* ---------------- sound.c (altavoz interno del PC + AC97) ---------------- */
void sound_play(u32 freq_hz, u32 ms);
void sound_melodia_fenix(void);
int  sound_ac97_ok(void);                       /* v1.4: ¿hay AC97? */
void sound_melodia_ac97(void);                  /* melodía por AC97 */
void sound_tone_ac97(u32 freq_hz, u32 ms);      /* tono por AC97 */

/* ---------------- fat32.c (FAT32 lectura/escritura, v1.4) ----------------- */
int  fat_mount(void);                           /* 0 ok */
int  fat_present(void);
const char *fat_label(void);
const char *fat_where(void);                    /* de dónde se montó */
u32  fat_total_mb(void);
u32  fat_free_kb(void);
u32  fat_bytes_per_cluster(void);
u32  fat_root_entries_max(void);
int  fat_dir_count(void);
int  fat_dir_get(int idx, char *name_out, u32 namesz, u32 *size, int *is_dir);
int  fat_read_file(const char *name, char *buf, u32 max);   /* bytes o <0 */
int  fat_write_file(const char *name, const char *data, u32 len); /* 0 ok */
int  fat_delete_file(const char *name);         /* 0 ok */

/* ---------------- ac97.c (audio AC'97 por DMA, v1.4) ---------------------- */
int  ac97_init(void);
int  ac97_present(void);
u32  ac97_played_frames(void);
u32  ac97_buffers_done(void);
u16  ac97_io_base(void);
int  ac97_play(const i16 *pcm, u32 nframes);    /* bloqueante */

/* ---------------- httpd.c (servidor web, v1.4) ----------------------------- */
int  httpd_start(void);                         /* servidor on */
int  httpd_stop(void);                          /* servidor off */
int  httpd_active(void);
u32  httpd_served_count(void);

/* ---------------- rtc.c ---------------- */
void rtc_read_datetime(void);
extern volatile u32 rtc_sec, rtc_min, rtc_hour, rtc_day, rtc_month, rtc_year, rtc_wday;
const char *rtc_month_name(u32 m);
const char *rtc_day_name(u32 wd);

/* ---------------- power.c ---------------- */
void power_reboot(void);
void power_shutdown(void);

/* ---------------- pmm.c ---------------- */
void pmm_init(BootInfo *bi);
u64  pmm_alloc(void);              /* 4KB, dirección física == virtual */
void pmm_free(u64 page);
u64  pmm_alloc_contig(u32 pages);
extern u64 pmm_total_pages, pmm_used_pages;
extern u64 kernel_start_addr, kernel_end_addr;

/* ---------------- heap.c ---------------- */
void heap_init(void);
void *kmalloc(size_t n);
void kfree(void *p);
void *kcalloc(size_t n);
extern u64 heap_start, heap_end, heap_used, heap_size;

/* ---------------- fb.c (HAL gráfico) ---------------- */
typedef struct { u32 paddr; u32 pitch; u32 width, height, bpp; } FbInfo;
extern FbInfo fb;
void fb_init(BootInfo *bi);
void fb_pixel(i32 x, i32 y, u32 color);
void fb_fill_rect(i32 x, i32 y, i32 w, i32 h, u32 color);
void fb_rect(i32 x, i32 y, i32 w, i32 h, u32 color);
void fb_fill(u32 color);
void fb_char(i32 x, i32 y, char c, u32 fg, u32 bg);
void fb_text(i32 x, i32 y, const char *s, u32 fg, u32 bg);
void fb_copy_row(i32 dst_y, i32 src_y, i32 x, i32 w);
u32  fb_rgb(u8 r, u8 g, u8 b);
void fb_blit_backbuffer(void);
extern u32 *backbuffer;
void bb_pixel(i32 x, i32 y, u32 c);
void bb_fill_rect(i32 x, i32 y, i32 w, i32 h, u32 c);
void bb_rect(i32 x, i32 y, i32 w, i32 h, u32 c);
void bb_char(i32 x, i32 y, char c, u32 fg, u32 bg);
void bb_text(i32 x, i32 y, const char *s, u32 fg, u32 bg);
void bb_text_t(i32 x, i32 y, const char *s, u32 fg);
void bb_fill(u32 c);

/* ---------------- console.c (terminal de arranque sobre fb) ---------------- */
void console_init(void);
void console_putc(char c);
void console_puts(const char *s);
void console_clear(void);

/* ---------------- task.c (multitarea round-robin) ---------------- */
#define MAX_TASKS 8
#define TASK_KSTACK_PAGES 4   /* 16KB por tarea */
typedef enum { T_READY, T_BLOCKED, T_DEAD } TaskState;
typedef struct {
    u64 regs[15];             /* r15..rax (orden de PUSHALL) */
    u64 vector, err;
    u64 rip, cs, rflags;
    u64 rsp, ss;              /* slots del marco iretq de modo largo (5 campos) */
} Frame;
typedef struct Task {
    int id;
    char name[16];
    TaskState state;
    int killable;
    u64 resume_rsp;
    u64 kstack_phys;
    u64 switches;                 /* veces que el planificador la eligió (v1.2) */
    struct Task *next;
} Task;
extern Task tasks[MAX_TASKS];
extern Task *current_task;
void task_init(void);
int  task_create(const char *name, void (*fn)(void), int killable);
void task_kill(int id);
void task_wait_input(void);   /* bloquea hasta que llegue una tecla */
void task_dump(void);         /* usado por el comando ps */
int  task_count_alive(void);
u64  task_switch_schedule(u64 frame_addr);

/* ---------------- gui.c (Executive gráfico) ---------------- */
#define TB_HEIGHT 36
#define FONT_W 8
#define FONT_H 16
#define MAX_WINDOWS 8
#define SHELL_COLS_MAX 96
#define SHELL_ROWS_MAX 40

typedef enum { WIN_NONE, WIN_SHELL, WIN_DEMO, WIN_ABOUT, WIN_EDITOR,
               WIN_CALC, WIN_VIEWER, WIN_INST } WinType;
typedef struct Window {
    int used, visible;
    WinType type;
    i32 x, y, w, h;
    char title[28];
    u16 *cells;                       /* char | (attr<<8), attr = índice de color */
    int cols, rows, ccx, ccy;
    i32 bx, by, bvx, bvy;             /* demo: pelota */
    char fname[24];                   /* editor: archivo destino */
    int ed_saved;                     /* editor: destello "guardado" */
    /* calculadora (v1.2) */
    i64 c_acc;                        /* acumulador */
    char c_op;                        /* operación pendiente: 0 + - x / */
    char c_disp[16];                  /* texto del visor */
    int  c_fresh;                     /* 1 = siguiente dígito reinicia el visor */
    /* visor de archivos / navegador (v1.2) */
    char *view_buf;                   /* contenido (kmalloc) o NULL */
    u32   view_len;
    int   view_top;                   /* primera línea visible */
    int   view_lines;                 /* nº de líneas del contenido */
} Window;

void gui_init(void);
void gui_task(void);
void gui_set_theme(int theme);
void gui_mouse_update(void);
extern int gui_ready;
Window *gui_shell_window(void);
Window *gui_demo_window(void);
Window *gui_focused_window(void);       /* ventana con foco (o NULL) */
int gui_get_theme(void);

/* ---------------- editor (subsistema de texto gráfico) ---------------- */
void wm_open_editor(const char *fname, int load); /* fname NULL = nuevo */
void editor_feed_key(Window *w, int key);         /* teclas desde la shell */
void editor_save(Window *w);                      /* botón Guardar -> RAMFS */
void editor_clear(Window *w);                     /* botón Limpiar */
int  editor_button_click(Window *w, i32 mx, i32 my); /* 1 si tocó un botón */

/* ---------------- calculadora gráfica (v1.2) ---------------- */
void wm_open_calc(void);
void calc_feed_key(Window *w, int key);
int  calc_button_click(Window *w, i32 mx, i32 my);

/* ---------------- visor de archivos / navegador (v1.2) ---------------- */
Window *wm_open_viewer(const char *fname);              /* RAMFS -> visor */
Window *wm_open_nav(const char *title, char *buf, u32 len); /* texto libre */
void viewer_feed_key(Window *w, int key);               /* scroll */
void viewer_close_free(Window *w);
u32 shell_attr_color(u8 attr);
extern int demo_running;
extern int demo_task_id;
/* Paleta de temas */
typedef struct Theme {
    u32 wp_top, wp_bottom;     /* gradiente del fondo */
    u32 accent;                /* color de acento (taskbar/títulos) */
    u32 taskbar_bg, taskbar_border;
    u32 win_bg, win_title_focus, win_title_unfocus;
} Theme;
extern Theme current_theme;
#define THEME_FUEGO 0
#define THEME_AZUL  1
#define THEME_BOSQUE 2
#define THEME_VAPOR 3
const char *theme_name(int t);

/* ---------------- shell.c (subsistema FenixShell) ---------------- */
void shell_task(void);
void shell_spawn(void);
void shell_feed_key(int key);  /* llamada cuando la ventana shell tiene foco */
void shell_newline(void);

/* ---------------- demo/about (subsistemas visuales) ---------------- */
void demo_task(void);
void clock_task(void);
void demo_toggle(void);
extern int demo_running;

/* ================= Declaraciones internas compartidas ================= */
void kmain(BootInfo *bi);
void wm_open_shell(void);
void wm_open_demo(void);
void wm_open_about(void);

/* ---------------- fx.c (FenixScript + extensiones, v1.2) ---------------- */
int  fx_run(const char *fname, Window *out);      /* 0 ok */
int  fx_list(int idx, const char **name, const char **meta); /* extensiones .fx */
extern void shell_exec_hook(const char *line);     /* definido en shell.c */

/* ---------------- instalador.c (instalador gráfico, v1.3) ----------------- */
void wm_open_installer(void);
int  installer_click(Window *w, i32 mx, i32 my);   /* 1 si consumió el click */
void installer_render(Window *w);                   /* pintado desde gui.c */

/* ---------------- sysinfo.c (información del sistema, v1.3) --------------- */
/* construye un informe de hardware (CPU, RAM, GPU, discos, PCI, USB,
 * red, audio) en un buffer kmalloc y lo abre en el visor */
void sysinfo_open_window(void);
int  sysinfo_build(char *buf, u32 cap);
const char *cpu_brand(void);
const char *cpu_vendor(void);

/* ---------------- bootembed (stage1/stage2 incrustados, v1.3) ------------- */
extern const u8 fenix_embed_stage1[];   /* 512 bytes tras el parcheo */
extern const u8 fenix_embed_stage2[];   /* 40*512 bytes tras el parcheo */
#define EMBED_STAGE1_SIZE 512
#define EMBED_STAGE2_SIZE (40 * 512)

/* ---------------- win.c (FenixCompat MZ/PE, v1.2) ---------------- */
int  win_analyze(const char *fname, Window *out); /* 0 ok, -1 no existe, -2 no exe */
void win_sample_install(void);                    /* instala muestra.exe en RAMFS */

/* ---------------- pci.c (enumeración PCI, v1.2) ---------------- */
typedef struct {
    u8  bus, dev, func;
    u16 vendor, device;
    u8  class_code, subclass, prog_if;
    u32 bar[6];
    u8  irq_line, irq_pin;
} PciDev;
int      pci_init(void);
int      pci_count(void);
PciDev  *pci_get(int idx);
PciDev  *pci_find(u16 vendor, u16 device);

/* ---------------- usb.c (detección de controladoras USB, v1.2) ------------- */
int  usb_scan(void);                              /* nº de controladoras USB */
int  usb_info(int idx, const char **type, u8 *bus, u8 *dev);

/* ---------------- e1000.c (driver de red Intel e1000, v1.2) ---------------- */
int  e1000_init(void);
int  e1000_present(void);
void e1000_mac(u8 mac_out[6]);
int  e1000_send(const void *data, u32 len);       /* trama Ethernet completa */
int  e1000_poll(void *buf, u32 bufsize);          /* >0: bytes recibidos */
extern int net_link_up;

/* ---------------- net.c (pila TCP/IP, v1.2) ---------------- */
int  net_init(void);                              /* pci + e1000 + config */
int  net_ready(void);
u32  net_my_ip(void);
u32  net_gateway(void);
u32  net_dns(void);
void net_set_ips(u32 ip, u32 gw, u32 dns);
void net_mac(u8 mac_out[6]);
u32  net_tx_count(void);
u32  net_rx_count(void);
int  net_ip_parse(const char *s, u32 *out);       /* "10.0.2.15" -> u32 */
void net_ip_str(u32 ip, char *buf, u32 size);
int  net_ping(u32 ip, u32 *rtt_ms);               /* 1 eco, 0 fallo */
u32 net_dns_resolve(const char *name);            /* 0 = fallo */

/* socket TCP minimal (una conexión activa: cliente o servidor) */
int  net_tcp_connect(u32 ip, u16 port);
int  net_tcp_send(const void *data, u32 len);
int  net_tcp_recv(void *buf, u32 max, u32 timeout_ticks); /* bytes o -1 */
void net_tcp_close(void);
int  net_tcp_connected(void);

/* modo servidor TCP (v1.4) */
int  net_tcp_listen(u16 port);                  /* escucha en un puerto */
int  net_tcp_listening(void);                   /* ¿LISTEN/SYN_RCVD? */
int  net_tcp_accept_wait(u32 timeout_ticks);    /* espera 3-way handshake */
u16  net_tcp_local_port(void);
void tcb_force_reset(void);                     /* cierre sin FIN */

/* HTTP alto nivel: estado http (200..), bytes; -1 sin red, -2 DNS, -3 TCP, -4 resp. */
int  net_http_get(const char *url, char *host_out, u32 hostsz,
                  char **body_out, u32 *body_len);
int  net_html_to_text(const char *html, u32 n, char *out, u32 outmax, char *title_out);

#endif /* FENIXOS_H */
