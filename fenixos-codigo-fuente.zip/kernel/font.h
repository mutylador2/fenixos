/* FenixOS — font.h: fuente bitmap 8x16 generada (95 glifos ASCII) */
#ifndef FENIX_FONT_H
#define FENIX_FONT_H
extern const unsigned char font8x16[95][16];
#endif
