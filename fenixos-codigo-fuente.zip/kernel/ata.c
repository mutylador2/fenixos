/* FenixOS — ata.c: driver de disco ATA PIO (canal primario, maestro).
 *
 * Soporta IDENTIFY DEVICE y lectura/escritura de sectores por LBA28
 * mediante polling (sin IRQ14): suficiente para la configuración
 * persistente del sistema y para listar el hardware.
 *
 * En QEMU/VirtualBox el disco aparece como primario-maestro. Si la
 * máquina arranca solo con CD, el driver se degrada con elegancia
 * (ata_present() == 0) y la configuración persistente queda inactiva. */
#include "fenixos.h"

/* puertos del canal primario */
#define ATA_DATA     0x1F0
#define ATA_ERROR    0x1F1
#define ATA_SECCNT   0x1F2
#define ATA_LBA_LO   0x1F3
#define ATA_LBA_MID  0x1F4
#define ATA_LBA_HI   0x1F5
#define ATA_DRIVE    0x1F6
#define ATA_STATUS   0x1F7
#define ATA_CMD      0x1F7
#define ATA_CTRL     0x3F6

#define ST_BSY  0x80
#define ST_DRQ  0x08
#define ST_ERR  0x01
#define ST_DF   0x20

#define CMD_IDENTIFY 0xEC
#define CMD_READ     0x20
#define CMD_WRITE    0x30
#define CMD_FLUSH    0xE7

static int    ata_present_flag = 0;
static u32    ata_sectors = 0;          /* capacidad LBA28 */
static char   ata_model[41];
static int    ata_uses_lba48 = 0;

/* espera activa por estado: NO usa pit_ticks ni hlt (se llama antes
 * de que el timer esté activo, con interrupciones deshabilitadas) */
static int ata_wait(u32 mask, u32 loops) {
    for (u32 i = 0; i < loops; i++) {
        u8 st = inb(ATA_STATUS);
        if (!(st & ST_BSY) && (mask == 0 || (st & mask))) return 0;
        if (st & (ST_ERR | ST_DF)) return -1;
        io_wait();
    }
    return -2;
}

static void ata_select(u32 lba) {
    outb(ATA_DRIVE, 0xE0 | ((lba >> 24) & 0x0F));   /* maestro, LBA28 */
    io_wait();
}

static void ata_delay(void) {
    for (int i = 0; i < 14; i++) inb(ATA_STATUS);   /* 400ns */
}

int ata_init(void) {
    ata_present_flag = 0;
    ata_sectors = 0;
    ata_model[0] = 0;
    ata_uses_lba48 = 0;

    outb(ATA_CTRL, 0x04);                 /* reset software del canal */
    io_wait();
    outb(ATA_CTRL, 0x00);
    io_wait();
    /* Esperar a que el canal termine el reset: si se escribe IDENTIFY
       mientras el dispositivo sigue en reset, el comando se pierde
       (estado final 0x50 sin DRQ, falla intermitente). */
    ata_wait(0, 1000000);
    ata_delay();
    ata_delay();

    for (int intento = 0; intento < 3 && !ata_present_flag; intento++) {
        outb(ATA_DRIVE, 0xA0);            /* seleccionar maestro */
        ata_delay();
        ata_delay();

        u8 st = inb(ATA_STATUS);
        if (st == 0xFF || st == 0x7F || st == 0) {   /* sin dispositivo */
            if (intento == 2)
                klogw("ATA", "sin disco en el canal primario (solo CD?)");
            continue;
        }

        outb(ATA_SECCNT, 0);
        outb(ATA_LBA_LO, 0);
        outb(ATA_LBA_MID, 0);
        outb(ATA_LBA_HI, 0);

        outb(ATA_CMD, CMD_IDENTIFY);
        if (inb(ATA_STATUS) == 0) {
            if (intento == 2) klogw("ATA", "IDENTIFY sin respuesta");
            continue;
        }

        if (ata_wait(ST_DRQ, 3000000) != 0) {
            char tmp[64];
            ksnprintf(tmp, sizeof(tmp),
                      "IDENTIFY reintento %d, status=0x%X", intento + 1,
                      inb(ATA_STATUS));
            klogw("ATA", tmp);
            io_wait(); io_wait(); io_wait();
            continue;
        }

        u16 id[256];
        for (int i = 0; i < 256; i++) id[i] = inw(ATA_DATA);

        ata_uses_lba48 = (id[83] & 0x0400) ? 1 : 0;
        ata_sectors = (u32)id[60] | ((u32)id[61] << 16);   /* sectores LBA28 */
        if (!ata_sectors) {
            klogw("ATA", "capacidad LBA invalida");
            continue;
        }
        for (int i = 0; i < 40; i += 2) {     /* modelo en big-endian por pares */
            ata_model[i]     = (char)(id[27 + i / 2] >> 8);
            ata_model[i + 1] = (char)(id[27 + i / 2] & 0xFF);
        }
        ata_model[40] = 0;
        for (int i = 39; i >= 0 && ata_model[i] == ' '; i--) ata_model[i] = 0;

        ata_present_flag = 1;
    }
    if (!ata_present_flag) return -1;

    {
        char tmp[96];
        ksnprintf(tmp, sizeof(tmp), "disco primario: '%s', %u MB, %u sectores%s",
                  ata_model, ata_sectors >> 11, ata_sectors,
                  ata_uses_lba48 ? ", LBA48" : "");
        klog("ATA", tmp);
    }
    return 0;
}

int ata_present(void)   { return ata_present_flag; }
u32 ata_sectors_count(void) { return ata_sectors; }
const char *ata_model_name(void) { return ata_model; }

int ata_read_sector(u32 lba, void *buf) {
    if (!ata_present_flag || lba >= ata_sectors) return -1;
    ata_select(lba);
    outb(ATA_SECCNT, 1);
    outb(ATA_LBA_LO, (u8)(lba & 0xFF));
    outb(ATA_LBA_MID, (u8)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI, (u8)((lba >> 16) & 0xFF));
    outb(ATA_CMD, CMD_READ);
    if (ata_wait(ST_DRQ, 3000000) != 0) return -2;
    u16 *p = (u16 *)buf;
    for (int i = 0; i < 256; i++) p[i] = inw(ATA_DATA);
    ata_delay();
    return 0;
}

int ata_write_sector(u32 lba, const void *buf) {
    if (!ata_present_flag || lba >= ata_sectors) return -1;
    ata_select(lba);
    outb(ATA_SECCNT, 1);
    outb(ATA_LBA_LO, (u8)(lba & 0xFF));
    outb(ATA_LBA_MID, (u8)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI, (u8)((lba >> 16) & 0xFF));
    outb(ATA_CMD, CMD_WRITE);
    if (ata_wait(ST_DRQ, 3000000) != 0) return -2;
    const u16 *p = (const u16 *)buf;
    for (int i = 0; i < 256; i++) outw(ATA_DATA, p[i]);
    if (ata_wait(0, 3000000) != 0) return -2;   /* fin de la escritura */
    outb(ATA_CMD, CMD_FLUSH);             /* asegurar persistencia */
    if (ata_wait(0, 3000000) != 0) return -3;
    return 0;
}

/* LBA reservado para la configuración: cerca del final del disco,
 * muy lejos del kernel (LBA 128..~270) */
u32 ata_config_lba(void) {
    if (!ata_present_flag) return 0;
    u32 lba = ata_sectors - 8;
    return lba;
}
