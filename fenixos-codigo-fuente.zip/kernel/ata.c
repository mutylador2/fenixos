/* FenixOS — ata.c: driver de disco ATA PIO (canales primario y secundario).
 *
 * v1.4: el canal secundario (0x170) permite enchufar un DISCO DE DATOS
 * (p.ej. FAT32) además del disco de arranque, tal como hace VirtualBox
 * al añadir un segundo disco. El primario sigue siendo el maestro del
 * canal 0 (donde vive FenixOS).
 *
 * Soporta IDENTIFY DEVICE y lectura/escritura de sectores por LBA28
 * mediante polling (sin IRQ14): suficiente para la configuración
 * persistente del sistema, FAT32 y para listar el hardware.
 *
 * En QEMU/VirtualBox el disco de arranque aparece como primario-maestro.
 * Si la máquina arranca solo con CD, el driver se degrada con elegancia
 * (ata_present() == 0) y la configuración persistente queda inactiva. */
#include "fenixos.h"

#define ST_BSY  0x80
#define ST_DRQ  0x08
#define ST_ERR  0x01
#define ST_DF   0x20

#define CMD_IDENTIFY 0xEC
#define CMD_READ     0x20
#define CMD_WRITE    0x30
#define CMD_FLUSH    0xE7

typedef struct {
    u16  base;                 /* 0x1F0 primario, 0x170 secundario */
    u16  ctrl;                 /* 0x3F6 / 0x376 */
    int  present;
    u32  sectors;              /* capacidad LBA28 */
    char model[41];
    int  lba48;
} AtaChan;

static AtaChan ch_prim = { 0x1F0, 0x3F6, 0, 0, {0}, 0 };
static AtaChan ch_sec  = { 0x170, 0x376, 0, 0, {0}, 0 };

/* espera activa por estado: NO usa pit_ticks ni hlt (se llama antes
 * de que el timer esté activo, con interrupciones deshabilitadas) */
static int ata_wait_ch(AtaChan *c, u32 mask, u32 loops) {
    for (u32 i = 0; i < loops; i++) {
        u8 st = inb(c->base + 7);
        if (!(st & ST_BSY) && (mask == 0 || (st & mask))) return 0;
        if (st & (ST_ERR | ST_DF)) return -1;
        io_wait();
    }
    return -2;
}

static void ata_select_ch(AtaChan *c, u32 lba) {
    outb(c->base + 6, (u16)(0xE0 | ((lba >> 24) & 0x0F)));   /* maestro, LBA28 */
    io_wait();
}

static void ata_delay_ch(AtaChan *c) {
    for (int i = 0; i < 14; i++) inb(c->base + 7);   /* 400ns */
}

/* ---------- IDENTIFY del maestro de un canal ---------- */
static int ata_identify(AtaChan *c, const char *nombre, int silencioso) {
    c->present = 0;
    c->sectors = 0;
    c->model[0] = 0;
    c->lba48 = 0;

    outb(c->ctrl, 0x04);                  /* reset software del canal */
    io_wait();
    outb(c->ctrl, 0x00);
    io_wait();
    /* Esperar a que el canal termine el reset: si se escribe IDENTIFY
       mientras el dispositivo sigue en reset, el comando se pierde
       (estado final 0x50 sin DRQ, falla intermitente). */
    ata_wait_ch(c, 0, 1000000);
    ata_delay_ch(c);
    ata_delay_ch(c);

    for (int intento = 0; intento < 3 && !c->present; intento++) {
        outb(c->base + 6, 0xA0);          /* seleccionar maestro */
        ata_delay_ch(c);
        ata_delay_ch(c);

        u8 st = inb(c->base + 7);
        if (st == 0xFF || st == 0x7F || st == 0) {   /* sin dispositivo */
            continue;
        }

        outb(c->base + 2, 0);
        outb(c->base + 3, 0);
        outb(c->base + 4, 0);
        outb(c->base + 5, 0);

        outb(c->base + 7, CMD_IDENTIFY);
        if (inb(c->base + 7) == 0) continue;

        if (ata_wait_ch(c, ST_DRQ, 3000000) != 0) {
            if (!silencioso) {
                char tmp[64];
                ksnprintf(tmp, sizeof(tmp),
                          "IDENTIFY reintento %d, status=0x%X", intento + 1,
                          inb(c->base + 7));
                klogw("ATA", tmp);
            }
            io_wait(); io_wait(); io_wait();
            continue;
        }

        u16 id[256];
        for (int i = 0; i < 256; i++) id[i] = inw(c->base);

        if (id[0] & 0x8000) {             /* bit15: dispositivo ATAPI (CD) */
            if (!silencioso) klogw("ATA", "dispositivo ATAPI (CD): no es un disco");
            continue;
        }

        c->lba48 = (id[83] & 0x0400) ? 1 : 0;
        c->sectors = (u32)id[60] | ((u32)id[61] << 16);   /* sectores LBA28 */
        if (!c->sectors) continue;
        for (int i = 0; i < 40; i += 2) {     /* modelo en big-endian por pares */
            c->model[i]     = (char)(id[27 + i / 2] >> 8);
            c->model[i + 1] = (char)(id[27 + i / 2] & 0xFF);
        }
        c->model[40] = 0;
        for (int i = 39; i >= 0 && c->model[i] == ' '; i--) c->model[i] = 0;

        c->present = 1;
    }
    if (!c->present) return -1;

    {
        char tmp[112];
        ksnprintf(tmp, sizeof(tmp), "disco %s: '%s', %u MB, %u sectores%s",
                  nombre, c->model, c->sectors >> 11, c->sectors,
                  c->lba48 ? ", LBA48" : "");
        klog("ATA", tmp);
    }
    return 0;
}

int ata_init(void) {
    return ata_identify(&ch_prim, "primario", 0);
}

/* v1.4: sondeo del canal secundario. Si no hay nada, no molesta
 * (silencioso: el canal vacío es lo normal en un equipo simple). */
int ata2_init(void) {
    if (ch_prim.present) ata_delay_ch(&ch_prim);   /* dejar el bus en paz */
    return ata_identify(&ch_sec, "secundario", 1);
}

int ata_present(void)   { return ch_prim.present; }
u32 ata_sectors_count(void) { return ch_prim.sectors; }
const char *ata_model_name(void) { return ch_prim.model; }

int ata2_present(void)  { return ch_sec.present; }
u32 ata2_sectors_count(void) { return ch_sec.sectors; }
const char *ata2_model_name(void) { return ch_sec.model; }

static int ata_rw(AtaChan *c, u32 lba, void *buf, int escribir) {
    if (!c->present || lba >= c->sectors) return -1;
    ata_select_ch(c, lba);
    outb(c->base + 2, 1);
    outb(c->base + 3, (u8)(lba & 0xFF));
    outb(c->base + 4, (u8)((lba >> 8) & 0xFF));
    outb(c->base + 5, (u8)((lba >> 16) & 0xFF));
    outb(c->base + 7, escribir ? CMD_WRITE : CMD_READ);
    if (ata_wait_ch(c, ST_DRQ, 3000000) != 0) return -2;
    if (escribir) {
        const u16 *p = (const u16 *)buf;
        for (int i = 0; i < 256; i++) outw(c->base, p[i]);
        if (ata_wait_ch(c, 0, 3000000) != 0) return -2;   /* fin de la escritura */
        outb(c->base + 7, CMD_FLUSH);             /* asegurar persistencia */
        if (ata_wait_ch(c, 0, 3000000) != 0) return -3;
    } else {
        u16 *p = (u16 *)buf;
        for (int i = 0; i < 256; i++) p[i] = inw(c->base);
        ata_delay_ch(c);
    }
    return 0;
}

int ata_read_sector(u32 lba, void *buf)   { return ata_rw(&ch_prim, lba, buf, 0); }
int ata_write_sector(u32 lba, const void *buf) { return ata_rw(&ch_prim, lba, (void *)buf, 1); }
int ata2_read_sector(u32 lba, void *buf)  { return ata_rw(&ch_sec, lba, buf, 0); }
int ata2_write_sector(u32 lba, const void *buf) { return ata_rw(&ch_sec, lba, (void *)buf, 1); }

/* LBA reservado para la configuración: cerca del final del disco,
 * muy lejos del kernel (LBA 128..~270) */
u32 ata_config_lba(void) {
    if (!ch_prim.present) return 0;
    u32 lba = ch_prim.sectors - 8;
    return lba;
}
