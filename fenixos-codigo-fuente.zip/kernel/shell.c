/* FenixOS — shell.c: FenixShell, la terminal del sistema.
 * Corre como tarea del kernel, escribe en el buffer de la ventana
 * Terminal y consume la cola del teclado cuando tiene foco. */
#include "fenixos.h"

/* atributos de color (índice -> color) */
#define A_WHITE  0
#define A_GREEN  1
#define A_CYAN   2
#define A_YELLOW 3
#define A_RED    4
#define A_GRAY   5
#define A_ACCENT 6
#define A_MAGENTA 7

u32 shell_attr_color(u8 attr) {
    switch (attr) {
    case A_GREEN:   return 0xFF7EE787;
    case A_CYAN:    return 0xFF79C0FF;
    case A_YELLOW:  return 0xFFE3B341;
    case A_RED:     return 0xFFF85149;
    case A_GRAY:    return 0xFF8B949E;
    case A_ACCENT:  return current_theme.accent;
    case A_MAGENTA: return 0xFFD2A8FF;
    default:        return 0xFFE6EDF3;
    }
}

static int shell_task_id = -1;
static char linebuf[160];
static int linepos = 0;

static void sh_scroll(Window *w) {
    memcpy(w->cells, w->cells + w->cols, (u32)(w->cols * (w->rows - 1)) * sizeof(u16));
    u16 *last = w->cells + w->cols * (w->rows - 1);
    for (int i = 0; i < w->cols; i++) last[i] = ' ';
    w->ccy = w->rows - 1;
}

static void sh_nl(Window *w) {
    w->ccx = 0;
    w->ccy++;
    if (w->ccy >= w->rows) sh_scroll(w);
}

static void sh_putc(Window *w, char c, u8 attr) {
    if (c == '\n') { sh_nl(w); return; }
    w->cells[w->ccy * w->cols + w->ccx] = (u16)(u8)c | ((u16)attr << 8);
    w->ccx++;
    if (w->ccx >= w->cols) sh_nl(w);
}

static void sh_puts(Window *w, const char *s, u8 attr) {
    while (*s) sh_putc(w, *s++, attr);
}

static void sh_printf(Window *w, u8 attr, const char *fmt, ...) {
    char buf[384];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    sh_puts(w, buf, attr);
}

static void sh_prompt(Window *w) {
    sh_puts(w, user_current_name(), A_MAGENTA);
    sh_putc(w, '@', A_GRAY);
    sh_puts(w, config_hostname(), A_GREEN);
    sh_puts(w, ":~$ ", A_GRAY);
    w->ccx = w->ccx % w->cols;
}

static void sh_welcome(Window *w) {
    sh_puts(w, "FenixOS 1.3 \"Titan\"  ·  kernel fenix-kernel 1.3.0 x86_64\n", A_ACCENT);
    sh_puts(w, "Sesion: ", A_GRAY);
    sh_puts(w, user_current_name(), A_MAGENTA);
    sh_puts(w, " (rol ", A_GRAY);
    sh_puts(w, role_name(user_current_role()), A_MAGENTA);
    sh_puts(w, "). Escribe 'ayuda' para ver las ordenes.\n\n", A_GRAY);
}

/* ---------------------- usuarios y permisos ---------------------- */
static void cmd_login(Window *w, int argc, char **argv) {
    if (argc < 2) {
        sh_puts(w, "Uso: login <usuario> [clave]  (ej: login admin fenix)\n", A_GRAY);
        return;
    }
    int r = user_login(argv[1], argc >= 3 ? argv[2] : "");
    if (r == 0) {
        sh_printf(w, A_GREEN, "sesion iniciada como '%s' (rol %s)\n",
                  user_current_name(), role_name(user_current_role()));
    } else if (r == -2) {
        sh_puts(w, "login: clave incorrecta\n", A_RED);
    } else {
        sh_printf(w, A_RED, "login: no existe el usuario '%s'\n", argv[1]);
    }
}

static void cmd_quiensoy(Window *w) {
    sh_printf(w, A_WHITE, "usuario: %s (rol %s)\n",
              user_current_name(), role_name(user_current_role()));
    klogf(LOG_INFO, "USR", "usuario: %s (rol %s)",
          user_current_name(), role_name(user_current_role()));
}

static void cmd_usuarios(Window *w) {
    sh_printf(w, A_ACCENT, "%-14s %s\n", "USUARIO", "ROL");
    for (int i = 0; i < 8; i++) {
        const char *nm; int role;
        if (!user_list(i, &nm, &role)) continue;
        sh_printf(w, A_WHITE, "%-14s %s\n", nm, role_name(role));
    }
}

static void cmd_salir(Window *w) {
    if (user_logout() == 0)
        sh_printf(w, A_GREEN, "sesion cerrada. Ahora eres '%s'\n", user_current_name());
    else
        sh_puts(w, "salir: ya eres invitado\n", A_GRAY);
}

/* crear cuenta (v1.3): useradd <nombre> <clave> <rol 0-2> */
static void cmd_useradd(Window *w, int argc, char **argv) {
    if (argc < 4) {
        sh_puts(w, "Uso: useradd <nombre> <clave> <rol 0=invitado 1=usuario 2=admin>\n", A_GRAY);
        sh_puts(w, "(clave '-' = sin clave; la cuenta se guarda en disco)\n", A_GRAY);
        return;
    }
    int role = 0;
    const char *s = argv[3];
    while (*s >= '0' && *s <= '9') role = role * 10 + (*s++ - '0');
    int r = user_add(argv[1], (argv[2][0] == '-' && !argv[2][1]) ? "" : argv[2], role);
    if (r == 0) {
        sh_printf(w, A_GREEN, "cuenta '%s' creada (rol %s) y guardada en disco\n",
                  argv[1], role_name(role));
        sh_puts(w, "prueba: login <nombre> <clave> | sobrevive al reinicio\n", A_GRAY);
    } else if (r == -2)
        sh_printf(w, A_RED, "useradd: ya existe '%s'\n", argv[1]);
    else if (r == -3)
        sh_puts(w, "useradd: sin ranuras (8 cuentas max)\n", A_RED);
    else
        sh_puts(w, "useradd: nombre o rol invalido\n", A_RED);
}

/* ---------------------- sistema de logs ---------------------- */
static void cmd_logs(Window *w, int argc, char **argv) {
    if (argc >= 2 && !strcmp(argv[1], "limpiar")) {
        klog_clear();
        sh_puts(w, "registro de eventos limpiado\n", A_GREEN);
        return;
    }
    if (argc >= 2 && !strcmp(argv[1], "guardar")) {
        if (klog_save() == 0)
            sh_puts(w, "registro guardado en RAMFS como sistema.log\n", A_GREEN);
        else
            sh_puts(w, "logs: no se pudo guardar\n", A_RED);
        return;
    }
    int n = klog_count();
    sh_printf(w, A_ACCENT, "registro de eventos (%d entradas en RAM)\n", n);
    for (int i = 0; i < n; i++) {
        u32 secs; u8 lvl; char tag[8]; char msg[80];
        klog_get(i, &secs, &lvl, tag, msg);
        u8 attr = (lvl == LOG_ERROR) ? A_RED : (lvl == LOG_WARN) ? A_YELLOW : A_GRAY;
        sh_printf(w, attr, "[+%us][%s] %s\n", secs, tag, msg);
    }
}

/* ---------------------- configuración ---------------------- */
static void cmd_config(Window *w, int argc, char **argv) {
    if (argc == 1) {                       /* listar */
        sh_puts(w, "Configuracion (valores activos en RAM):\n", A_ACCENT);
        for (int i = 0; i < 16; i++) {
            const char *k, *v;
            if (!config_pair(i, &k, &v)) continue;
            sh_printf(w, A_WHITE, "  %-10s = %s\n", k, v);
        }
        if (blk_present())
            sh_printf(w, A_GRAY, "persistente en disco LBA %u ('config guardar')\n",
                      blk_config_lba());
        else
            sh_puts(w, "sin disco: la configuracion no se puede persistir\n", A_YELLOW);
        return;
    }
    if (argc == 2 && !strcmp(argv[1], "guardar")) {
        if (!user_perm_ok(ROL_ADMIN)) { sh_puts(w, "config: requiere rol admin\n", A_RED); return; }
        if (config_save_disk() == 0) sh_puts(w, "configuracion guardada en disco\n", A_GREEN);
        else sh_puts(w, "config: fallo al escribir en el disco\n", A_RED);
        return;
    }
    if (argc == 2 && !strcmp(argv[1], "cargar")) {
        if (!user_perm_ok(ROL_ADMIN)) { sh_puts(w, "config: requiere rol admin\n", A_RED); return; }
        int r = config_load_disk();
        if (r == 0) sh_puts(w, "configuracion recargada del disco\n", A_GREEN);
        else if (r == 1) sh_puts(w, "config: el disco aun no tiene configuracion\n", A_YELLOW);
        else sh_puts(w, "config: fallo de lectura\n", A_RED);
        return;
    }
    if (argc >= 3) {                       /* fijar clave valor */
        if (!user_perm_ok(ROL_ADMIN)) { sh_puts(w, "config: requiere rol admin\n", A_RED); return; }
        char val[32];
        u32 vl = 0;
        for (int i = 2; i < argc; i++) {
            if (i > 2 && vl < sizeof(val) - 1) val[vl++] = ' ';
            for (char *p = argv[i]; *p && vl < sizeof(val) - 1; p++) val[vl++] = *p;
        }
        val[vl] = 0;
        int r = config_set(argv[1], val);
        if (r == 0) {
            if (!strcmp(argv[1], "hostname"))
                config_refresh_hostname();   /* aplicar de inmediato */
            sh_printf(w, A_GREEN, "config: %s = %s (usa 'config guardar' para persistir)\n",
                      argv[1], val);
            klogf(LOG_INFO, "CFG", "clave '%s' fijada a '%s'", argv[1], val);
        }
        else if (r == -3) sh_puts(w, "config: tabla llena (16 claves max)\n", A_RED);
        else sh_puts(w, "config: clave o valor invalido\n", A_RED);
        return;
    }
    sh_puts(w, "Uso: config | config <clave> <valor> | config guardar | config cargar\n", A_GRAY);
}

/* ---------------------- disco y usb ---------------------- */
static void cmd_disco(Window *w) {
    if (!blk_present()) {
        sh_puts(w, "disco: no hay discos ATA/AHCI utilizables\n", A_YELLOW);
        return;
    }
    sh_printf(w, A_WHITE, "modelo    : %s\n", blk_model());
    sh_printf(w, A_WHITE, "backend   : %s\n", blk_backend());
    sh_printf(w, A_WHITE, "sectores  : %u (512 B)\n", blk_sectors());
    sh_printf(w, A_WHITE, "capacidad : %u MB\n", blk_sectors() >> 11);
    if (blk_part_base())
        sh_printf(w, A_GRAY, "instalacion: particion 0x63 en LBA %u (%u sectores)\n",
                  blk_part_base(), blk_part_sectors());
    else
        sh_puts(w, "instalacion: disco entero (sin particion)\n", A_GRAY);
    sh_printf(w, A_GRAY, "config en : LBA %u | menu multiboot en LBA %u\n",
              blk_config_lba(), blk_part_base() + 41);
    if (ahci_present()) {
        sh_printf(w, A_CYAN, "AHCI      : %d puerto(s) SATA activos\n", ahci_port_count());
        for (int i = 0; i < ahci_port_count(); i++)
            sh_printf(w, A_WHITE, "  SATA %d : %s, %u MB\n",
                      i, ahci_port_model(i), ahci_port_sectors(i) >> 11);
    }
}

/* ---------------------- arranque (menu multiboot) ---------------------- */
static void cmd_arranque(Window *w, int argc, char **argv) {
    if (argc >= 2 && !strcmp(argv[1], "guardar")) {
        /* 'arranque <opt> <seg>' ya guardó; aquí solo re-muestra */
    }
    if (argc >= 3) {
        if (!user_perm_ok(ROL_ADMIN)) { sh_puts(w, "arranque: requiere rol admin\n", A_RED); return; }
        int opt = 0, tmo = 0;
        const char *s = argv[1];
        while (*s >= '0' && *s <= '9') opt = opt * 10 + (*s++ - '0');
        s = argv[2];
        while (*s >= '0' && *s <= '9') tmo = tmo * 10 + (*s++ - '0');
        if (opt < 1 || opt > 5 || tmo < 1 || tmo > 9) {
            sh_puts(w, "arranque: opcion 1-5, segundos 1-9\n", A_RED);
            return;
        }
        int r = blk_write_bootconfig((u8)opt, (u8)tmo);
        if (r == 0)
            sh_printf(w, A_GREEN, "gestor de arranque: opcion %u, autoarranque %u s (persistente)\n", opt, tmo);
        else if (r == -2)
            sh_puts(w, "arranque: desde CD no hay disco donde guardar\n", A_YELLOW);
        else
            sh_puts(w, "arranque: fallo de escritura en el disco\n", A_RED);
        return;
    }
    u8 opt = 0, tmo = 0;
    int r = blk_read_bootconfig(&opt, &tmo);
    sh_puts(w, "Gestor de arranque (menu multiboot):\n", A_ACCENT);
    sh_puts(w, " 1) FenixOS        2) modo seguro\n", A_WHITE);
    sh_puts(w, " 3) otro SO de este disco    4) otro disco\n", A_WHITE);
    sh_puts(w, " 5) informacion del sistema\n", A_WHITE);
    if (r == 0)
        sh_printf(w, A_WHITE, " por defecto: opcion %u, autoarranque %u s\n", opt, tmo);
    else
        sh_puts(w, " por defecto: opcion 1, autoarranque 8 s (sin sector)\n", A_GRAY);
    sh_puts(w, "cambiar: arranque <opcion 1-5> <segundos 1-9>\n", A_GRAY);
}

/* ---------------------- red ---------------------- */
static void cmd_ping(Window *w, int argc, char **argv) {
    if (argc < 2) { sh_puts(w, "Uso: ping <ip|nombre> (ej: ping 10.0.2.2)\n", A_GRAY); return; }
    if (!net_ready()) { sh_puts(w, "ping: red no disponible (falta la NIC e1000)\n", A_RED); return; }
    u32 ip = 0;
    if (!net_ip_parse(argv[1], &ip)) {
        sh_printf(w, A_GRAY, "resolviendo '%s' por DNS...\n", argv[1]);
        ip = net_dns_resolve(argv[1]);
        if (!ip) { sh_printf(w, A_RED, "ping: no se pudo resolver '%s'\n", argv[1]); return; }
        char ipb[16];
        net_ip_str(ip, ipb, sizeof(ipb));
        sh_printf(w, A_GREEN, "'%s' es %s\n", argv[1], ipb);
    }
    {
        char ipb[16];
        net_ip_str(ip, ipb, sizeof(ipb));
        sh_printf(w, A_WHITE, "PING %s: 4 ecos de 32 bytes\n", ipb);
    }
    int okc = 0;
    for (int i = 0; i < 4; i++) {
        u32 rtt = 0;
        if (net_ping(ip, &rtt)) {
            sh_printf(w, A_GREEN, "  eco %d: respuesta en %lu ms\n", i + 1, rtt);
            klogf(LOG_INFO, "ICMP", "eco %d OK, %lu ms", i + 1, rtt);
            okc++;
        } else {
            sh_puts(w, "  eco: sin respuesta (tiempo agotado)\n", A_RED);
        }
    }
    sh_printf(w, A_WHITE, "%d de 4 ecos recibidos\n", okc);
}

static void cmd_net(Window *w, int argc, char **argv) {
    if (!net_ready()) {
        sh_puts(w, "net: interfaz no disponible (arranca con -nic user,model=e1000)\n", A_RED);
        return;
    }
    if (argc >= 2 && !strcmp(argv[1], "ip")) {
        /* net ip a.b.c.d [gw] [dns] */
        u32 ip = 0, gw = 0, dns = 0;
        if (argc < 3 || !net_ip_parse(argv[2], &ip)) {
            sh_puts(w, "Uso: net ip <a.b.c.d> [puerta] [dns]\n", A_GRAY);
            return;
        }
        if (argc >= 4 && !net_ip_parse(argv[3], &gw)) gw = 0;
        if (argc >= 5 && !net_ip_parse(argv[4], &dns)) dns = 0;
        if (!gw) gw = (ip & 0xFFFFFF00) | 0x02;
        if (!dns) dns = (ip & 0xFFFFFF00) | 0x03;
        net_set_ips(ip, gw, dns);
        sh_puts(w, "direcciones actualizadas\n", A_GREEN);
    }
    u8 mac[6];
    net_mac(mac);
    char ipb[16], gwb[16], dnsb[16];
    net_ip_str(net_my_ip(), ipb, sizeof(ipb));
    net_ip_str(net_gateway(), gwb, sizeof(gwb));
    net_ip_str(net_dns(), dnsb, sizeof(dnsb));
    sh_puts(w, "Interfaz e1000 (Intel 82540EM, emulada)\n", A_ACCENT);
    sh_printf(w, A_WHITE, "  MAC   : %x:%x:%x:%x:%x:%x\n", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    sh_printf(w, A_WHITE, "  IP    : %s\n", ipb);
    sh_printf(w, A_WHITE, "  GW    : %s\n", gwb);
    sh_printf(w, A_WHITE, "  DNS   : %s\n", dnsb);
    sh_printf(w, A_WHITE, "  enlaces: %s, tramas TX %u, RX %u\n",
              net_link_up ? "arriba" : "abajo", net_tx_count(), net_rx_count());
    sh_puts(w, "prueba: ping 10.0.2.2 · nav http://example.com\n", A_GRAY);
}

/* ---------------------- scripts y extensiones ---------------------- */
static void cmd_fx(Window *w, int argc, char **argv) {
    if (argc < 2) {
        sh_puts(w, "Uso: fx <script.fx>  (ver 'ext' para la lista)\n", A_GRAY);
        return;
    }
    int r = fx_run(argv[1], w);
    if (r == -1) sh_printf(w, A_RED, "fx: no existe '%s'\n", argv[1]);
    else if (r == -2) sh_printf(w, A_RED, "fx: '%s' no es un script FenixScript\n", argv[1]);
    else if (r == -3) sh_puts(w, "fx: limite de pasos alcanzado (posible bucle infinito)\n", A_YELLOW);
}

static void cmd_ext(Window *w, int argc, char **argv) {
    (void)argc; (void)argv;
    sh_puts(w, "Extensiones FenixScript instaladas (*.fx en el RAMFS):\n", A_ACCENT);
    int n = 0;
    for (int i = 0; i < ramfs_slots(); i++) {
        const char *name, *meta;
        if (!fx_list(i, &name, &meta)) continue;
        sh_printf(w, A_WHITE, "  %-18s %s\n", name, meta ? meta : "");
        n++;
    }
    if (!n) sh_puts(w, "  (ninguna: crea scripts .fx con el editor)\n", A_GRAY);
    sh_puts(w, "ejecuta una con: fx <nombre.fx>\n", A_GRAY);
}

/* ---------------------- compatibilidad Windows ---------------------- */
static void cmd_win(Window *w, int argc, char **argv) {
    if (argc < 2) {
        sh_puts(w, "Uso: win <archivo.exe>  (prueba con: win muestra.exe)\n", A_GRAY);
        return;
    }
    int r = win_analyze(argv[1], w);
    if (r == -1) sh_printf(w, A_RED, "win: no existe '%s'\n", argv[1]);
    else if (r == -2) sh_printf(w, A_RED, "win: '%s' no es un ejecutable MZ/PE\n", argv[1]);
}

/* ---------------------- visor de archivos ---------------------- */
static void cmd_visor(Window *w, int argc, char **argv) {
    Window *v = wm_open_viewer(argc >= 2 ? argv[1] : "leeme.txt");
    if (!v) { sh_puts(w, "visor: no hay ventanas libres\n", A_RED); return; }
    sh_printf(w, A_GRAY, "visor abierto con '%s' (flechas arriba/abajo para desplazar)\n",
              argc >= 2 ? argv[1] : "leeme.txt");
}

/* ---------------------- usb ---------------------- */
static void cmd_usb(Window *w) {
    int n = usb_scan();
    sh_puts(w, "Controladoras USB en el bus PCI:\n", A_ACCENT);
    if (!n) {
        sh_puts(w, "  (ninguna detectada)\n", A_GRAY);
        sh_puts(w, "en QEMU: -usb -device usb-tablet | en VirtualBox: ajustes USB\n", A_GRAY);
    }
    for (int i = 0; i < n; i++) {
        const char *type; u8 bus, dev;
        if (!usb_info(i, &type, &bus, &dev)) continue;
        sh_printf(w, A_WHITE, "  %02x:%02x.0  %s (deteccion, sin pila USB funcional)\n",
                  bus, dev, type);
    }
    sh_puts(w, "nota: compartir Internet del movil (anclaje USB/RNDIS) requiere\n", A_GRAY);
    sh_puts(w, "una pila USB host con driver RNDIS: pendiente en la hoja de ruta.\n", A_GRAY);
}

/* ---------------------- navegador FenixNav ---------------------- */
static void cmd_nav(Window *w, int argc, char **argv) {
    if (argc < 2) {
        sh_puts(w, "Uso: nav <url>  (ej: nav http://example.com)\n", A_GRAY);
        sh_puts(w, "solo HTTP (sin cifrado TLS); el texto se abre en el visor\n", A_GRAY);
        return;
    }
    if (!net_ready()) {
        sh_puts(w, "nav: red no disponible (falta la NIC e1000)\n", A_RED);
        return;
    }
    sh_printf(w, A_GRAY, "FenixNav: descargando %s ...\n", argv[1]);
    char host[64];
    char *body = NULLP;
    u32 body_len = 0;
    int r = net_http_get(argv[1], host, sizeof(host), &body, &body_len);
    if (r < 0) {
        const char *msg = (r == -1) ? "sin red" :
                          (r == -2) ? "fallo de DNS" :
                          (r == -3) ? "conexion TCP fallida" :
                          (r == -4) ? "respuesta HTTP invalida" : "error";
        sh_printf(w, A_RED, "nav: error: %s\n", msg);
        return;
    }
    char title[64];
    static char text[20000];
    int tl = net_html_to_text(body, body_len, text, sizeof(text) - 1, title);
    kfree(body);
    if (tl < 0) { sh_puts(w, "nav: fallo al convertir el HTML\n", A_RED); return; }
    text[tl] = 0;
    char *txt = (char *)kmalloc((u32)tl + 1);
    if (!txt) { sh_puts(w, "nav: sin memoria para el texto\n", A_RED); return; }
    memcpy(txt, text, (u32)tl + 1);
    char ttl[28];
    {
        char hh[16];
        strncpy(hh, host, 15);
        hh[15] = 0;
        ksnprintf(ttl, sizeof(ttl), "FenixNav: %s", hh);
    }
    wm_open_nav(ttl, txt, (u32)tl);
    sh_printf(w, A_GREEN, "HTTP %d: %lu bytes de '%s' -> ventana FenixNav (%d lineas)\n",
              r, body_len, host, tl ? 1 : 0);
    klogf(LOG_INFO, "HTTP", "GET %s: estado %d, %lu bytes, %d chars de texto",
          host, r, body_len, tl);
}

/* ---------------------- ayuda ---------------------- */
static void cmd_ayuda(Window *w) {
    static const struct { const char *cmd, *desc; } tabla[] = {
        { "ayuda",       "lista de ordenes disponibles" },
        { "info",        "datos del sistema estilo neofetch" },
        { "mem",         "uso de memoria fisica y del monton" },
        { "ps",          "tareas activas con uso de CPU" },
        { "kill <id>",   "termina una tarea (rol usuario)" },
        { "login <u> <c>","cambia de usuario (admin/fenix, usuario/1234)" },
        { "salir",       "cierra la sesion (pasa a invitado)" },
        { "quiensoy",    "usuario y rol actuales" },
        { "usuarios",    "cuentas del sistema (rol admin)" },
        { "archivos",    "lista los archivos del RAMFS" },
        { "escribir <a> <txt>", "escribe texto en un archivo" },
        { "leer <a>",    "muestra el contenido de un archivo" },
        { "tocar <a>",   "crea un archivo vacio" },
        { "borrar <a>",  "elimina un archivo del RAMFS" },
        { "editor [a]",  "editor grafico de texto" },
        { "visor [a]",   "visor de archivos con desplazamiento" },
        { "calculadora", "calculadora grafica con botones" },
        { "fx <archivo.fx>", "ejecuta un script FenixScript" },
        { "ext",         "extensiones .fx instaladas" },
        { "win <exe>",   "FenixCompat: analiza ejecutables MZ/PE" },
        { "ping <host>", "4 ecos ICMP a una IP o nombre" },
        { "net [ip ...]", "estado de la red / reconfigurar IP" },
        { "nav <url>",   "navegador web (HTTP) en ventana" },
        { "config",      "ver/configurar el sistema (persistente)" },
        { "logs",        "registro de eventos (logs limpiar/guardar)" },
        { "sistema",     "informacion del hardware en una ventana" },
        { "instalador",  "instalacion grafica en otro disco" },
        { "arranque",    "menu multiboot: opcion y autoarranque" },
        { "disco",       "discos ATA/AHCI y zona de instalacion" },
        { "usb",         "controladoras USB detectadas" },
        { "demo on/off", "ventana de demostracion animada" },
        { "tema <t>",    "fuego, azul, bosque o vapor" },
        { "calc a + b",  "calculadora de enteros en la terminal" },
        { "sonido",      "tono de prueba por el altavoz" },
        { "musica",      "melodia 'Renacer' en el altavoz" },
        { "fecha",       "fecha y hora del reloj CMOS" },
        { "raton",       "posicion y botones del raton PS/2" },
        { "acerca",      "ventana Acerca de FenixOS" },
        { "uptime",      "tiempo encendido del sistema" },
        { "echo <txt>",  "imprime texto" },
        { "limpiar",     "limpia la terminal" },
        { "fenix",       "arte del fenix" },
        { "reboot",      "reinicia el equipo (rol admin)" },
        { "apagar",      "apaga el equipo (rol admin)" },
    };
    sh_puts(w, "Ordenes de FenixShell (permisos segun rol):\n", A_ACCENT);
    for (u32 i = 0; i < sizeof(tabla) / sizeof(tabla[0]); i++)
        sh_printf(w, A_WHITE, "  %-14s %s\n", tabla[i].cmd, tabla[i].desc);
}
static void art_phoenix(Window *w, int line) {
    static const char *art[8] = {
        "      /\\",
        "     /  \\",
        "    / /\\ \\",
        "   / /  \\ \\",
        "  /_/ /\\ \\_\\",
        "    \\ \\/ /",
        "     \\__/",
        ""
    };
    if (line < 8 && art[line][0]) sh_puts(w, art[line], A_YELLOW);
}

static void cmd_osfetch(Window *w) {
    u64 secs = pit_ticks / 100;
    u64 mb_used = pmm_used_pages * PAGE_SIZE / (1024u * 1024u);
    u64 mb_total = pmm_total_pages * PAGE_SIZE / (1024u * 1024u);
    char inf[14][72];
    int n = 0;
    ksnprintf(inf[n++], 72, "%s@%s", user_current_name(), config_hostname());
    ksnprintf(inf[n++], 72, "-----------------");
    ksnprintf(inf[n++], 72, "SO:        FenixOS 1.3 \"Titan\" x86_64");
    ksnprintf(inf[n++], 72, "Kernel:    fenix-kernel 1.3.0 (bootloader propio)");
    ksnprintf(inf[n++], 72, "Shell:     fsh 1.3");
    ksnprintf(inf[n++], 72, "Sesion:    %s (rol %s)", user_current_name(), role_name(user_current_role()));
    ksnprintf(inf[n++], 72, "Pantalla:  %ux%u@%u bpp", fb.width, fb.height, fb.bpp);
    ksnprintf(inf[n++], 72, "Uptime:    %lu min %lu seg", secs / 60, secs % 60);
    ksnprintf(inf[n++], 72, "RAM:       %lu MB / %lu MB", mb_used, mb_total);
    ksnprintf(inf[n++], 72, "RAMFS:     %d archivos, %lu bytes", ramfs_count(), ramfs_bytes_used());
    ksnprintf(inf[n++], 72, "Disco:     %s [%s]", blk_present() ? blk_model() : "no detectado", blk_backend());
    if (net_ready()) {
        char ipbuf[16];
        net_ip_str(net_my_ip(), ipbuf, sizeof(ipbuf));
        ksnprintf(inf[n++], 72, "Red:       e1000, IP %s", ipbuf);
    } else {
        ksnprintf(inf[n++], 72, "Red:       no disponible");
    }
    ksnprintf(inf[n++], 72, "Tareas:    %d activas", task_count_alive());

    for (int i = 0; i < n; i++) {
        art_phoenix(w, i);
        sh_puts(w, "  ", A_WHITE);
        sh_puts(w, inf[i], i < 2 ? A_GREEN : A_WHITE);
        sh_putc(w, '\n', 0);
    }
    for (int i = n; i < 8; i++) {
        art_phoenix(w, i);
        sh_putc(w, '\n', 0);
    }
}

static void cmd_mem(Window *w) {
    u64 mb_used = pmm_used_pages * PAGE_SIZE / (1024u * 1024u);
    u64 mb_total = pmm_total_pages * PAGE_SIZE / (1024u * 1024u);
    u64 kpages = heap_used / 1024;
    sh_printf(w, A_WHITE, "Memoria fisica : %lu MB usados de %lu MB (%lu paginas de 4KB)\n",
              mb_used, mb_total, pmm_used_pages);
    sh_printf(w, A_WHITE, "Monton (heap)  : %lu KB usados de %lu KB\n", kpages, heap_size / 1024);
    sh_printf(w, A_GRAY,  "Kernel         : %lu KB en [0x%X - 0x%X]\n",
              (kernel_end_addr - kernel_start_addr) / 1024,
              kernel_start_addr, kernel_end_addr);
}

static void cmd_ps(Window *w) {
    u64 total = 0;
    for (int i = 0; i < MAX_TASKS; i++)
        if (tasks[i].id >= 0 && tasks[i].state != T_DEAD) total += tasks[i].switches;
    sh_printf(w, A_ACCENT, "%-4s %-12s %-9s %-8s %s\n", "ID", "TAREA", "ESTADO", "CPU%", "CAMBIOS");
    for (int i = 0; i < MAX_TASKS; i++) {
        if (tasks[i].id < 0 || tasks[i].state == T_DEAD) continue;
        const char *st = (tasks[i].state == T_READY) ? "listo" : "bloqueada";
        u32 pct = total ? (u32)(tasks[i].switches * 100 / total) : 0;
        sh_printf(w, A_WHITE, "%-4d %-12s %-9s %-8u %lu\n",
                  tasks[i].id, tasks[i].name, st, pct, tasks[i].switches);
    }
}

static void cmd_fecha(Window *w) {
    rtc_read_datetime();
    sh_printf(w, A_WHITE, "%s %u %s %u - %2u:%2u:%2u\n",
              rtc_day_name(rtc_wday), rtc_day, rtc_month_name(rtc_month),
              rtc_year, rtc_hour, rtc_min, rtc_sec);
}

static void cmd_tema(Window *w, int argc, char **argv) {
    if (argc < 2) {
        sh_puts(w, "Temas: fuego, azul, bosque, vapor. Uso: tema <nombre>\n", A_GRAY);
        return;
    }
    int t = -1;
    if (!strcmp(argv[1], "fuego")) t = THEME_FUEGO;
    else if (!strcmp(argv[1], "azul")) t = THEME_AZUL;
    else if (!strcmp(argv[1], "bosque")) t = THEME_BOSQUE;
    else if (!strcmp(argv[1], "vapor")) t = THEME_VAPOR;
    if (t < 0) { sh_puts(w, "tema: tema desconocido\n", A_RED); return; }
    gui_set_theme(t);
    config_set("tema", theme_name(t));    /* recordar en la configuración */
    sh_printf(w, A_GREEN, "Tema cambiado a '%s' ('config guardar' para persistir)\n", theme_name(t));
    klogf(LOG_INFO, "GUI", "tema cambiado a %s", theme_name(t));
}

static void cmd_demo(Window *w, int argc, char **argv) {
    if (argc >= 2 && !strcmp(argv[1], "off")) {
        if (demo_task_id >= 0) {
            task_kill(demo_task_id);
            demo_task_id = -1;
            demo_running = 0;
            Window *dw = gui_demo_window();
            if (dw) dw->visible = 0;
            sh_puts(w, "FenixDemo detenido.\n", A_GRAY);
        } else {
            sh_puts(w, "FenixDemo no esta activo.\n", A_GRAY);
        }
        return;
    }
    if (demo_task_id >= 0) {
        sh_puts(w, "FenixDemo ya esta activo.\n", A_GRAY);
        return;
    }
    demo_task_id = task_create("fenixdemo", demo_task, 1);
    if (demo_task_id < 0) { sh_puts(w, "demo: sin memoria para tareas\n", A_RED); return; }
    wm_open_demo();
    sh_printf(w, A_GREEN, "FenixDemo iniciado (tarea %d).\n", demo_task_id);
}

static void cmd_calc(Window *w, int argc, char **argv) {
    if (argc != 4) {
        sh_puts(w, "Uso: calc <num> <+|-|x|/> <num>\n", A_GRAY);
        return;
    }
    i64 a = 0, b = 0;
    int neg1 = 0, neg2 = 0;
    const char *s = argv[1];
    if (*s == '-') { neg1 = 1; s++; }
    while (*s >= '0' && *s <= '9') a = a * 10 + (*s++ - '0');
    if (*s) { sh_puts(w, "calc: numero invalido\n", A_RED); return; }
    if (neg1) a = -a;
    s = argv[3];
    if (*s == '-') { neg2 = 1; s++; }
    while (*s >= '0' && *s <= '9') b = b * 10 + (*s++ - '0');
    if (*s) { sh_puts(w, "calc: numero invalido\n", A_RED); return; }
    if (neg2) b = -b;

    i64 r = 0;
    switch (argv[2][0]) {
    case '+': r = a + b; break;
    case '-': r = a - b; break;
    case 'x': r = a * b; break;
    case '/':
        if (b == 0) { sh_puts(w, "calc: division entre cero\n", A_RED); return; }
        r = a / b;
        break;
    default:
        sh_puts(w, "calc: operador invalido (usa + - x /)\n", A_RED);
        return;
    }
    sh_printf(w, A_CYAN, "%ld %c %ld = %ld\n", a, argv[2][0], b, r);
}

static void cmd_raton(Window *w) {
    sh_printf(w, A_WHITE, "posicion : x=%d y=%d (pantalla %ux%u)\n",
              mouse_x, mouse_y, fb.width, fb.height);
    sh_printf(w, A_WHITE, "botones  : %s%s%s\n",
              (mouse_buttons & 1) ? "izquierdo" : "",
              (mouse_buttons & 2) ? " derecho" : "",
              (mouse_buttons & 4) ? " central" : "");
    if (!(mouse_buttons & 7))
        sh_puts(w, "           (ninguno pulsado)\n", A_GRAY);
    sh_puts(w, "mueve el raton y vuelve a ejecutar 'raton' para ver el cambio\n", A_GRAY);
}

static void cmd_fenix(Window *w) {
    static const char *art[8] = {
        "      /\\        ___  ___  ___  ___  ___",
        "     /  \\       |   |___|  |  |___ |__",
        "    / /\\ \\      |   |   \\  |  |___  __|",
        "   / /  \\ \\",
        "  /_/ /\\ \\_\\    \"Renacer de las cenizas,",
        "    \\ \\/ /       un SO propio desde cero\"",
        "     \\__/",
        ""
    };
    for (int i = 0; i < 8; i++) {
        if (art[i][0]) sh_puts(w, art[i], i < 4 ? A_YELLOW : A_ACCENT);
        sh_putc(w, '\n', 0);
    }
}

/* ---------------------- comandos del RAMFS ---------------------- */
static void cmd_escribir_error(Window *w, int r);

static void cmd_archivos(Window *w) {
    const char *name;
    u32 size;
    int n = 0;
    if (!ramfs_count()) {
        sh_puts(w, "RAMFS vacio. Crea uno con 'tocar <archivo>'.\n", A_GRAY);
        return;
    }
    sh_printf(w, A_ACCENT, "%-20s %s\n", "ARCHIVO", "BYTES");
    for (int i = 0; i < 16; i++) {
        if (!ramfs_get(i, &name, &size)) continue;
        sh_printf(w, A_WHITE, "%-20s %lu\n", name, size);
        n++;
    }
    (void)n;
    sh_printf(w, A_GRAY, "%d archivo(s), %lu bytes usados de %d x %u\n",
              ramfs_count(), ramfs_bytes_used(), ramfs_slots(), ramfs_file_max());
}

static void cmd_escribir(Window *w, int argc, char **argv) {
    if (argc < 3) {
        sh_puts(w, "Uso: escribir <archivo> <texto...>\n", A_GRAY);
        return;
    }
    char texto[RAMFS_BUF];
    u32 len = 0;
    for (int i = 2; i < argc && len < sizeof(texto) - 1; i++) {
        if (i > 2) texto[len++] = ' ';
        for (const char *p = argv[i]; *p && len < sizeof(texto) - 1; p++)
            texto[len++] = *p;
    }
    texto[len] = 0;
    int r = ramfs_write(argv[1], texto, len);
    switch (r) {
    case 0:  sh_printf(w, A_GREEN, "archivo '%s' escrito (%lu bytes)\n", argv[1], len); break;
    case -1: sh_puts(w, "escribir: RAMFS lleno (32 archivos max)\n", A_RED); break;
    case -2: sh_puts(w, "escribir: sin memoria para los datos\n", A_RED); break;
    case -4: sh_printf(w, A_RED, "escribir: maximo %u bytes por archivo\n", ramfs_file_max()); break;
    default: sh_puts(w, "escribir: nombre invalido (sin espacios ni '/')\n", A_RED); break;
    }
}

static void cmd_leer(Window *w, int argc, char **argv) {
    if (argc < 2) { sh_puts(w, "Uso: leer <archivo>\n", A_GRAY); return; }
    char buf[RAMFS_BUF];
    int n = ramfs_read(argv[1], buf, sizeof(buf));
    if (n < 0) { sh_printf(w, A_RED, "leer: no existe '%s' (prueba 'archivos')\n", argv[1]); return; }
    if (n == 0) { sh_puts(w, "(archivo vacio)\n", A_GRAY); return; }
    sh_puts(w, buf, A_WHITE);
    if (n && buf[n - 1] != '\n') sh_putc(w, '\n', 0);
}

static void cmd_tocar(Window *w, int argc, char **argv) {
    if (argc < 2) { sh_puts(w, "Uso: tocar <archivo> (crea vacio)\n", A_GRAY); return; }
    int r = ramfs_write(argv[1], "", 0);
    if (r == 0) sh_printf(w, A_GREEN, "archivo '%s' creado\n", argv[1]);
    else cmd_escribir_error(w, r);
}

static void cmd_borrar(Window *w, int argc, char **argv) {
    if (argc < 2) { sh_puts(w, "Uso: borrar <archivo>\n", A_GRAY); return; }
    if (ramfs_delete(argv[1]) == 0)
        sh_printf(w, A_GREEN, "archivo '%s' borrado\n", argv[1]);
    else
        sh_printf(w, A_RED, "borrar: no existe '%s'\n", argv[1]);
}

static void cmd_escribir_error(Window *w, int r) {
    switch (r) {
    case 0:  break;
    case -1: sh_puts(w, "RAMFS lleno (32 archivos max)\n", A_RED); break;
    case -2: sh_puts(w, "sin memoria para los datos\n", A_RED); break;
    case -4: sh_printf(w, A_RED, "maximo %u bytes por archivo\n", ramfs_file_max()); break;
    default: sh_puts(w, "nombre invalido (sin espacios ni '/')\n", A_RED); break;
    }
}

/* ---------------------- sonido y ventanas ---------------------- */
static void cmd_sonido(Window *w) {
    sh_puts(w, "sonando tono de 880 Hz por el altavoz PC...\n", A_GRAY);
    sound_play(880, 220);
    sh_puts(w, "listo (en QEMU hace falta -audiodev para oirlo)\n", A_GREEN);
}

static void cmd_musica(Window *w) {
    sh_puts(w, "tocando melodia 'Renacer'...\n", A_GRAY);
    sound_melodia_fenix();
    sh_puts(w, "melodia terminada\n", A_GREEN);
}

static void cmd_editor(Window *w, int argc, char **argv) {
    if (argc >= 2) {
        if (!ramfs_exists(argv[1]))
            sh_printf(w, A_GRAY, "'%s' no existe: se creara al guardar\n", argv[1]);
        wm_open_editor(argv[1], 1);
    } else {
        wm_open_editor(NULLP, 1);
    }
    sh_puts(w, "editor abierto: teclea con la ventana en foco y pulsa Guardar\n", A_GRAY);
}

/* ---------------------------- ejecución ---------------------------- */
/* niveles de permiso por orden (v1.2): 0 todos, 1 usuario, 2 admin */
static int cmd_level(const char *cmd) {
    static const char *lvl_user[] = {
        "kill", "escribir", "write", "borrar", "rm", "tocar", "touch",
        "editor", "fx", "demo", "tema", "sonido", "beep", "musica", "play",
        "calculadora", "calc", "visor", "nav", "http", "ping", "win",
        "demo", "sistema", "sysinfo",
    };
    static const char *lvl_admin[] = {
        "apagar", "shutdown", "reboot", "reiniciar", "usuarios", "useradd",
        "arranque", "instalador",
    };
    for (u32 i = 0; i < sizeof(lvl_user) / sizeof(lvl_user[0]); i++)
        if (!strcmp(cmd, lvl_user[i])) return ROL_USUARIO;
    for (u32 i = 0; i < sizeof(lvl_admin) / sizeof(lvl_admin[0]); i++)
        if (!strcmp(cmd, lvl_admin[i])) return ROL_ADMIN;
    return ROL_INVITADO;
}

static void exec_line(Window *w) {
    /* trocear la línea en argv */
    char *argv[12];
    int argc = 0;
    char *p = linebuf;
    while (*p && argc < 12) {
        while (*p == ' ') p++;
        if (!*p) break;
        argv[argc++] = p;
        while (*p && *p != ' ') p++;
        if (*p) *p++ = 0;
    }
    if (argc == 0) return;
    const char *cmd = argv[0];
    klogf(LOG_INFO, "FSH", "orden: %s", cmd);

    /* control de permisos por rol (config y net lo refinan dentro) */
    int need = cmd_level(cmd);
    if (need > user_current_role()) {
        sh_printf(w, A_RED, "permiso denegado: '%s' requiere rol %s (eres %s)\n",
                  cmd, role_name(need), role_name(user_current_role()));
        klogf(LOG_WARN, "SEC", "'%s' denegada a '%s'", cmd, user_current_name());
        return;
    }

    if (!strcmp(cmd, "ayuda") || !strcmp(cmd, "help")) cmd_ayuda(w);
    else if (!strcmp(cmd, "info") || !strcmp(cmd, "osfetch")) cmd_osfetch(w);
    else if (!strcmp(cmd, "mem")) cmd_mem(w);
    else if (!strcmp(cmd, "ps")) cmd_ps(w);
    else if (!strcmp(cmd, "fecha") || !strcmp(cmd, "date")) cmd_fecha(w);
    else if (!strcmp(cmd, "raton") || !strcmp(cmd, "mouse")) cmd_raton(w);
    else if (!strcmp(cmd, "login") || !strcmp(cmd, "su")) cmd_login(w, argc, argv);
    else if (!strcmp(cmd, "salir") || !strcmp(cmd, "logout")) cmd_salir(w);
    else if (!strcmp(cmd, "quiensoy") || !strcmp(cmd, "whoami")) cmd_quiensoy(w);
    else if (!strcmp(cmd, "usuarios")) cmd_usuarios(w);
    else if (!strcmp(cmd, "useradd")) cmd_useradd(w, argc, argv);
    else if (!strcmp(cmd, "logs") || !strcmp(cmd, "dmesg")) cmd_logs(w, argc, argv);
    else if (!strcmp(cmd, "config")) cmd_config(w, argc, argv);
    else if (!strcmp(cmd, "disco") || !strcmp(cmd, "disk")) cmd_disco(w);
    else if (!strcmp(cmd, "sistema") || !strcmp(cmd, "sysinfo")) {
        sysinfo_open_window();
        sh_puts(w, "informacion del sistema abierta (icono 'Sistema')\n", A_GRAY);
    }
    else if (!strcmp(cmd, "instalador")) {
        wm_open_installer();
        sh_puts(w, "instalador abierto: elige disco, modo y confirma\n", A_GRAY);
    }
    else if (!strcmp(cmd, "arranque")) cmd_arranque(w, argc, argv);
    else if (!strcmp(cmd, "usb")) cmd_usb(w);
    else if (!strcmp(cmd, "ping")) cmd_ping(w, argc, argv);
    else if (!strcmp(cmd, "net")) cmd_net(w, argc, argv);
    else if (!strcmp(cmd, "nav") || !strcmp(cmd, "navegar") || !strcmp(cmd, "http")) cmd_nav(w, argc, argv);
    else if (!strcmp(cmd, "fx")) cmd_fx(w, argc, argv);
    else if (!strcmp(cmd, "ext")) cmd_ext(w, argc, argv);
    else if (!strcmp(cmd, "win") || !strcmp(cmd, "compat")) cmd_win(w, argc, argv);
    else if (!strcmp(cmd, "visor")) cmd_visor(w, argc, argv);
    else if (!strcmp(cmd, "calculadora") || !strcmp(cmd, "calcg")) {
        wm_open_calc();
        sh_puts(w, "calculadora abierta: toca los botones con el raton\n", A_GRAY);
    }
    else if (!strcmp(cmd, "tema")) cmd_tema(w, argc, argv);
    else if (!strcmp(cmd, "demo")) cmd_demo(w, argc, argv);
    else if (!strcmp(cmd, "calc")) cmd_calc(w, argc, argv);
    else if (!strcmp(cmd, "fenix")) cmd_fenix(w);
    else if (!strcmp(cmd, "archivos") || !strcmp(cmd, "ls")) cmd_archivos(w);
    else if (!strcmp(cmd, "escribir") || !strcmp(cmd, "write")) cmd_escribir(w, argc, argv);
    else if (!strcmp(cmd, "leer") || !strcmp(cmd, "cat")) cmd_leer(w, argc, argv);
    else if (!strcmp(cmd, "tocar") || !strcmp(cmd, "touch")) cmd_tocar(w, argc, argv);
    else if (!strcmp(cmd, "borrar") || !strcmp(cmd, "rm")) cmd_borrar(w, argc, argv);
    else if (!strcmp(cmd, "editor")) cmd_editor(w, argc, argv);
    else if (!strcmp(cmd, "sonido") || !strcmp(cmd, "beep")) cmd_sonido(w);
    else if (!strcmp(cmd, "musica") || !strcmp(cmd, "play")) cmd_musica(w);
    else if (!strcmp(cmd, "acerca") || !strcmp(cmd, "about")) { wm_open_about(); sh_puts(w, "ventana 'Acerca de FenixOS' abierta\n", A_GRAY); }
    else if (!strcmp(cmd, "limpiar") || !strcmp(cmd, "clear")) {
        for (int i = 0; i < w->cols * w->rows; i++) w->cells[i] = ' ';
        w->ccx = w->ccy = 0;
    }
    else if (!strcmp(cmd, "uptime")) {
        u64 secs = pit_ticks / 100;
        sh_printf(w, A_WHITE, "encendido %lu min %lu seg (%lu ticks)\n",
                  secs / 60, secs % 60, pit_ticks);
    }
    else if (!strcmp(cmd, "echo")) {
        for (int i = 1; i < argc; i++) {
            sh_puts(w, argv[i], A_WHITE);
            if (i < argc - 1) sh_putc(w, ' ', A_WHITE);
        }
        sh_putc(w, '\n', 0);
    }
    else if (!strcmp(cmd, "kill")) {
        if (argc < 2) { sh_puts(w, "uso: kill <id> (ver 'ps')\n", A_GRAY); return; }
        int id = 0;
        const char *s = argv[1];
        while (*s >= '0' && *s <= '9') id = id * 10 + (*s++ - '0');
        if (*s || id <= 0) { sh_puts(w, "kill: id invalido\n", A_RED); return; }
        if (id == 1) { sh_puts(w, "kill: la terminal no puede suicidarse\n", A_RED); return; }
        int alive = 0, can_kill = 0;
        for (int i = 0; i < MAX_TASKS; i++)
            if (tasks[i].id == id) { alive = 1; can_kill = tasks[i].killable; }
        if (!alive) { sh_puts(w, "kill: no existe esa tarea\n", A_RED); return; }
        if (!can_kill) { sh_puts(w, "kill: esa tarea es esencial del sistema\n", A_RED); return; }
        task_kill(id);
        klogf(LOG_INFO, "TASK", "tarea %d terminada por '%s'", id, user_current_name());
        if (id == demo_task_id) {
            demo_task_id = -1;
            demo_running = 0;
            Window *dw = gui_demo_window();
            if (dw) dw->visible = 0;
        }
        sh_printf(w, A_GREEN, "tarea %d terminada\n", id);
    }
    else if (!strcmp(cmd, "reboot") || !strcmp(cmd, "reiniciar")) {
        klog("SYS", "reboot solicitado por el usuario");
        sh_puts(w, "Reiniciando...\n", A_YELLOW);
        power_reboot();
    }
    else if (!strcmp(cmd, "apagar") || !strcmp(cmd, "shutdown")) {
        klog("SYS", "apagado solicitado por el usuario");
        sh_puts(w, "Apagando (ACPI)... si no se apaga usa Machine > ACPI Shutdown\n", A_YELLOW);
        power_shutdown();
    }
    else {
        sh_printf(w, A_RED, "fsh: orden no encontrada: %s (prueba 'ayuda')\n", cmd);
    }
}

/* gancho para FenixScript: ejecuta una orden de la shell tal cual
 * (la usa la instruccion EXEC de los scripts .fx) */
void shell_exec_hook(const char *line) {
    Window *w = gui_shell_window();
    if (!w || !line || !*line) return;
    char buf[160];
    strncpy(buf, line, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = 0;
    char *save = linebuf[0] ? linebuf : NULLP;   /* conservar linea en curso */
    (void)save;
    linebuf[0] = 0;
    int saved_pos = linepos;
    linepos = 0;
    strncpy(linebuf, buf, sizeof(linebuf) - 1);
    linebuf[sizeof(linebuf) - 1] = 0;
    exec_line(w);
    linepos = saved_pos;                          /* restaurar (simple) */
}

static void shell_handle_key(Window *w, int c) {
    if (c == '\n' || c == '\r') {
        sh_nl(w);
        linebuf[linepos] = 0;
        exec_line(w);
        linepos = 0;
        sh_prompt(w);
        return;
    }
    if (c == '\b' || c == 127) {
        if (linepos > 0) {
            linepos--;
            if (w->ccx > 0) w->ccx--;
            else if (w->ccy > 0) { w->ccy--; w->ccx = w->cols - 1; }
            w->cells[w->ccy * w->cols + w->ccx] = ' ';
        }
        return;
    }
    if (c >= 0x100) return;                 /* teclas no imprimibles */
    if (linepos < (int)sizeof(linebuf) - 1) {
        linebuf[linepos++] = (char)c;
        sh_putc(w, (char)c, A_WHITE);
    }
}

/* ---------------------------- tarea principal ---------------------------- */
void shell_task(void) {
    Window *w = gui_shell_window();
    if (!w) {
        for (;;) hlt_cpu();
    }
    shell_task_id = 1;
    sh_welcome(w);
    sh_prompt(w);

    for (;;) {
        task_wait_input();
        int c;
        while ((c = kbd_getc()) >= 0) {
            /* enrutado por foco: cada ventana recibe sus teclas */
            Window *fw = gui_focused_window();
            if (fw && fw->type == WIN_EDITOR)
                editor_feed_key(fw, c);
            else if (fw && fw->type == WIN_CALC)
                calc_feed_key(fw, c);
            else if (fw && fw->type == WIN_VIEWER)
                viewer_feed_key(fw, c);
            else
                shell_handle_key(w, c);
        }
    }
}

void shell_spawn(void) {
    int id = task_create("fsh", shell_task, 0);
    if (id >= 0) shell_task_id = id;
}
