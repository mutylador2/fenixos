/* FenixOS — klog.c: sistema de registro de eventos (v1.2)
 *
 * Tres destinos para cada evento:
 *   1. COM1 (consola de depuración, siempre)
 *   2. Anillo en RAM (últimos KLOG_MAX eventos consultables con 'logs')
 *   3. Archivo RAMFS sistema.log con 'logs guardar' (snapshot)
 *
 * Niveles: LOG_INFO (informativo), LOG_WARN (aviso), LOG_ERROR (error).
 * El anillo usa memoria estática: funciona incluso antes del heap. */
#include "fenixos.h"

#define KLOG_MAX   96
#define KLOG_MSG   80
#define KLOG_TAG   8

typedef struct {
    u32  secs;                    /* segundos desde el arranque */
    u8   level;                   /* LOG_* */
    char tag[KLOG_TAG];
    char msg[KLOG_MSG];
} LogEntry;

static LogEntry ring[KLOG_MAX];
static int ring_head = 0;         /* siguiente a escribir */
static int ring_total = 0;        /* nº de eventos desde el arranque */
static u64 boot_tick0 = 0;        /* tick de referencia (arranque del anillo) */

static void ring_push(u8 level, const char *tag, const char *msg) {
    LogEntry *e = &ring[ring_head];
    e->secs = (u32)((pit_ticks - boot_tick0) / 100);
    e->level = level;
    strncpy(e->tag, tag, KLOG_TAG - 1);
    e->tag[KLOG_TAG - 1] = 0;
    strncpy(e->msg, msg, KLOG_MSG - 1);
    e->msg[KLOG_MSG - 1] = 0;
    ring_head = (ring_head + 1) % KLOG_MAX;
    if (ring_total < KLOG_MAX) ring_total++;
}

static void emit(u8 level, const char *tag, const char *msg) {
    const char *lvl = (level == LOG_ERROR) ? "E" : (level == LOG_WARN) ? "W" : "I";
    serial_write("[");
    serial_write(lvl);
    serial_write("][");
    serial_write(tag);
    serial_write("] ");
    serial_write(msg);
    serial_write("\n");
    ring_push(level, tag, msg);
}

/* API básica (nivel INFO) — compatible con el uso previo */
void klog(const char *tag, const char *msg) { emit(LOG_INFO, tag, msg); }
void klogw(const char *tag, const char *msg) { emit(LOG_WARN, tag, msg); }
void kloge(const char *tag, const char *msg) { emit(LOG_ERROR, tag, msg); }

/* API con formato */
void klogf(u8 level, const char *tag, const char *fmt, ...) {
    char buf[KLOG_MSG];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    emit(level, tag, buf);
}

/* ------------------- consulta para la orden 'logs' ------------------- */

int klog_count(void) {
    return ring_total > KLOG_MAX ? KLOG_MAX : ring_total;
}

/* rellena buf con el evento i-ésimo (0 = más antiguo visible) */
int klog_get(int idx, u32 *secs, u8 *level, char *tag, char *msg) {
    int n = klog_count();
    if (idx < 0 || idx >= n) return 0;
    int base = (ring_total <= KLOG_MAX) ? 0 : ring_head;
    int real = (base + idx) % KLOG_MAX;
    LogEntry *e = &ring[real];
    if (secs) *secs = e->secs;
    if (level) *level = e->level;
    if (tag) strcpy(tag, e->tag);
    if (msg) strcpy(msg, e->msg);
    return 1;
}

void klog_clear(void) {
    ring_head = 0;
    ring_total = 0;
}

/* snapshot al RAMFS para inspección cómoda con 'leer' o el visor */
int klog_save(void) {
    static char buf[4096];
    u32 len = 0;
    int n = klog_count();
    for (int i = 0; i < n && len < sizeof(buf) - 100; i++) {
        u32 secs; u8 lvl; char tag[KLOG_TAG]; char msg[KLOG_MSG];
        klog_get(i, &secs, &lvl, tag, msg);
        char line[120];
        ksnprintf(line, sizeof(line), "[%c][+%u s][%s] %s\n",
                  (lvl == LOG_ERROR) ? 'E' : (lvl == LOG_WARN) ? 'W' : 'I',
                  secs, tag, msg);
        for (char *p = line; *p && len < sizeof(buf) - 1; p++) buf[len++] = *p;
    }
    buf[len] = 0;
    return ramfs_write("sistema.log", buf, len);
}
