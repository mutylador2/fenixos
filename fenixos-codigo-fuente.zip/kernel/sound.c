/* FenixOS — sound.c: driver del altavoz interno del PC (PC speaker)
 *
 * El altavoz clasico se controla con el canal 2 del PIT (8253/8254):
 *   - se programa el divisor para la frecuencia deseada (modo cuadrada 3)
 *   - se abre la puerta logica con los bits 0-1 del puerto 0x61
 *   - suena hasta que se cierra la puerta
 *
 * En QEMU hace falta un dispositivo de audio del anfitrion para oirlo
 * (-audiodev pa,...); en VirtualBox y en hardware real suena directo.
 * La orden queda registrada en el registro serial en cualquier caso. */
#include "fenixos.h"

#define PIT_CMD    0x43
#define PIT_CH2    0x42
#define SPEAKER_GW 0x61

#define PIT_BASE_HZ 1193182u

/* Programar el canal 2 del PIT a una frecuencia y dejar la puerta abierta */
static int speaker_on(u32 freq_hz) {
    if (freq_hz < 18 || freq_hz > 20000) return 0;
    u32 div = PIT_BASE_HZ / freq_hz;
    if (div > 65535) div = 65535;
    outb(PIT_CMD, 0xB6);              /* canal 2, lo/hi, modo 3 (onda cuadrada) */
    outb(PIT_CH2, (u8)(div & 0xFF));
    outb(PIT_CH2, (u8)((div >> 8) & 0xFF));
    outb(SPEAKER_GW, (u8)(inb(SPEAKER_GW) | 0x03));   /* puerta + altavoz ON */
    return 1;
}

static void speaker_off(void) {
    outb(SPEAKER_GW, (u8)(inb(SPEAKER_GW) & (u8)~0x03));
}

/* Tono bloqueante de ms milisegundos. Se usa pit_sleep_ticks, asi que
 * el planificador sigue moviendo el resto de tareas mientras suena. */
void sound_play(u32 freq_hz, u32 ms) {
    if (!speaker_on(freq_hz)) return;
    u64 ticks = ms / 10;
    if (!ticks) ticks = 1;
    pit_sleep_ticks(ticks);
    speaker_off();
}

/* Melodia "Renacer" — motivo corto del fenix (Do mayor ascendente y vuelta) */
typedef struct { u16 freq; u16 ms; } Note;
static const Note melodia_fenix[] = {
    { 523, 140 },   /* C5 */
    { 659, 140 },   /* E5 */
    { 784, 140 },   /* G5 */
    { 880, 280 },   /* A5  (climax) */
    { 784, 120 },   /* G5 */
    { 659, 120 },   /* E5 */
    { 880, 420 },   /* A5  (final largo) */
};

void sound_melodia_fenix(void) {
    for (u32 i = 0; i < sizeof(melodia_fenix) / sizeof(melodia_fenix[0]); i++)
        sound_play(melodia_fenix[i].freq, melodia_fenix[i].ms);
}
