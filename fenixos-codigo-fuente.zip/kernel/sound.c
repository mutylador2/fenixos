/* FenixOS — sound.c: driver del altavoz interno del PC (PC speaker)
 *
 * El altavoz clasico se controla con el canal 2 del PIT (8253/8254):
 *   - se programa el divisor para la frecuencia deseada (modo cuadrada 3)
 *   - se abre la puerta logica con los bits 0-1 del puerto 0x61
 *   - suena hasta que se cierra la puerta
 *
 * En QEMU hace falta un dispositivo de audio del anfitrion para oirlo
 * (-audiodev pa,...); en VirtualBox y en hardware real suena directo.
 * La orden queda registrada en el registro serial en cualquier caso. */
#include "fenixos.h"

#define PIT_CMD    0x43
#define PIT_CH2    0x42
#define SPEAKER_GW 0x61

#define PIT_BASE_HZ 1193182u

/* Programar el canal 2 del PIT a una frecuencia y dejar la puerta abierta */
static int speaker_on(u32 freq_hz) {
    if (freq_hz < 18 || freq_hz > 20000) return 0;
    u32 div = PIT_BASE_HZ / freq_hz;
    if (div > 65535) div = 65535;
    outb(PIT_CMD, 0xB6);              /* canal 2, lo/hi, modo 3 (onda cuadrada) */
    outb(PIT_CH2, (u8)(div & 0xFF));
    outb(PIT_CH2, (u8)((div >> 8) & 0xFF));
    outb(SPEAKER_GW, (u8)(inb(SPEAKER_GW) | 0x03));   /* puerta + altavoz ON */
    return 1;
}

static void speaker_off(void) {
    outb(SPEAKER_GW, (u8)(inb(SPEAKER_GW) & (u8)~0x03));
}

/* Tono bloqueante de ms milisegundos. Se usa pit_sleep_ticks, asi que
 * el planificador sigue moviendo el resto de tareas mientras suena. */
void sound_play(u32 freq_hz, u32 ms) {
    if (!speaker_on(freq_hz)) return;
    u64 ticks = ms / 10;
    if (!ticks) ticks = 1;
    pit_sleep_ticks(ticks);
    speaker_off();
}

/* Melodia "Renacer" — motivo corto del fenix (Do mayor ascendente y vuelta) */
typedef struct { u16 freq; u16 ms; } Note;
static const Note melodia_fenix[] = {
    { 523, 140 },   /* C5 */
    { 659, 140 },   /* E5 */
    { 784, 140 },   /* G5 */
    { 880, 280 },   /* A5  (climax) */
    { 784, 120 },   /* G5 */
    { 659, 120 },   /* E5 */
    { 880, 420 },   /* A5  (final largo) */
};

void sound_melodia_fenix(void) {
    for (u32 i = 0; i < sizeof(melodia_fenix) / sizeof(melodia_fenix[0]); i++)
        sound_play(melodia_fenix[i].freq, melodia_fenix[i].ms);
}

/* ---------------- AC97 (v1.4): melodía sintetizada ----------------
 * Genera la melodía como PCM estéreo 16-bit a 48 kHz (seno con
 * envolvente ADSR simplificada) y la reproduce por DMA. Si no hay
 * AC97 cae al altavoz clásico del PC. En QEMU se verifica volcando
 * a WAV con -audiodev driver=wav. */
#define AC97_RATE 48000

int sound_ac97_ok(void) { return ac97_present(); }

void sound_melodia_ac97(void) {
    u32 total_ms = 0;
    for (u32 i = 0; i < sizeof(melodia_fenix) / sizeof(melodia_fenix[0]); i++)
        total_ms += melodia_fenix[i].ms;
    /* marcos estéreo (redondeados a múltiplo del búfer del BDL) */
    u32 frames = total_ms * AC97_RATE / 1000;
    const u32 BUFSZ = 8192;
    frames = (frames + BUFSZ - 1) / BUFSZ * BUFSZ;

    i16 *pcm = (i16 *)kmalloc(frames * 4);      /* 4 bytes por marco (L+R) */
    if (!pcm) { sound_melodia_fenix(); return; } /* sin memoria: altavoz */

    u32 f = 0;
    for (u32 n = 0; n < sizeof(melodia_fenix) / sizeof(melodia_fenix[0]); n++) {
        u32 nlen = melodia_fenix[n].ms * AC97_RATE / 1000;
        u32 f0 = nlen / 100, f1 = nlen / 20;    /* attack 10 ms, release 50 ms */
        i64 phase = 0;
        i64 dphase = (i64)melodia_fenix[n].freq * 65536 * 65536 / AC97_RATE;
        for (u32 k = 0; k < nlen && f < frames; k++, f++) {
            i32 env = 10000;
            if (k < f0) env = (i32)(k * 10000 / f0);              /* attack */
            else if (k > nlen - f1) env = (i32)((nlen - k) * 10000 / f1);
            i32 amp = 13000 * env / 10000;
            /* seno por identidad en 4 cuadrantes (tabla lineal implícita) */
            u32 ang = (u32)((phase >> 16) & 0xFFFF);
            i32 sv;
            if (ang < 8192)       sv = (i32)((ang * amp) >> 13);
            else if (ang < 16384) sv = (i32)((16384 - ang) * amp >> 13);
            else if (ang < 24576) sv = -(i32)((ang - 16384) * amp >> 13);
            else                  sv = -(i32)((65536 - ang) * amp >> 13);
            pcm[f * 2]     = (i16)sv;
            pcm[f * 2 + 1] = (i16)sv;
            phase += dphase;
        }
    }
    /* rellenar el sobrante con silencio */
    for (; f < frames; f++) { pcm[f * 2] = 0; pcm[f * 2 + 1] = 0; }

    int r = ac97_play(pcm, frames);
    kfree(pcm);
    if (r != 0) sound_melodia_fenix();          /* DMA falló: altavoz */
}

/* tono suelto por AC97 (para 'sonido') */
void sound_tone_ac97(u32 freq, u32 ms) {
    u32 frames = ms * AC97_RATE / 1000;
    const u32 BUFSZ = 8192;
    frames = (frames + BUFSZ - 1) / BUFSZ * BUFSZ;
    if (frames > BUFSZ * 16) frames = BUFSZ * 16;
    i16 *pcm = (i16 *)kmalloc(frames * 4);
    if (!pcm) { sound_play(freq, ms); return; }
    i64 phase = 0;
    i64 dphase = (i64)freq * 65536 * 65536 / AC97_RATE;
    for (u32 k = 0; k < frames; k++) {
        u32 ang = (u32)((phase >> 16) & 0xFFFF);
        i32 sv;
        if (ang < 8192)       sv = (i32)((ang * 12000) >> 13);
        else if (ang < 16384) sv = (i32)((16384 - ang) * 12000 >> 13);
        else if (ang < 24576) sv = -(i32)((ang - 16384) * 12000 >> 13);
        else                  sv = -(i32)((65536 - ang) * 12000 >> 13);
        pcm[k * 2] = (i16)sv;
        pcm[k * 2 + 1] = (i16)sv;
        phase += dphase;
    }
    int r = ac97_play(pcm, frames);
    kfree(pcm);
    if (r != 0) sound_play(freq, ms);
}
