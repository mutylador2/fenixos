/* FenixOS — usb.c: detección de controladoras USB (v1.2)
 *
 * Estado actual: ENUMERACIÓN (no hay pila USB funcional).
 * Se apoya en pci.c para localizar controladoras USB (clase 0x0C, subclase
 * 0x03) e informa del tipo según el interfaz de programación:
 *   0x00 UHCI (USB 1.1) · 0x10 OHCI (USB 1.1) · 0x20 EHCI (USB 2.0)
 *   0x30 xHCI (USB 3.x)
 *
 * Con una pila host completa se podría enlazar el móvil por cable USB
 * (anclaje de red RNDIS/NCM) para compartir Internet: queda en la hoja
 * de ruta, junto a teclados/ratones USB y almacenamiento UAS. */
#include "fenixos.h"

#define MAX_USB_CTLS 4

typedef struct {
    u8 bus, dev;
    u8 prog_if;
} UsbCtl;

static UsbCtl ctls[MAX_USB_CTLS];
static int usb_count = 0;

static const char *usb_type_name(u8 prog_if) {
    switch (prog_if) {
    case 0x00: return "UHCI (USB 1.1)";
    case 0x10: return "OHCI (USB 1.1)";
    case 0x20: return "EHCI (USB 2.0)";
    case 0x30: return "xHCI (USB 3.x)";
    default:   return "USB (?)";
    }
}

int usb_scan(void) {
    usb_count = 0;
    for (int i = 0; i < pci_count(); i++) {
        PciDev *d = pci_get(i);
        if (!d) continue;
        if (d->class_code == 0x0C && d->subclass == 0x03 && usb_count < MAX_USB_CTLS) {
            ctls[usb_count].bus = d->bus;
            ctls[usb_count].dev = d->dev;
            ctls[usb_count].prog_if = d->prog_if;
            usb_count++;
        }
    }
    return usb_count;
}

int usb_info(int idx, const char **type, u8 *bus, u8 *dev) {
    if (idx < 0 || idx >= usb_count) return 0;
    if (type) *type = usb_type_name(ctls[idx].prog_if);
    if (bus) *bus = ctls[idx].bus;
    if (dev) *dev = ctls[idx].dev;
    return 1;
}
