/* FenixOS — users.c: sistema de usuarios, roles y permisos (v1.2)
 *
 * Roles jerárquicos:
 *   ROL_INVITADO (0) : solo lectura y consultas
 *   ROL_USUARIO  (1) : uso normal (archivos, apps, red, scripts)
 *   ROL_ADMIN    (2) : gestión (config, kill, apagar, usuarios, logs)
 *
 * Usuarios de fábrica:
 *   admin    / fenix   (administrador)
 *   usuario  / 1234    (usuario)
 *   invitado / (sin clave) (invitado)
 *
 * La sesión activa se guarda en RAM; 'login'/'su' cambian de usuario.
 * Las contraseñas se almacenan como hash djb2 (jamás en claro).
 *
 * v1.3: la tabla de cuentas se persiste en el disco (sector
 * blk_users_lba(), junto al de configuración): las cuentas creadas con
 * 'user_add' sobreviven al reinicio. */
#include "fenixos.h"

#define MAX_USERS 8
#define MAX_NAME  16
#define USERS_MAGIC "FNXUSRS1"

typedef struct {
    char name[MAX_NAME];
    u32  pass_hash;             /* djb2; 0 = sin clave */
    int  role;                  /* ROL_* */
    int  used;
} User;

static User users[MAX_USERS] = {
    { "admin",    0, ROL_ADMIN,    0 },
    { "usuario",  0, ROL_USUARIO,  0 },
    { "invitado", 0, ROL_INVITADO, 0 },
};
static int cur_user = -1;       /* índice del usuario en sesión */
static char cur_name[MAX_NAME] = "invitado";
static int cur_role = ROL_INVITADO;

u32 user_hash(const char *s) {
    if (!s || !*s) return 0;
    u32 h = 5381;
    while (*s) h = ((h << 5) + h) ^ (u8)*s++;
    return h ? h : 1;             /* evita colisión con "sin clave" */
}

void users_init(void) {
    users[0].pass_hash = user_hash("fenix");
    users[1].pass_hash = user_hash("1234");
    users[2].pass_hash = 0;       /* invitado sin clave */
    for (int i = 3; i < MAX_USERS; i++) users[i].used = 0;
    for (int i = 0; i < 3; i++) users[i].used = 1;

    users_load_disk();            /* v1.3: recuperar cuentas guardadas */

    /* autologin desde la configuración persistente (por defecto admin) */
    const char *auto_user = config_get("autologin");
    if (!auto_user) auto_user = "admin";
    int idx = -1;
    for (int i = 0; i < MAX_USERS; i++)
        if (users[i].used && !strcmp(users[i].name, auto_user)) { idx = i; break; }
    if (idx < 0) idx = 0;

    cur_user = idx;
    strncpy(cur_name, users[idx].name, MAX_NAME - 1);
    cur_name[MAX_NAME - 1] = 0;
    cur_role = users[idx].role;
    klogf(LOG_INFO, "USR", "sesion iniciada como '%s' (rol %s)",
          cur_name, role_name(cur_role));
}

int user_login(const char *name, const char *pass) {
    for (int i = 0; i < MAX_USERS; i++) {
        if (!users[i].used || strcmp(users[i].name, name)) continue;
        if (users[i].pass_hash == 0 || users[i].pass_hash == user_hash(pass)) {
            cur_user = i;
            strncpy(cur_name, users[i].name, MAX_NAME - 1);
            cur_name[MAX_NAME - 1] = 0;
            cur_role = users[i].role;
            klogf(LOG_INFO, "USR", "login: '%s' (rol %s)", cur_name, role_name(cur_role));
            return 0;
        }
        klogf(LOG_WARN, "USR", "clave incorrecta para '%s'", name);
        return -2;                /* clave incorrecta */
    }
    klogf(LOG_WARN, "USR", "login de usuario inexistente '%s'", name);
    return -1;                    /* no existe */
}

int user_logout(void) {
    if (cur_role == ROL_INVITADO && !strcmp(cur_name, "invitado")) return -1;
    klogf(LOG_INFO, "USR", "logout de '%s'", cur_name);
    cur_user = 2;                 /* invitado */
    strcpy(cur_name, "invitado");
    cur_role = ROL_INVITADO;
    return 0;
}

const char *user_current_name(void) { return cur_name; }
int user_current_role(void)        { return cur_role; }
const char *role_name(int r) {
    switch (r) {
    case ROL_ADMIN:    return "admin";
    case ROL_USUARIO:  return "usuario";
    default:           return "invitado";
    }
}

/* lista usuarios para la orden 'usuarios' */
int user_list(int idx, const char **name, int *role) {
    if (idx < 0 || idx >= MAX_USERS) return 0;
    if (!users[idx].used) return 0;
    if (name) *name = users[idx].name;
    if (role) *role = users[idx].role;
    return 1;
}

/* ¿el rol actual alcanza el nivel exigido? */
int user_perm_ok(int required) {
    return cur_role >= required;
}

/* gestión de cuentas (solo admin): user_add(name, pass, role) */
int user_add(const char *name, const char *pass, int role) {
    if (!name || !*name || strlen(name) >= MAX_NAME) return -1;
    if (role < ROL_INVITADO || role > ROL_ADMIN) return -1;
    for (int i = 0; i < MAX_USERS; i++)
        if (users[i].used && !strcmp(users[i].name, name)) return -2;  /* ya existe */
    for (int i = 0; i < MAX_USERS; i++) {
        if (!users[i].used) {
            strncpy(users[i].name, name, MAX_NAME - 1);
            users[i].name[MAX_NAME - 1] = 0;
            users[i].pass_hash = (pass && *pass) ? user_hash(pass) : 0;
            users[i].role = role;
            users[i].used = 1;
            klogf(LOG_INFO, "USR", "cuenta creada: '%s' (rol %s)", name, role_name(role));
            users_save_disk();      /* v1.3: persistir de inmediato */
            return 0;
        }
    }
    return -3;                    /* sin ranuras */
}

/* ---------------- persistencia de cuentas (v1.3) ----------------
 * Un sector de 512 B: firma + (nombre[16] + hash u32 + rol u32)*8. */
int users_save_disk(void) {
    if (!blk_present()) return -1;
    static u8 sector[512];
    memset(sector, 0, sizeof(sector));
    memcpy(sector, USERS_MAGIC, 8);
    u8 *p = sector + 8;
    for (int i = 0; i < MAX_USERS; i++, p += 62) {
        if (!users[i].used) continue;
        strncpy((char *)p, users[i].name, MAX_NAME - 1);
        u32 h = users[i].pass_hash;
        p[16] = (u8)(h & 0xFF); p[17] = (u8)((h >> 8) & 0xFF);
        p[18] = (u8)((h >> 16) & 0xFF); p[19] = (u8)((h >> 24) & 0xFF);
        u32 r = (u32)users[i].role;
        p[20] = (u8)(r & 0xFF); p[21] = (u8)((r >> 8) & 0xFF);
        p[22] = (u8)((r >> 16) & 0xFF); p[23] = (u8)((r >> 24) & 0xFF);
    }
    if (blk_write(blk_users_lba(), sector) != 0) {
        klogw("USR", "no se pudieron guardar las cuentas en disco");
        return -2;
    }
    klog("USR", "cuentas guardadas en disco");
    return 0;
}

int users_load_disk(void) {
    if (!blk_present()) return -1;
    static u8 sector[512];
    if (blk_read(blk_users_lba(), sector) != 0) return -2;
    if (memcmp(sector, USERS_MAGIC, 8) != 0) return 1;    /* primera vez */
    const u8 *p = sector + 8;
    int loaded = 0;
    for (int i = 0; i < MAX_USERS; i++, p += 62) {
        if (!p[0]) continue;
        strncpy(users[i].name, (const char *)p, MAX_NAME - 1);
        users[i].name[MAX_NAME - 1] = 0;
        users[i].pass_hash = (u32)p[16] | ((u32)p[17] << 8)
                           | ((u32)p[18] << 16) | ((u32)p[19] << 24);
        u32 r = (u32)p[20] | ((u32)p[21] << 8)
              | ((u32)p[22] << 16) | ((u32)p[23] << 24);
        users[i].role = (int)(r & 3);
        users[i].used = 1;
        loaded++;
    }
    if (loaded)
        klogf(LOG_INFO, "USR", "cuentas recuperadas del disco (%d personalizadas)", loaded);
    return 0;
}
