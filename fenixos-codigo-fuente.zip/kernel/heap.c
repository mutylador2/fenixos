/* FenixOS — heap.c: asignador de kernel kmalloc/kfree (first-fit con coalescencia)
 * Región: [heap_start, heap_start + HEAP_SIZE) tras el kernel, alineada a 2MB. */
#include "fenixos.h"

#define HEAP_SIZE (16u << 20)        /* 16MB */
#define MIN_SPLIT 32
#define HDR_MAGIC 0x46454E49u        /* 'FENI' */

typedef struct Block {
    u32 size;                        /* tamaño útil (sin cabecera) */
    u32 used;
    u32 magic;
    u32 pad;
} Block;

#define HDR_SIZE sizeof(Block)

u64 heap_start = 0, heap_end = 0, heap_used = 0, heap_size = 0;
static int heap_ready = 0;

void heap_init(void) {
    u64 base = (kernel_end_addr + 0x1FFFFF) & ~(u64)0x1FFFFF;   /* alinear a 2MB */
    u64 pages = HEAP_SIZE / PAGE_SIZE;
    u64 phys = pmm_alloc_contig((u32)pages);
    if (phys) base = phys;
    heap_start = base;
    heap_size = HEAP_SIZE;
    heap_end = base + HEAP_SIZE;
    heap_used = 0;

    Block *b = (Block *)heap_start;
    b->size = (u32)(HEAP_SIZE - HDR_SIZE);
    b->used = 0;
    b->magic = HDR_MAGIC;
    b->pad = 0;
    heap_ready = 1;
}

void *kmalloc(size_t n) {
    if (!heap_ready || n == 0 || n > heap_size) return NULLP;
    u32 need = (u32)((n + 15) & ~(u32)15);          /* alineado a 16 */
    Block *b = (Block *)heap_start;
    Block *end = (Block *)heap_end;
    while (b < end) {
        if (b->magic != HDR_MAGIC) return NULLP;    /* heap corrupta */
        if (!b->used && b->size >= need) {
            if (b->size >= need + HDR_SIZE + MIN_SPLIT) {
                Block *rest = (Block *)((u8 *)b + HDR_SIZE + need);
                rest->size = b->size - need - HDR_SIZE;
                rest->used = 0;
                rest->magic = HDR_MAGIC;
                rest->pad = 0;
                b->size = need;
            }
            b->used = 1;
            heap_used += b->size + HDR_SIZE;
            return (void *)((u8 *)b + HDR_SIZE);
        }
        b = (Block *)((u8 *)b + HDR_SIZE + b->size);
    }
    return NULLP;
}

void kfree(void *p) {
    if (!p || !heap_ready) return;
    Block *b = (Block *)((u8 *)p - HDR_SIZE);
    if (b->magic != HDR_MAGIC || !b->used) return;  /* puntero inválido */
    heap_used -= b->size + HDR_SIZE;
    b->used = 0;

    /* coalescencia hacia delante */
    Block *end = (Block *)heap_end;
    Block *nxt = (Block *)((u8 *)b + HDR_SIZE + b->size);
    while (nxt < end && nxt->magic == HDR_MAGIC && !nxt->used) {
        b->size += HDR_SIZE + nxt->size;
        nxt = (Block *)((u8 *)b + HDR_SIZE + b->size);
    }

    /* coalescencia hacia atrás (barrido lineal, heap pequeña) */
    Block *cur = (Block *)heap_start;
    while (cur < end && cur < b) {
        if (cur->magic != HDR_MAGIC) break;
        Block *cnext = (Block *)((u8 *)cur + HDR_SIZE + cur->size);
        if (cnext == b) {
            if (!cur->used) {
                cur->size += HDR_SIZE + b->size;
                b = cur;
                continue;                            /* seguir fusionando */
            }
            break;
        }
        cur = cnext;
    }
}

void *kcalloc(size_t n) {
    void *p = kmalloc(n);
    if (p) memset(p, 0, n);
    return p;
}
