/* FenixOS — task.c: multitarea round-robin.
 * Cada tarea tiene su propia pila de kernel; el frame de interrupción
 * queda en la pila de la tarea interrumpida y el scheduler solo cambia
 * RSP al frame de la siguiente tarea (task_switch_schedule). */
#include "fenixos.h"

Task tasks[MAX_TASKS];
Task *current_task = NULLP;
static int next_id = 1;
static int cur_idx = 0;

void task_init(void) {
    for (int i = 0; i < MAX_TASKS; i++) {
        tasks[i].id = -1;
        tasks[i].name[0] = 0;
        tasks[i].state = T_DEAD;
        tasks[i].killable = 0;
        tasks[i].resume_rsp = 0;
        tasks[i].kstack_phys = 0;
        tasks[i].switches = 0;
        tasks[i].next = NULLP;
    }
    /* tarea 0 = núcleo en ejecución (kmain) */
    tasks[0].id = 0;
    strcpy(tasks[0].name, "principal");
    tasks[0].state = T_READY;
    tasks[0].killable = 0;
    tasks[0].kstack_phys = 0x80000;
    cur_idx = 0;
    current_task = &tasks[0];
}

int task_create(const char *name, void (*fn)(void), int killable) {
    cli_irq();
    int slot = -1;
    for (int i = 1; i < MAX_TASKS; i++) {
        if (tasks[i].state == T_DEAD) { slot = i; break; }
    }
    if (slot < 0) { sti_irq(); return -1; }

    u64 stack = pmm_alloc_contig(TASK_KSTACK_PAGES);
    if (!stack) { sti_irq(); return -1; }

    Task *t = &tasks[slot];
    t->id = next_id++;
    strncpy(t->name, name, sizeof(t->name) - 1);
    t->name[sizeof(t->name) - 1] = 0;
    t->killable = killable;
    t->kstack_phys = stack;
    t->state = T_READY;

    /* frame inicial canónico en la cima de la pila propia (176 bytes:
     * 15 regs + vector + err + rip/cs/rflags + rsp/ss para el iretq) */
    Frame *f = (Frame *)(stack + TASK_KSTACK_PAGES * PAGE_SIZE - sizeof(Frame));
    memset(f, 0, sizeof(Frame));
    f->rip = (u64)fn;
    f->cs = 0x08;
    f->rflags = 0x202;                  /* IF=1 */
    f->rsp = stack + TASK_KSTACK_PAGES * PAGE_SIZE;
    f->ss = 0x10;
    t->resume_rsp = (u64)f;

    sti_irq();
    return t->id;
}

void task_kill(int id) {
    for (int i = 1; i < MAX_TASKS; i++) {
        if (tasks[i].id == id && tasks[i].killable && tasks[i].state != T_DEAD) {
            tasks[i].state = T_DEAD;
            if (tasks[i].kstack_phys) {
                for (u32 p = 0; p < TASK_KSTACK_PAGES; p++)
                    pmm_free(tasks[i].kstack_phys + (u64)p * PAGE_SIZE);
                tasks[i].kstack_phys = 0;
            }
            tasks[i].id = -1;
        }
    }
}

/* llamado desde la IRQ0 (contexto de interrupción).
 * rdi/rax: frame actual; devuelve el frame de la tarea a ejecutar. */
u64 task_switch_schedule(u64 frame_addr) {
    current_task->resume_rsp = frame_addr;
    for (int k = 1; k <= MAX_TASKS; k++) {
        Task *t = &tasks[(cur_idx + k) % MAX_TASKS];
        if (t->id >= 0 && t->state == T_READY) {
            if (k == MAX_TASKS || t == current_task)
                return frame_addr;      /* solo estamos nosotros */
            cur_idx = (int)(t - tasks);
            current_task = t;
            t->switches++;
            return t->resume_rsp ? t->resume_rsp : frame_addr;
        }
    }
    return frame_addr;
}

/* bloquea la tarea actual hasta que llegue una tecla */
void task_wait_input(void) {
    cli_irq();
    if (!kbd_available()) {
        current_task->state = T_BLOCKED;
        sti_irq();
        while (current_task->state == T_BLOCKED) hlt_cpu();
    } else {
        sti_irq();
    }
}

int task_count_alive(void) {
    int n = 0;
    for (int i = 0; i < MAX_TASKS; i++)
        if (tasks[i].id >= 0 && tasks[i].state != T_DEAD) n++;
    return n;
}
