/* FenixOS — net.c: pila TCP/IP básica con sockets (v1.2)
 *
 * Capas implementadas (IPv4, sin fragmentación, una interfaz):
 *   Ethernet -> ARP (caché de 4 entradas) -> IPv4 (checksum)
 *   -> ICMP (echo request/reply: ping) · UDP (DNS) · TCP (minimal)
 *   -> HTTP/1.1 GET (con redirecciones y chunked) + HTML -> texto
 *
 * TCP "minimal": un solo socket activo, ventana fija 16 KB, sin
 * retransmisión agresiva (2 reintentos) — suficiente para HTTP en
 * redes virtuales donde no hay pérdida. Direcciones por defecto
 * (QEMU/VirtualBox NAT): 10.0.2.15/24, puerta 10.0.2.2, DNS 10.0.2.3. */
#include "fenixos.h"

int strncasecmp_fenix(const char *a, const char *b, u32 n);

#define ET_ARP  0x0806
#define ET_IP   0x0800

#define IP_ICMP 1
#define IP_TCP  6
#define IP_UDP  17

#define TCP_FIN 0x01
#define TCP_SYN 0x02
#define TCP_RST 0x04
#define TCP_PSH 0x08
#define TCP_ACK 0x10

static u32 my_ip = 0, gw_ip = 0, dns_ip = 0;
static u8  my_mac[6];
static u32 tx_count = 0, rx_count = 0;

/* ---------------- ARP ---------------- */
#define ARP_CACHE 4
typedef struct { u32 ip; u8 mac[6]; int used; } ArpEnt;
static ArpEnt arp_cache[ARP_CACHE];

/* ---------------- buffers ---------------- */
static u8 frame_in[2048];
static u8 pkt_out[1600];

/* ---------------- DNS ---------------- */
static volatile int dns_ready = 0;
static volatile u16 dns_id = 0;
static u32 dns_answer_ip = 0;

/* ---------------- ping ---------------- */
static volatile int ping_pending = 0;
static u16 ping_id = 0, ping_seq = 0;
static volatile u64 ping_sent_tick = 0;
static volatile int ping_ok = 0;

/* ---------------- TCP (un socket: cliente o servidor) ---------------- */
#define TCP_NONE 0
#define TCP_SYN_SENT 1
#define TCP_EST 2
#define TCP_CLOSED 3
#define TCP_LISTEN 4
#define TCP_SYN_RCVD 5
static struct {
    int state;
    u32 rip;
    u16 lport, rport;
    u32 seq, ack;
} tcb;

#define RXRING 16384
static u8  tcp_rx[RXRING];
static volatile u32 tcp_head = 0, tcp_tail = 0;
static volatile int tcp_fin = 0;

/* ---------------- utilidades ---------------- */
static inline u16 hb16(u16 v) { return (u16)((v >> 8) | (v << 8)); }
static inline u32 hb32(u32 v) {
    return ((v & 0xFF) << 24) | ((v & 0xFF00) << 8) | ((v >> 8) & 0xFF00) | (v >> 24);
}

static u16 csum(const u8 *data, u32 len, u32 sum) {
    for (u32 i = 0; i + 1 < len; i += 2)
        sum += (u32)data[i] << 8 | data[i + 1];
    if (len & 1) sum += (u32)data[len - 1] << 8;
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    return (u16)(~sum);
}

void net_ip_str(u32 ip, char *buf, u32 size) {
    ksnprintf(buf, size, "%u.%u.%u.%u",
              ip & 0xFF, (ip >> 8) & 0xFF, (ip >> 16) & 0xFF, (ip >> 24) & 0xFF);
}

int net_ip_parse(const char *s, u32 *out) {
    if (!s || !out) return 0;
    /* convención interna: little-endian (el 1er octeto en el byte bajo),
     * así memcpy(ip) produce el orden exacto del cable */
    u32 ip = 0;
    int parts = 0;
    for (int p = 0; p < 4; p++) {
        u32 v = 0, digits = 0;
        while (*s >= '0' && *s <= '9') { v = v * 10 + (u32)(*s++ - '0'); digits++; }
        if (!digits || v > 255) return 0;
        ip |= v << (p * 8);
        parts++;
        if (p < 3) { if (*s != '.') return 0; s++; }
    }
    if (*s || parts != 4) return 0;
    *out = ip;
    return 1;
}

int net_ready(void)  { return e1000_present(); }
u32  net_my_ip(void) { return my_ip; }
u32  net_gateway(void) { return gw_ip; }
u32  net_dns(void)   { return dns_ip; }
void net_mac(u8 m[6]) { for (int i = 0; i < 6; i++) m[i] = my_mac[i]; }
u32  net_tx_count(void) { return tx_count; }
u32  net_rx_count(void) { return rx_count; }

void net_set_ips(u32 ip, u32 gw, u32 dns) {
    my_ip = ip;
    if (gw) gw_ip = gw;
    if (dns) dns_ip = dns;
    char b[16];
    net_ip_str(ip, b, sizeof(b));
    klogf(LOG_INFO, "NET", "IP fijada a %s", b);
}

int net_init(void) {
    pci_init();
    if (e1000_init() != 0) {
        klogw("NET", "pila TCP/IP inactiva (sin NIC)");
        return -1;
    }
    e1000_mac(my_mac);
    for (int i = 0; i < ARP_CACHE; i++) arp_cache[i].used = 0;
    tcb.state = TCP_NONE;

    /* direcciones desde la configuración persistente (defaults slirp) */
    const char *s = config_get("ip");
    if (!s || !net_ip_parse(s, &my_ip))   my_ip = 0x0F02000Au;   /* 10.0.2.15 (LE) */
    s = config_get("gw");
    if (!s || !net_ip_parse(s, &gw_ip))   gw_ip = 0x0202000Au;   /* 10.0.2.2  (LE) */
    s = config_get("dns");
    if (!s || !net_ip_parse(s, &dns_ip))  dns_ip = 0x0302000Au;  /* 10.0.2.3  (LE) */
    tcb.lport = (u16)(40000 + (pit_ticks % 2000));

    char b1[16], b2[16], b3[16];
    net_ip_str(my_ip, b1, sizeof(b1));
    net_ip_str(gw_ip, b2, sizeof(b2));
    net_ip_str(dns_ip, b3, sizeof(b3));
    klogf(LOG_INFO, "NET", "pila lista: IP %s GW %s DNS %s", b1, b2, b3);
    return 0;
}

/* ---------------- envío Ethernet ---------------- */
static int eth_send(u8 dst_mac[6], u16 etype, const u8 *payload, u32 len) {
    if (14 + len > sizeof(pkt_out)) return -1;
    memcpy(pkt_out, dst_mac, 6);
    memcpy(pkt_out + 6, my_mac, 6);
    pkt_out[12] = (u8)(etype >> 8);
    pkt_out[13] = (u8)(etype & 0xFF);
    memcpy(pkt_out + 14, payload, len);
    int r = e1000_send(pkt_out, 14 + len);
    if (r == 0) tx_count++;
    return r;
}

/* ---------------- ARP ---------------- */
static void arp_reply(const u8 *req) {
    u8 out[28];
    /* htype/ptype/hlen/plen/op */
    out[0] = 0; out[1] = 1; out[2] = 8; out[3] = 0;
    out[4] = 6; out[5] = 4; out[6] = 0; out[7] = 2;
    memcpy(out + 8, my_mac, 6);
    memcpy(out + 14, &my_ip, 4);
    memcpy(out + 18, req + 8, 6);         /* MAC destino */
    memcpy(out + 24, req + 14, 4);        /* IP destino */
    eth_send((u8 *)(req + 8), ET_ARP, out, 28);
}

static void arp_request(u32 ip) {
    u8 out[28];
    static const u8 bcast[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
    out[0] = 0; out[1] = 1; out[2] = 8; out[3] = 0;
    out[4] = 6; out[5] = 4; out[6] = 0; out[7] = 1;
    memcpy(out + 8, my_mac, 6);
    memcpy(out + 14, &my_ip, 4);
    memset(out + 18, 0, 6);
    memcpy(out + 24, &ip, 4);
    eth_send((u8 *)bcast, ET_ARP, out, 28);
}

static void arp_cache_add(u32 ip, const u8 mac[6]) {
    for (int i = 0; i < ARP_CACHE; i++)
        if (arp_cache[i].used && arp_cache[i].ip == ip) {
            memcpy(arp_cache[i].mac, mac, 6);
            return;
        }
    for (int i = 0; i < ARP_CACHE; i++)
        if (!arp_cache[i].used) {
            arp_cache[i].used = 1;
            arp_cache[i].ip = ip;
            memcpy(arp_cache[i].mac, mac, 6);
            return;
        }
    arp_cache[0].used = 1;                 /* recicla la primera */
    arp_cache[0].ip = ip;
    memcpy(arp_cache[0].mac, mac, 6);
}

/* procesa UNA trama entrante (recursión: tcp rx genera ACKs) */
static void process_frame(const u8 *f, u32 len);

static int arp_lookup(u32 ip, u8 mac_out[6], u32 timeout_ticks) {
    for (int i = 0; i < ARP_CACHE; i++)
        if (arp_cache[i].used && arp_cache[i].ip == ip) {
            memcpy(mac_out, arp_cache[i].mac, 6);
            return 1;
        }
    u64 deadline = pit_ticks + timeout_ticks;
    arp_request(ip);
    while (pit_ticks < deadline) {
        int n = e1000_poll(frame_in, sizeof(frame_in));
        if (n > 0) { rx_count++; process_frame(frame_in, (u32)n); }
        else hlt_cpu();
        for (int i = 0; i < ARP_CACHE; i++)
            if (arp_cache[i].used && arp_cache[i].ip == ip) {
                memcpy(mac_out, arp_cache[i].mac, 6);
                return 1;
            }
    }
    return 0;
}

/* ---------------- IP ---------------- */
static u16 ip_csum(const u8 *h) { return csum(h, 20, 0); }

static int ip_send(u8 proto, u32 dst, const u8 *payload, u32 len) {
    if (20 + len > sizeof(pkt_out)) return -1;
    u8 mac[6];
    u32 next = ((dst & 0xFFFFFF00) == (my_ip & 0xFFFFFF00)) ? dst : gw_ip;
    if (!arp_lookup(next, mac, 150)) {
        char nb[16];
        net_ip_str(next, nb, sizeof(nb));
        klogf(LOG_WARN, "NET", "sin ARP para %s", nb);
        return -1;
    }
    u8 iph[20];
    iph[0] = 0x45;                        /* v4, IHL 5 */
    iph[1] = 0;
    iph[2] = (u8)((20 + len) >> 8); iph[3] = (u8)(20 + len);
    iph[4] = (u8)(pit_ticks >> 8); iph[5] = (u8)pit_ticks;
    iph[6] = 0x40; iph[7] = 0;            /* DF */
    iph[8] = 64;
    iph[9] = proto;
    iph[10] = iph[11] = 0;
    memcpy(iph + 12, &my_ip, 4);
    memcpy(iph + 16, &dst, 4);
    u16 cs = ip_csum(iph);
    iph[10] = (u8)(cs >> 8); iph[11] = (u8)cs;
    /* eth + ip + payload en pkt_out reutilizado */
    memcpy(pkt_out, mac, 6);
    memcpy(pkt_out + 6, my_mac, 6);
    pkt_out[12] = 0x08; pkt_out[13] = 0x00;
    memcpy(pkt_out + 14, iph, 20);
    memcpy(pkt_out + 34, payload, len);
    int r = e1000_send(pkt_out, 14 + 20 + len);
    if (r == 0) tx_count++;
    return r;
}

/* ---------------- ICMP ---------------- */
int net_ping(u32 ip, u32 *rtt_ms) {
    if (!e1000_present()) return 0;
    u8 pkt[8 + 32];
    memset(pkt, 0, sizeof(pkt));
    ping_id = (u16)pit_ticks;
    ping_seq++;
    ping_pending = 1;
    ping_ok = 0;
    /* ICMP echo: type(0) code(1) checksum(2-3) id(4-5) seq(6-7) datos(8+) */
    pkt[0] = 8; pkt[1] = 0;               /* echo request */
    pkt[4] = (u8)(ping_id >> 8); pkt[5] = (u8)ping_id;
    pkt[6] = (u8)(ping_seq >> 8); pkt[7] = (u8)ping_seq;
    for (int i = 0; i < 32; i++) pkt[8 + i] = (u8)('F' + (i & 15));
    u16 cs = csum(pkt, sizeof(pkt), 0);
    pkt[2] = (u8)(cs >> 8); pkt[3] = (u8)cs;

    u64 deadline = pit_ticks + 250;       /* 2.5 s */
    ping_sent_tick = pit_ticks;
    if (ip_send(IP_ICMP, ip, pkt, sizeof(pkt)) != 0) { ping_pending = 0; return 0; }
    while (pit_ticks < deadline) {
        int n = e1000_poll(frame_in, sizeof(frame_in));
        if (n > 0) { rx_count++; process_frame(frame_in, (u32)n); }
        else hlt_cpu();
        if (ping_ok) {
            if (rtt_ms) *rtt_ms = (u32)((pit_ticks - ping_sent_tick) * 10);
            ping_pending = 0;
            return 1;
        }
    }
    ping_pending = 0;
    return 0;
}

/* ---------------- UDP ---------------- */
static int udp_send(u16 sport, u16 dport, u32 dst, const u8 *data, u32 len) {
    u8 udp[8 + 512];
    if (8 + len > sizeof(udp)) return -1;
    udp[0] = (u8)(sport >> 8); udp[1] = (u8)sport;
    udp[2] = (u8)(dport >> 8); udp[3] = (u8)dport;
    udp[4] = (u8)((8 + len) >> 8); udp[5] = (u8)(8 + len);
    udp[6] = udp[7] = 0;
    memcpy(udp + 8, data, len);
    return ip_send(IP_UDP, dst, udp, 8 + len);
}

/* ---------------- DNS ---------------- */
static void dns_build_query(const char *name, u8 *q, u32 *qlen) {
    dns_id = (u16)(pit_ticks ^ (pit_ticks >> 8) ^ 0xF17E);
    u32 off = 0;
    q[off++] = (u8)(dns_id >> 8); q[off++] = (u8)dns_id;
    q[off++] = 0x01; q[off++] = 0x00;     /* recursión */
    q[off++] = 0; q[off++] = 1;           /* 1 pregunta */
    q[off++] = 0; q[off++] = 0;
    q[off++] = 0; q[off++] = 0;
    q[off++] = 0; q[off++] = 0;
    for (const char *p = name; *p; ) {
        const char *dot = p;
        while (*dot && *dot != '.') dot++;
        u8 lab = (u8)(dot - p);
        q[off++] = lab;
        memcpy(q + off, p, lab);
        off += lab;
        p = (*dot) ? dot + 1 : dot;
    }
    q[off++] = 0;
    q[off++] = 0; q[off++] = 1;           /* tipo A */
    q[off++] = 0; q[off++] = 1;           /* clase IN */
    *qlen = off;
}

/* salta un nombre DNS (con punteros de compresión 0xC0) */
static u32 dns_skip_name(const u8 *p, u32 off, u32 max) {
    while (off < max) {
        u8 b = p[off];
        if (b == 0) return off + 1;
        if ((b & 0xC0) == 0xC0) return off + 2;
        off += (u32)b + 1;
    }
    return off;
}

u32 net_dns_resolve(const char *name) {
    if (!e1000_present() || !dns_ip) return 0;
    if (net_ip_parse(name, &dns_answer_ip)) return dns_answer_ip;  /* ya es IP */

    u8 q[280];
    u32 qlen;
    dns_build_query(name, q, &qlen);
    dns_id = (u16)((q[0] << 8) | q[1]);
    dns_ready = 0;
    dns_answer_ip = 0;
    if (udp_send(50053, 53, dns_ip, q, qlen) != 0) return 0;

    u64 deadline = pit_ticks + 300;       /* 3 s */
    while (pit_ticks < deadline) {
        int n = e1000_poll(frame_in, sizeof(frame_in));
        if (n > 0) { rx_count++; process_frame(frame_in, (u32)n); }
        else hlt_cpu();
        if (dns_ready && dns_answer_ip) return dns_answer_ip;
        if (dns_ready) return 0;          /* respuesta sin A */
    }
    klogf(LOG_WARN, "DNS", "sin respuesta para '%s'", name);
    return 0;
}

/* ---------------- TCP ---------------- */
static int tcp_send_pkt(u8 flags, const u8 *payload, u32 len) {
    u8 seg[20 + 1400];                    /* v1.4: MSS completo (antes 512) */
    if (20 + len > sizeof(seg)) return -1;
    seg[0] = (u8)(tcb.lport >> 8); seg[1] = (u8)tcb.lport;
    seg[2] = (u8)(tcb.rport >> 8); seg[3] = (u8)tcb.rport;
    u32 s = hb32(tcb.seq);
    u32 a = hb32(tcb.ack);
    memcpy(seg + 4, &s, 4);
    memcpy(seg + 8, &a, 4);
    seg[12] = 0x50;                       /* data offset 5 */
    seg[13] = flags;
    seg[14] = 0x40; seg[15] = 0x00;       /* ventana 16384 */
    seg[16] = seg[17] = 0;                /* csum después */
    seg[18] = seg[19] = 0;
    if (len) memcpy(seg + 20, payload, len);

    /* checksum con pseudo-cabecera */
    u32 sum = 0;
    u8 ph[12];
    memcpy(ph, &my_ip, 4);
    memcpy(ph + 4, &tcb.rip, 4);
    ph[8] = 0; ph[9] = IP_TCP;
    ph[10] = (u8)((20 + len) >> 8); ph[11] = (u8)(20 + len);
    for (int i = 0; i < 12; i += 2) sum += (u32)ph[i] << 8 | ph[i + 1];
    u16 cs = csum(seg, 20 + len, sum);
    seg[16] = (u8)(cs >> 8); seg[17] = (u8)cs;

    int r = ip_send(IP_TCP, tcb.rip, seg, 20 + len);
    if (r == 0 && (flags & (TCP_FIN | TCP_SYN | TCP_PSH))) tcb.seq += len + ((flags & (TCP_FIN | TCP_SYN)) ? 1 : 0);
    return r;
}

static void tcp_push(const u8 *data, u32 len) {
    for (u32 i = 0; i < len; i++) {
        u32 h = tcp_head;
        if ((h + 1) % RXRING == tcp_tail) break;   /* lleno */
        tcp_rx[h] = data[i];
        tcp_head = (h + 1) % RXRING;
    }
}

static void tcp_process(const u8 *seg, u32 seglen, u32 src) {
    if (tcb.state == TCP_NONE || tcb.state == TCP_CLOSED) return;
    if (seglen < 20) return;
    u16 sport = (u16)((seg[0] << 8) | seg[1]);
    u16 dport = (u16)((seg[2] << 8) | seg[3]);
    if (tcb.state == TCP_LISTEN) {
        /* servidor: aceptar cualquier origen para nuestro puerto local */
        if (dport != tcb.lport) return;
        u8 fl = seg[13];
        if (!(fl & TCP_SYN) || (fl & TCP_ACK)) return;   /* solo SYN puro */
        tcb.rip = src;
        tcb.rport = sport;
        u32 seq = ((u32)seg[4] << 24) | ((u32)seg[5] << 16) |
                  ((u32)seg[6] << 8) | seg[7];
        tcb.ack = seq + 1;
        tcb.seq = (u32)pit_ticks * 2654435761u + 0x5EED1u;
        tcb.state = TCP_SYN_RCVD;
        tcp_send_pkt(TCP_SYN | TCP_ACK, NULLP, 0);
        klogf(LOG_INFO, "TCP", "SYN recibido en puerto %u: sincronizando", tcb.lport);
        return;
    }
    if (dport != tcb.lport || sport != tcb.rport) return;

    u32 seq = ((u32)seg[4] << 24) | ((u32)seg[5] << 16) | ((u32)seg[6] << 8) | seg[7];
    u32 ack = ((u32)seg[8] << 24) | ((u32)seg[9] << 16) | ((u32)seg[10] << 8) | seg[11];
    u8 doff = (u8)(seg[12] >> 4);
    u8 flags = seg[13];
    u32 hlen = (u32)doff * 4;
    if (hlen > seglen) return;
    const u8 *payload = seg + hlen;
    u32 plen = seglen - hlen;

    if (flags & TCP_RST) {
        klogw("TCP", "RST recibido: conexión cerrada por el otro extremo");
        tcb.state = TCP_CLOSED;
        tcp_fin = 1;
        return;
    }

    if (tcb.state == TCP_SYN_SENT) {
        if ((flags & (TCP_SYN | TCP_ACK)) == (TCP_SYN | TCP_ACK)) {
            tcb.ack = seq + 1;
            tcb.seq = ack;                    /* consume nuestro SYN */
            tcb.state = TCP_EST;
            tcp_send_pkt(TCP_ACK, NULLP, 0);
        }
        return;
    }
    if (tcb.state == TCP_SYN_RCVD) {
        /* esperando el ACK final del three-way handshake */
        if (flags & TCP_ACK) {
            tcb.seq = ack;                    /* el cliente confirma nuestro SYN-ACK */
            if (tcb.ack == seq || !plen) {
                tcb.state = TCP_EST;
                if (plen && seq == tcb.ack) {
                    tcp_push(payload, plen);
                    tcb.ack += plen;
                }
            }
        }
        return;
    }
    if (tcb.state != TCP_EST) return;

    if (flags & TCP_ACK) {
        /* nuestra confirmación de envío: si ack == seq, todo enviado */
        if (ack == tcb.seq) { /* OK, no hay datos pendientes en este diseño */ }
    }
    if (plen) {
        if (seq == tcb.ack) {
            tcp_push(payload, plen);
            tcb.ack += plen;
            tcp_send_pkt(TCP_ACK, NULLP, 0);
        } else if ((u32)(seq + plen) <= tcb.ack) {
            tcp_send_pkt(TCP_ACK, NULLP, 0);  /* retransmisión: re-ACK */
        }
        /* segmento futuro: se descarta, el otro extremo retransmite */
    }
    if (flags & TCP_FIN) {
        tcb.ack = seq + plen + 1;
        tcp_fin = 1;
        tcp_send_pkt(TCP_ACK, NULLP, 0);
    }
}

int net_tcp_connect(u32 ip, u16 port) {
    if (!e1000_present()) return -1;
    if (tcb.state == TCP_EST) net_tcp_close();
    if (tcb.state == TCP_LISTEN || tcb.state == TCP_SYN_RCVD)
        tcb.state = TCP_NONE;             /* desmontar el servidor si estaba */
    tcb.rip = ip;
    tcb.rport = port;
    tcb.lport = (u16)(40000 + (pit_ticks % 2000));
    tcb.seq = (u32)pit_ticks * 131 + 0x51ED;
    tcb.ack = 0;
    tcp_head = tcp_tail = 0;
    tcp_fin = 0;
    tcb.state = TCP_SYN_SENT;
    if (tcp_send_pkt(TCP_SYN, NULLP, 0) != 0) { tcb.state = TCP_NONE; return -2; }

    u64 deadline = pit_ticks + 300;       /* 3 s */
    while (pit_ticks < deadline) {
        int n = e1000_poll(frame_in, sizeof(frame_in));
        if (n > 0) { rx_count++; process_frame(frame_in, (u32)n); }
        else hlt_cpu();
        if (tcb.state == TCP_EST) return 0;
        if (tcb.state == TCP_CLOSED) return -3;
        if (pit_ticks - (deadline - 300) > 0 && (pit_ticks % 100) == 0)
            tcp_send_pkt(TCP_SYN, NULLP, 0);   /* reintento cada ~1 s */
    }
    tcb.state = TCP_NONE;
    return -3;                            /* sin respuesta */
}

int net_tcp_send(const void *data, u32 len) {
    if (tcb.state != TCP_EST) return -1;
    const u8 *p = (const u8 *)data;
    u32 sent = 0;
    while (sent < len) {
        u32 chunk = len - sent;
        if (chunk > 1400) chunk = 1400;
        u32 myseq = tcb.seq;
        int ok = 0;
        for (int tries = 0; tries < 3 && !ok; tries++) {
            tcp_send_pkt(TCP_PSH | TCP_ACK, p + sent, chunk);
            u64 deadline = pit_ticks + 100;   /* 1 s por intento */
            while (pit_ticks < deadline) {
                int n = e1000_poll(frame_in, sizeof(frame_in));
                if (n > 0) { rx_count++; process_frame(frame_in, (u32)n); }
                else hlt_cpu();
                if (tcb.state != TCP_EST) return -2;
                if (tcb.seq != myseq) { ok = 1; break; }  /* reconocido */
            }
        }
        if (!ok) return -2;
        sent += chunk;
    }
    return 0;
}

int net_tcp_recv(void *buf, u32 max, u32 timeout_ticks) {
    u64 deadline = pit_ticks + timeout_ticks;
    for (;;) {
        /* datos disponibles */
        if (tcp_tail != tcp_head) {
            u32 n = 0;
            while (n < max && tcp_tail != tcp_head) {
                ((u8 *)buf)[n++] = tcp_rx[tcp_tail];
                tcp_tail = (tcp_tail + 1) % RXRING;
            }
            return (int)n;
        }
        if (tcp_fin) return 0;            /* fin limpio */
        if (tcb.state != TCP_EST) return 0;
        if (pit_ticks >= deadline) return -1;
        int n = e1000_poll(frame_in, sizeof(frame_in));
        if (n > 0) { rx_count++; process_frame(frame_in, (u32)n); }
        else hlt_cpu();
    }
}

int net_tcp_connected(void) { return tcb.state == TCP_EST; }

/* ---------------- modo servidor (v1.4) ---------------- */
int net_tcp_listen(u16 port) {
    if (!e1000_present()) return -1;
    tcp_head = tcp_tail = 0;
    tcp_fin = 0;
    tcb.lport = port;
    tcb.rport = 0;
    tcb.rip = 0;
    tcb.state = TCP_LISTEN;
    return 0;
}

int net_tcp_listening(void) {
    return tcb.state == TCP_LISTEN || tcb.state == TCP_SYN_RCVD;
}

/* espera una conexión entrante (3-way handshake completo) */
int net_tcp_accept_wait(u32 timeout_ticks) {
    if (tcb.state != TCP_LISTEN) return -2;
    u64 deadline = pit_ticks + timeout_ticks;
    for (;;) {
        int n = e1000_poll(frame_in, sizeof(frame_in));
        if (n > 0) { rx_count++; process_frame(frame_in, (u32)n); }
        else hlt_cpu();
        if (tcb.state == TCP_EST) return 0;
        if (tcb.state != TCP_SYN_RCVD && tcb.state != TCP_LISTEN) return -3;
        if (pit_ticks >= deadline) return -1;
    }
}

u16 net_tcp_local_port(void) { return tcb.lport; }

/* fuerza el cierre del socket sin FIN (al matar la tarea servidor) */
void tcb_force_reset(void) {
    tcp_head = tcp_tail = 0;
    tcp_fin = 0;
    tcb.state = TCP_CLOSED;
}

void net_tcp_close(void) {
    if (tcb.state == TCP_EST) {
        tcp_send_pkt(TCP_FIN | TCP_ACK, NULLP, 0);
        u64 deadline = pit_ticks + 30;    /* 300 ms */
        while (pit_ticks < deadline) {
            int n = e1000_poll(frame_in, sizeof(frame_in));
            if (n > 0) { rx_count++; process_frame(frame_in, (u32)n); }
            else hlt_cpu();
        }
    }
    tcb.state = TCP_CLOSED;
}

/* ---------------- despacho de tramas ---------------- */
static void process_frame(const u8 *f, u32 len) {
    if (len < 14) return;
    u16 etype = (u16)((f[12] << 8) | f[13]);
    const u8 *payload = f + 14;
    u32 plen = len - 14;

    if (etype == ET_ARP) {
        if (plen < 28) return;
        u16 op = (u16)((payload[6] << 8) | payload[7]);
        u32 tpa;
        memcpy(&tpa, payload + 24, 4);
        if (op == 1 && tpa == my_ip) {
            arp_reply(payload);
        } else if (op == 2) {
            u32 spa;
            memcpy(&spa, payload + 14, 4);
            arp_cache_add(spa, payload + 8);
        }
        return;
    }
    if (etype != ET_IP || plen < 20) return;

    u8 ihl = (u8)((payload[0] & 0x0F) * 4);
    u16 tot = (u16)((payload[2] << 8) | payload[3]);
    u8 proto = payload[9];
    u32 src, dst;
    memcpy(&src, payload + 12, 4);
    memcpy(&dst, payload + 16, 4);
    if (dst != my_ip) return;             /* no es para nosotros */
    if (tot > plen) tot = (u16)plen;
    if (tot < ihl) return;
    const u8 *l4 = payload + ihl;
    u32 l4len = tot - ihl;

    if (proto == IP_ICMP && l4len >= 8) {
        u8 type = l4[0];
        if (type == 0 && ping_pending) {  /* echo reply */
            u16 id = (u16)((l4[4] << 8) | l4[5]);
            u16 sq = (u16)((l4[6] << 8) | l4[7]);
            if (id == ping_id && sq == ping_seq) ping_ok = 1;
        } else if (type == 8) {           /* echo request -> responder */
            u8 rep[8 + 32];
            u32 dl = l4len > sizeof(rep) ? sizeof(rep) : l4len;
            memcpy(rep, l4, dl);
            rep[0] = 0;
            rep[2] = rep[3] = 0;          /* recalcular checksum */
            u16 cs = csum(rep, dl, 0);
            rep[2] = (u8)(cs >> 8); rep[3] = (u8)cs;
            ip_send(IP_ICMP, src, rep, dl);
        }
        return;
    }
    if (proto == IP_UDP && l4len >= 8) {
        u16 dport = (u16)((l4[2] << 8) | l4[3]);
        u16 ulen = (u16)((l4[4] << 8) | l4[5]);
        if (dport == 50053) {             /* respuesta DNS para nosotros */
            const u8 *d = l4 + 8;
            u32 dlen = (ulen >= 8) ? (u32)ulen - 8 : 0;
            if (dlen < 12) return;
            u16 rid = (u16)((d[0] << 8) | d[1]);
            u16 rcode = d[3] & 0x0F;
            u16 ancount = (u16)((d[6] << 8) | d[7]);
            if (rid != dns_id || rcode != 0) { dns_ready = 1; return; }
            u32 off = 12;
            off = dns_skip_name(d, off, dlen);   /* pregunta */
            off += 4;
            for (int i = 0; i < ancount && off + 12 <= dlen; i++) {
                off = dns_skip_name(d, off, dlen);
                if (off + 10 > dlen) break;
                u16 rtype = (u16)((d[off] << 8) | d[off + 1]);
                u16 rdlen = (u16)((d[off + 8] << 8) | d[off + 9]);
                off += 10;
                if (rtype == 1 && rdlen == 4 && off + 4 <= dlen) {
                    memcpy(&dns_answer_ip, d + off, 4);
                    break;
                }
                off += rdlen;
            }
            dns_ready = 1;
        }
        return;
    }
    if (proto == IP_TCP) {
        tcp_process(l4, l4len, src);
        return;
    }
}

/* ---------------- HTTP ---------------- */
#define HTTP_MAX 49152
static char http_host[64];

static int http_parse_url(const char *url, char *host, u32 hosts, u16 *port, char *path, u32 paths) {
    const char *p = url;
    if (!strncmp(p, "http://", 7)) p += 7;
    u32 h = 0;
    *port = 80;
    while (*p && *p != '/' && *p != ':') {
        if (h + 1 >= hosts) return 0;
        host[h++] = *p++;
    }
    host[h] = 0;
    if (*p == ':') {
        p++;
        u32 pv = 0;
        while (*p >= '0' && *p <= '9') { pv = pv * 10 + (u32)(*p++ - '0'); }
        if (!pv || pv > 65535) return 0;
        *port = (u16)pv;
    }
    if (!h) return 0;
    if (*p == 0) { strcpy(path, "/"); return 1; }
    if (*p != '/') return 0;
    strncpy(path, p, paths - 1);
    path[paths - 1] = 0;
    return 1;
}


static const char *http_header(const char *hdrs, const char *name) {
    u32 nl = strlen(name);
    while (hdrs && *hdrs) {
        const char *eol = strstr(hdrs, "\r\n");
        if (!eol) eol = hdrs + strlen(hdrs);
        if ((u32)(eol - hdrs) > nl && !strncmp(hdrs, name, nl) && hdrs[nl] == ':') {
            const char *v = hdrs + nl + 1;
            while (*v == ' ') v++;
            return v;
        }
        if (!*eol) break;
        hdrs = eol + 2;
    }
    return NULLP;
}

static int http_fetch_once(u32 ip, u16 port, const char *host, const char *path,
                           char **body_out, u32 *body_len) {
    int cr = net_tcp_connect(ip, port);
    klogf(LOG_INFO, "TCP", "connect %s:%u -> %s", host, port, cr == 0 ? "OK" : "FALLO");
    if (cr != 0) return -3;
    char req[512];
    int rl = ksnprintf(req, sizeof(req),
                       "GET %s HTTP/1.1\r\nHost: %s\r\n"
                       "User-Agent: FenixNav/1.2 (FenixOS)\r\n"
                       "Accept: text/html,text/plain,*/*\r\n"
                       "Connection: close\r\n\r\n", path, host);
    if (rl <= 0 || net_tcp_send(req, (u32)rl) != 0) { net_tcp_close(); return -3; }

    char *resp = (char *)kmalloc(HTTP_MAX);
    if (!resp) { net_tcp_close(); return -5; }
    u32 got = 0;
    u64 deadline = pit_ticks + 800;       /* 8 s */
    while (got < HTTP_MAX - 1) {
        char tmp[2048];
        int n = net_tcp_recv(tmp, sizeof(tmp), 100);
        if (n > 0) {
            if (got + (u32)n >= HTTP_MAX - 1) n = (int)(HTTP_MAX - 1 - got);
            memcpy(resp + got, tmp, (u32)n);
            got += (u32)n;
            continue;
        }
        if (n == 0) break;                /* FIN: fin de la respuesta */
        if (pit_ticks >= deadline) break; /* tiempo agotado */
    }
    net_tcp_close();
    klogf(LOG_INFO, "HTTP", "respuesta recibida: %lu bytes", got);
    resp[got] = 0;
    if (!got) { kfree(resp); return -4; }

    /* partir cabeceras/cuerpo */
    char *body = strstr(resp, "\r\n\r\n");
    if (!body) { kfree(resp); return -4; }
    *body = 0;
    body += 4;
    u32 body_raw = got - (u32)(body - resp);

    if (strncmp(resp, "HTTP/", 5) != 0) { kfree(resp); return -4; }
    int status = 0;
    { const char *sp = resp + 9; while (*sp >= '0' && *sp <= '9') status = status * 10 + (*sp++ - '0'); }

    const char *cl = http_header(resp, "Content-Length");
    const char *te = http_header(resp, "Transfer-Encoding");
    u32 content_len = 0;
    int chunked = 0;
    if (cl) {
        for (const char *p = cl; *p >= '0' && *p <= '9'; p++)
            content_len = content_len * 10 + (u32)(*p - '0');
    }
    if (te && strstr(te, "chunked")) chunked = 1;

    if (chunked) {
        /* decodificar chunks in situ */
        char *out = resp;
        const char *p = body;
        const char *end = body + body_raw;
        while (p < end) {
            u32 size = 0;
            while (p < end && *p != '\r' && *p != '\n' && *p != ';')
                size = size * 16 + ((*p <= '9') ? (u32)(*p - '0') : (u32)((*p | 32) - 'a' + 10)), p++;
            while (p < end && *p++ != '\n') { }
            if (size == 0) break;
            if (p + size > end) size = (u32)(end - p);
            memmove(out, p, size);
            out += size;
            p += size;
            while (p < end && *p++ != '\n') { }
        }
        *body_len = (u32)(out - resp);
        memmove(body, resp, *body_len);   /* mover al hueco del cuerpo */
        *body_out = body;
        return status;
    }

    if (content_len && content_len <= body_raw) *body_len = content_len;
    else *body_len = body_raw;
    memmove(resp, body, *body_len);
    *body_out = resp;
    return status;
}

int net_http_get(const char *url, char *host_out, u32 hostsz,
                 char **body_out, u32 *body_len) {
    if (!e1000_present()) return -1;
    for (int hop = 0; hop < 2; hop++) {
        char host[64], path[256];
        u16 port = 80;
        if (!http_parse_url(url, host, sizeof(host), &port, path, sizeof(path)))
            return -4;
        strncpy(http_host, host, sizeof(http_host) - 1);
        http_host[sizeof(http_host) - 1] = 0;
        if (host_out) {
            strncpy(host_out, host, hostsz - 1);
            host_out[hostsz - 1] = 0;
        }
        u32 ip = net_dns_resolve(host);
        if (!ip) return -2;
        int status = http_fetch_once(ip, port, host, path, body_out, body_len);
        if (status == 301 || status == 302 || status == 307) {
            /* seguir la redirección: releer las cabeceras guardadas */
            klogf(LOG_INFO, "HTTP", "redirección %d", status);
            return status;                /* simplificación v1.2: no sigue */
        }
        return status;
    }
    return -4;
}

/* ---------------- HTML -> texto ---------------- */
int strncasecmp_fenix(const char *a, const char *b, u32 n) {
    for (u32 i = 0; i < n; i++) {
        char ca = a[i], cb = b[i];
        if (ca >= 'A' && ca <= 'Z') ca = (char)(ca + 32);
        if (cb >= 'A' && cb <= 'Z') cb = (char)(cb + 32);
        if (ca != cb) return ca - cb;
        if (!ca) return 0;
    }
    return 0;
}

static int html_is_block(const char *name) {
    static const char *blocks[] = {
        "p", "div", "br", "li", "ul", "ol", "table", "tr", "td", "th",
        "h1", "h2", "h3", "h4", "h5", "h6", "header", "footer", "section",
        "article", "nav", "blockquote", "pre", "form", "hr",
    };
    for (u32 i = 0; i < sizeof(blocks) / sizeof(blocks[0]); i++)
        if (!strncasecmp_fenix(name, blocks[i], strlen(blocks[i]))) return 1;
    return 0;
}

int net_html_to_text(const char *html, u32 n, char *out, u32 outmax, char *title_out) {
    u32 o = 0;
    int in_tag = 0, in_script = 0, in_style = 0, in_title = 0;
    int block_after = 0, last_space = 1, name_done = 0;
    char tagname[16];
    u32 tl = 0;
    char *t = title_out;
    if (t) t[0] = 0;

    const char *p = html;
    const char *end = html + n;
    while (p < end) {
        char c = *p;
        if (in_tag) {
            if (c == '>') {
                in_tag = 0;
                if (!name_done) tagname[tl] = 0;
                if (!in_script && !in_style && html_is_block(tagname)) block_after = 1;
                p++;
                continue;
            }
            if ((c == ' ' || c == '\t') && !name_done && tl > 0) {
                tagname[tl] = 0;              /* fin del nombre del tag */
                name_done = 1;
            } else if (!name_done && tl + 1 < sizeof(tagname)) {
                tagname[tl++] = (char)((c >= 'A' && c <= 'Z') ? c + 32 : c);
            }
            p++;
            continue;
        }
        if (c == '<') {
            in_tag = 1;
            tl = 0;
            name_done = 0;
            tagname[0] = 0;
            if (end - p > 7 && strncasecmp_fenix(p + 1, "script", 6) == 0 &&
                (p[7] == '>' || p[7] == ' ')) in_script = 1;
            if (end - p > 8 && strncasecmp_fenix(p + 1, "/script", 7) == 0) in_script = 0;
            if (end - p > 6 && strncasecmp_fenix(p + 1, "style", 5) == 0 &&
                (p[6] == '>' || p[6] == ' ')) in_style = 1;
            if (end - p > 7 && strncasecmp_fenix(p + 1, "/style", 6) == 0) in_style = 0;
            if (end - p > 6 && strncasecmp_fenix(p + 1, "title", 5) == 0 &&
                (p[6] == '>' || p[6] == ' ')) in_title = 1;
            if (end - p > 7 && strncasecmp_fenix(p + 1, "/title", 6) == 0) {
                in_title = 0;
                if (t) { *t = 0; t = NULLP; }
            }
            p++;
            continue;
        }
        if (in_script || in_style) { p++; continue; }
        if (in_title && t) {
            if (t - title_out < 60 && c >= 32 && c < 127) *t++ = c;
            p++;
            continue;
        }
        if (c == '&') {
            static const struct { const char *ent; char ch; } ents[] = {
                { "amp;", '&' }, { "lt;", '<' }, { "gt;", '>' },
                { "quot;", '"' }, { "apos;", '\'' }, { "nbsp;", ' ' },
                { "#39;", '\'' }, { "iexcl;", 'i' }, { "aacute;", 'a' },
                { "eacute;", 'e' }, { "iacute;", 'i' }, { "oacute;", 'o' },
                { "uacute;", 'u' }, { "ntilde;", 'n' }, { "copy;", 'c' },
                { "laquo;", '<' }, { "raquo;", '>' }, { "mdash;", '-' },
                { "ndash;", '-' }, { "hellip;", '.' },
            };
            int done = 0;
            for (u32 i = 0; i < sizeof(ents) / sizeof(ents[0]); i++) {
                u32 el = strlen(ents[i].ent);
                if (p + el < end && !memcmp(p + 1, ents[i].ent, el)) {
                    if (o + 1 < outmax) out[o++] = ents[i].ch;
                    p += el + 1;
                    last_space = 0;
                    done = 1;
                    break;
                }
            }
            if (done) continue;
        }
        if (block_after) {
            if (o && out[o - 1] != '\n' && o + 1 < outmax) out[o++] = '\n';
            block_after = 0;
            last_space = 1;
        }
        if (c == '\r') { p++; continue; }
        if (c == '\n' || c == '\t') c = ' ';
        if (c == ' ') {
            if (!last_space && o + 1 < outmax) out[o++] = ' ';
            last_space = 1;
            p++;
            continue;
        }
        if (c >= 32 && c < 127 && o + 1 < outmax) {
            out[o++] = c;
            last_space = 0;
        }
        p++;
    }
    if (t) *t = 0;
    /* colapsar 3+ saltos a uno en blanco */
    u32 w = 0;
    int nls = 0;
    for (u32 i = 0; i < o; i++) {
        if (out[i] == '\n') {
            nls++;
            if (nls > 2) continue;
        } else nls = 0;
        out[w++] = out[i];
    }
    out[w] = 0;
    return (int)w;
}
