/* FenixOS — sysinfo.c: apartado de Información del Sistema (v1.3)
 *
 * Reúne todo lo que el hardware puede contarle al kernel y lo presenta
 * en una ventana del visor, con la estética de 'neofetch':
 *   - CPU: fabricante, marca completa, familia/modelo/paso y rasgos
 *   - RAM: total utilizable (e820) y uso actual del PMM
 *   - GPU: cadenas OEM del VBE (fabricante/producto), resolución y VRAM
 *   - Discos: backend (AHCI/ATA-PIO), modelos, capacidad, partición
 *   - Firmware/arranque: modo (CD/USB/disco), menú multiboot, modo seguro
 *   - PCI: todos los dispositivos detectados con clase
 *   - USB: controladoras detectadas
 *   - Red: NIC, MAC, IP configurada
 *   - Audio: controladores PCI multimedia + altavoz PC
 * El informe es honesto: lo no soportado se indica como tal. */
#include "fenixos.h"

static char cpu_vendor_buf[16];
static char cpu_brand_buf[52];
static int  cpu_probed = 0;
static u32  cpu_family_model = 0;
static u32  cpu_features_edx = 0;
static u32  cpu_features_ecx = 0;

static void cpu_probe(void) {
    if (cpu_probed) return;
    u32 a, b, c, d;
    __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0));
    cpu_vendor_buf[0] = (char)(b & 0xFF);
    cpu_vendor_buf[1] = (char)((b >> 8) & 0xFF);
    cpu_vendor_buf[2] = (char)((b >> 16) & 0xFF);
    cpu_vendor_buf[3] = (char)((b >> 24) & 0xFF);
    cpu_vendor_buf[4] = (char)(d & 0xFF);
    cpu_vendor_buf[5] = (char)((d >> 8) & 0xFF);
    cpu_vendor_buf[6] = (char)((d >> 16) & 0xFF);
    cpu_vendor_buf[7] = (char)((d >> 24) & 0xFF);
    cpu_vendor_buf[8] = (char)(c & 0xFF);
    cpu_vendor_buf[9] = (char)((c >> 8) & 0xFF);
    cpu_vendor_buf[10] = (char)((c >> 16) & 0xFF);
    cpu_vendor_buf[11] = (char)((c >> 24) & 0xFF);
    cpu_vendor_buf[12] = 0;

    __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(1));
    cpu_family_model = a;
    cpu_features_edx = d;
    cpu_features_ecx = c;

    __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0x80000000));
    if (a >= 0x80000004) {
        u32 *out = (u32 *)cpu_brand_buf;
        __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0x80000002));
        out[0] = a; out[1] = b; out[2] = c; out[3] = d;
        __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0x80000003));
        out[4] = a; out[5] = b; out[6] = c; out[7] = d;
        __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0x80000004));
        out[8] = a; out[9] = b; out[10] = c; out[11] = d;
        cpu_brand_buf[48] = 0;
        for (int i = 0; i < 48 && cpu_brand_buf[i]; i++)
            if (cpu_brand_buf[i] == '\n' || cpu_brand_buf[i] == '\r')
                cpu_brand_buf[i] = ' ';
        /* recortar espacios iniciales */
        char *p = cpu_brand_buf;
        while (*p == ' ') p++;
        if (p != cpu_brand_buf) {
            int k = 0;
            while (p[k]) { cpu_brand_buf[k] = p[k]; k++; }
            cpu_brand_buf[k] = 0;
        }
    } else {
        ksnprintf(cpu_brand_buf, sizeof(cpu_brand_buf), "%s (sin cadena de marca)",
                  cpu_vendor_buf);
    }
    cpu_probed = 1;
}

const char *cpu_vendor(void) { cpu_probe(); return cpu_vendor_buf; }
const char *cpu_brand(void)  { cpu_probe(); return cpu_brand_buf; }

static void line_append(char *buf, u32 cap, u32 *len, const char *text) {
    for (const char *p = text; *p && *len + 1 < cap; p++) buf[(*len)++] = *p;
    if (*len + 1 < cap) buf[(*len)++] = '\n';
    buf[*len] = 0;
}

static void line_fmt(char *buf, u32 cap, u32 *len, const char *fmt, ...) {
    char tmp[180];
    va_list ap;
    va_start(ap, fmt);
    kvsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    line_append(buf, cap, len, tmp);
}

static const char *pci_class_full(u8 cls, u8 sub) {
    static char nbuf[40];
    const char *c = "otro";
    switch (cls) {
    case 0x00: c = "otro"; break;
    case 0x01:
        switch (sub) {
        case 0x01: c = "almacenamiento (IDE)"; break;
        case 0x06: c = "almacenamiento (AHCI/SATA)"; break;
        case 0x07: c = "almacenamiento (SAS)"; break;
        case 0x08: c = "almacenamiento (NVMe)"; break;
        default:   c = "almacenamiento"; break;
        }
        break;
    case 0x02: c = "red"; break;
    case 0x03: c = "video"; break;
    case 0x04:
        switch (sub) {
        case 0x00: c = "multimedia (video)"; break;
        case 0x01: c = "multimedia (audio)"; break;
        case 0x03: c = "multimedia (HDA audio)"; break;
        default:   c = "multimedia"; break;
        }
        break;
    case 0x05: c = "memoria"; break;
    case 0x06: c = "puente"; break;
    case 0x0C:
        switch (sub) {
        case 0x00: c = "FireWire"; break;
        case 0x03: c = "USB"; break;
        default:   c = "serial bus"; break;
        }
        break;
    default: c = "clase ?"; break;
    }
    ksnprintf(nbuf, sizeof(nbuf), "%s", c);
    return nbuf;
}

int sysinfo_build(char *buf, u32 cap) {
    cpu_probe();
    u32 len = 0;

    line_append(buf, cap, &len,
                "FENIXOS 1.3 'TITAN' - INFORMACION DEL SISTEMA");
    line_append(buf, cap, &len,
                "==========================================================");

    /* ---- procesador ---- */
    u32 fam = (cpu_family_model >> 8) & 0xF;
    u32 model = (cpu_family_model >> 4) & 0xF;
    if (fam == 0xF) fam += ((cpu_family_model >> 20) & 0xFF) << 4;
    if (fam == 0x6 || fam == 0xF) model += ((cpu_family_model >> 16) & 0xF) << 4;
    line_fmt(buf, cap, &len, "CPU fabricante : %s", cpu_vendor_buf);
    line_fmt(buf, cap, &len, "CPU modelo     : %s", cpu_brand_buf);
    line_fmt(buf, cap, &len, "CPU familia    : %u, modelo %u, paso %u",
             fam, model, cpu_family_model & 0xF);
    {
        char feat[120];
        u32 fl = 0;
        if (cpu_features_edx & (1 << 25)) fl += ksnprintf(feat + fl, sizeof(feat) - fl, "SSE ");
        if (cpu_features_edx & (1 << 26)) fl += ksnprintf(feat + fl, sizeof(feat) - fl, "SSE2 ");
        if (cpu_features_ecx & (1 << 0))  fl += ksnprintf(feat + fl, sizeof(feat) - fl, "SSE3 ");
        if (cpu_features_ecx & (1 << 19)) fl += ksnprintf(feat + fl, sizeof(feat) - fl, "SSE4.1 ");
        if (cpu_features_ecx & (1 << 20)) fl += ksnprintf(feat + fl, sizeof(feat) - fl, "SSE4.2 ");
        if (cpu_features_ecx & (1 << 28)) fl += ksnprintf(feat + fl, sizeof(feat) - fl, "AVX ");
        if (cpu_features_edx & (1 << 23)) fl += ksnprintf(feat + fl, sizeof(feat) - fl, "MMX ");
        if (cpu_features_edx & (1 << 24)) fl += ksnprintf(feat + fl, sizeof(feat) - fl, "FXSR ");
        line_fmt(buf, cap, &len, "CPU rasgos     : %s", fl ? feat : "(basicos)");
    }

    /* ---- memoria ---- */
    u64 mb_total = pmm_total_pages * PAGE_SIZE / (1024u * 1024u);
    u64 mb_used  = pmm_used_pages * PAGE_SIZE / (1024u * 1024u);
    line_fmt(buf, cap, &len, "RAM utilizable : %lu MB (en uso: %lu MB, PMM e820)",
             mb_total, mb_used);
    line_fmt(buf, cap, &len, "RAM kernel/heap: kernel %lu KB, heap %lu KB",
             (kernel_end_addr - kernel_start_addr) / 1024, heap_size / 1024);

    /* ---- gráficos ---- */
    {
        extern u32 fenix_vbe_mem64k;
        extern char fenix_gpu_vendor[28];
        extern char fenix_gpu_product[28];
        line_fmt(buf, cap, &len, "GPU (VBE)      : %s %s",
                 fenix_gpu_vendor[0] ? fenix_gpu_vendor : "(sin cadena OEM)",
                 fenix_gpu_product[0] ? fenix_gpu_product : "");
        line_fmt(buf, cap, &len, "Modo grafico   : %ux%u@%u bpp, framebuffer 0x%X",
                 fb.width, fb.height, fb.bpp, fb.paddr);
        if (fenix_vbe_mem64k)
            line_fmt(buf, cap, &len, "VRAM (VBE)     : %lu MB",
                     (u64)fenix_vbe_mem64k * 64 / 1024);
    }

    /* ---- discos ---- */
    if (blk_present()) {
        line_fmt(buf, cap, &len, "Disco (activo) : %s [%s], %u MB",
                 blk_model(), blk_backend(), blk_sectors() >> 11);
    } else {
        line_append(buf, cap, &len, "Disco (activo) : ningun disco ATA/AHCI");
    }
    int ad = ata_present();
    line_fmt(buf, cap, &len, "IDE primario   : %s",
             ad ? (const char *)ata_model_name() : "no detectado");
    if (ahci_present()) {
        for (int i = 0; i < ahci_port_count(); i++)
            line_fmt(buf, cap, &len, "SATA %d         : %s, %u MB",
                     i, ahci_port_model(i), ahci_port_sectors(i) >> 11);
    } else {
        line_append(buf, cap, &len, "SATA AHCI      : sin puertos activos");
    }
    if (blk_part_base())
        line_fmt(buf, cap, &len, "Instalacion    : particion 0x63 en LBA %u (%u sectores)",
                 blk_part_base(), blk_part_sectors());
    else
        line_append(buf, cap, &len, "Instalacion    : disco entero (sin particion)");

    /* ---- arranque ---- */
    {
        extern u32 fenix_boot_flags;
        const char *modo = "desconocido";
        if (fenix_boot_flags & BF_CD_BOOT) modo = "CD (blob El Torito)";
        else modo = "disco/USB (MBR propio)";
        line_fmt(buf, cap, &len, "Arranque       : %s%s", modo,
                 (fenix_boot_flags & BF_SAFE_MODE) ? " [MODO SEGURO]" : "");
        u8 opt = 0, tmo = 0;
        if (blk_read_bootconfig(&opt, &tmo) == 0)
            line_fmt(buf, cap, &len, "Menu multiboot : opcion %u por defecto, autoarranque %u s",
                     opt, tmo);
        else
            line_append(buf, cap, &len, "Menu multiboot : valores por defecto (opcion 1, 8 s)");
    }

    /* ---- PCI ---- */
    line_fmt(buf, cap, &len, "Dispositivos PCI: %d", pci_count());
    for (int i = 0; i < pci_count() && i < 12; i++) {
        PciDev *d = pci_get(i);
        line_fmt(buf, cap, &len, "  %02x:%02x.%d  %04x:%04x  %s",
                 d->bus, d->dev, d->func, d->vendor, d->device,
                 pci_class_full(d->class_code, d->subclass));
    }

    /* ---- USB ---- */
    int un = usb_scan();
    line_fmt(buf, cap, &len, "Controladoras USB: %d %s", un,
             un ? "(deteccion, sin pila USB funcional)" : "(ninguna)");

    /* ---- red ---- */
    if (net_ready()) {
        u8 mac[6];
        char ipb[16];
        net_mac(mac);
        net_ip_str(net_my_ip(), ipb, sizeof(ipb));
        line_fmt(buf, cap, &len, "Red            : e1000, MAC %x:%x:%x:%x:%x:%x, IP %s",
                 mac[0], mac[1], mac[2], mac[3], mac[4], mac[5], ipb);
    } else {
        line_append(buf, cap, &len, "Red            : no disponible (falta NIC e1000 o modo seguro)");
    }

    /* ---- audio ---- */
    {
        int audio_n = 0;
        for (int i = 0; i < pci_count(); i++) {
            PciDev *d = pci_get(i);
            if (d->class_code == 0x04) {
                line_fmt(buf, cap, &len, "Audio PCI      : %04x:%04x %s [salida aun no implementada]",
                         d->vendor, d->device, pci_class_full(0x04, d->subclass));
                audio_n++;
            }
        }
        if (!audio_n)
            line_append(buf, cap, &len, "Audio PCI      : sin controladores detectados");
        line_append(buf, cap, &len, "Audio activo   : altavoz PC estandar (PIT canal 2), ordenes sonido/musica");
    }

    /* ---- resumen de capacidades ---- */
    line_append(buf, cap, &len, "----------------------------------------------------------");
    line_append(buf, cap, &len, "Capacidades v1.3: AHCI/SATA, menú multiboot, instalador");
    line_append(buf, cap, &len, "grafico, ISO hibrido para USB (Rufus), usuarios");
    line_append(buf, cap, &len, "persistentes, informacion de hardware integrada.");
    line_append(buf, cap, &len, "(c) FenixOS - kernel propio x86_64 desde cero");
    return (int)len;
}

void sysinfo_open_window(void) {
    char *buf = (char *)kmalloc(4200);
    if (!buf) return;
    int n = sysinfo_build(buf, 4200);
    if (n <= 0) { kfree(buf); return; }
    /* quitar tildes no imprimibles y asegurar ASCII para el visor */
    for (int i = 0; i < n; i++) {
        u8 ch = (u8)buf[i];
        if (ch >= 32 && ch < 127) continue;
        buf[i] = ' ';
    }
    wm_open_nav("Informacion del sistema", buf, (u32)n);
    klog("SYS", "informacion del sistema generada");
}
