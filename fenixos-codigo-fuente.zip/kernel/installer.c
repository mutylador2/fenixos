/* FenixOS — instalador.c: instalador gráfico de FenixOS (v1.3)
 *
 * Permite instalar FenixOS en un disco desde el propio sistema en
 * ejecución (CD, USB o disco), con dos modos:
 *
 *  1) DISCO COMPLETO: FenixOS ocupa el disco (MBR + stage2 + kernel +
 *     sector de configuración del menú + config). El disco debe estar
 *     sin particiones; el instalador se niega a borrar una tabla con
 *     particiones existentes salvo que sea la propia FenixOS.
 *
 *  2) JUNTO A OTROS SISTEMAS (convivencia): crea una partición nueva
 *     de tipo 0x63 (FenixOS) en el espacio libre del disco, PRESERVA
 *     todas las particiones existentes (Windows/Linux), no cambia la
 *     marca de "activa" y escribe nuestro MBR con menú multiboot, que
 *     permite continuar arrancando los otros sistemas (chainload).
 *
 * Fuentes de los binarios: stage1/stage2 incrustados en el kernel
 * (fenix_embed_*, parcheados por el Makefile) y el kernel en ejecución
 * (kernel_start_addr..kernel_end_addr, copia byte a byte de kernel.bin).
 *
 * Diseño de escritura (disco de 512 B/sector, LBA):
 *   base+0       VBR (reservado)
 *   base+1..40   stage2 (40 sectores)
 *   base+41      sector del gestor de arranque 'FNXBOOT1'
 *   base+42..127 reservado
 *   base+128..   kernel.bin (según kernel_sectors)
 *   fin-8        configuración del sistema 'FNXCFG01'
 *   fin-9        cuentas de usuario 'FNXUSRS1' (vacío: por defecto) */
#include "fenixos.h"

/* ---------------- dispositivos disponibles ---------------- */
typedef struct {
    char name[40];
    int  backend;          /* 1 = ATA PIO, 2 = AHCI */
    int  index;            /* puerto AHCI (0 si ATA) */
    u32  sectors;
} DevInfo;

static DevInfo devs[6];
static int ndevs = 0;
static int sel_dev = -1;

/* ---------------- estados ---------------- */
enum {
    IST_SCAN = 0, IST_MODE, IST_CONFIRM, IST_RUN, IST_DONE, IST_ERR
};
static int state = IST_SCAN;
static int err_code = 0;

static char inst_lines[14][66];
static int  inst_nlines = 0;
static int  inst_mode = 0;         /* 1 = disco entero, 2 = junto a otros */
static u32  inst_part_base = 0, inst_part_sectors = 0;
static u32  mbr_copy[128];         /* MBR actual del disco destino (512 B) */
static int  have_mbr_copy = 0;

static void inst_line(const char *s) {
    if (inst_nlines < 14) {
        strncpy(inst_lines[inst_nlines], s, 64);
        inst_lines[inst_nlines][64] = 0;
        inst_nlines++;
    }
}

static void inst_clear(void) { inst_nlines = 0; }

/* ---------------- acceso a dispositivos ---------------- */
static int dev_read(int dev, u32 lba, void *buf) {
    if (dev < 0 || dev >= ndevs) return -1;
    if (devs[dev].backend == 1) return ata_read_sector(lba, buf);
    return ahci_read(devs[dev].index, lba, buf);
}
static int dev_write(int dev, u32 lba, const void *buf) {
    if (dev < 0 || dev >= ndevs) return -1;
    if (devs[dev].backend == 1) return ata_write_sector(lba, buf);
    return ahci_write(devs[dev].index, lba, buf);
}

extern u32 fenix_kernel_sectors;   /* definido en kernel.c */

/* ---------------- escaneo de discos ---------------- */
static void rescan(void) {
    ndevs = 0;
    sel_dev = -1;
    if (ata_present()) {
        DevInfo *d = &devs[ndevs++];
        memset(d, 0, sizeof(DevInfo));
        strncpy(d->name, "IDE primario (maestro)", sizeof(d->name) - 1);
        ksnprintf(d->name, sizeof(d->name), "IDE maestro: %s", ata_model_name());
        d->backend = 1;
        d->index = 0;
        d->sectors = ata_sectors_count();
    }
    for (int i = 0; i < ahci_port_count() && ndevs < 6; i++) {
        DevInfo *d = &devs[ndevs++];
        memset(d, 0, sizeof(DevInfo));
        ksnprintf(d->name, sizeof(d->name), "SATA %d: %s", i, ahci_port_model(i));
        d->backend = 2;
        d->index = i;
        d->sectors = ahci_port_sectors(i);
    }
    state = IST_SCAN;
    inst_clear();
    if (!ndevs) {
        inst_line("No se han detectado discos ATA/AHCI.");
        inst_line("Arranca FenixOS con un disco disponible");
        inst_line("(QEMU: -hda / -device ahci ; VirtualBox: SATA).");
    } else {
        inst_line("Discos detectados (toca uno para instalar):");
        for (int i = 0; i < ndevs; i++) {
            char l[66];
            ksnprintf(l, sizeof(l), "  %d) %s (%u MB)", i + 1, devs[i].name,
                      devs[i].sectors >> 11);
            inst_line(l);
        }
    }
}

/* ---------------- análisis del disco elegido ---------------- */
static void analyze_selected(void) {
    inst_clear();
    char l[66];
    ksnprintf(l, sizeof(l), "Disco: %s (%u MB)", devs[sel_dev].name,
              devs[sel_dev].sectors >> 11);
    inst_line(l);
    klogf(LOG_INFO, "INST", "analisis de dev %d (backend %d, puerto %d)",
          sel_dev, devs[sel_dev].backend, devs[sel_dev].index);
    /* leer el MBR actual */
    static u8 mbr[512];
    memset(mbr, 0, sizeof(mbr));
    have_mbr_copy = 0;
    int rr = dev_read(sel_dev, 0, mbr);
    klogf(LOG_INFO, "INST", "lectura MBR: r=%d firma=%02X%02X", rr, mbr[510], mbr[511]);
    if (rr == 0) {
        memcpy(mbr_copy, mbr, 512);
        have_mbr_copy = 1;
    }
    int parts = 0;
    int fenix_parts = 0;
    u32 max_end = 0;
    for (int i = 0; i < 4; i++) {
        const u8 *e = (const u8 *)mbr_copy + 446 + 16 * i;
        u8 type = e[4];
        if (!type) continue;
        parts++;
        u32 start = (u32)e[8] | ((u32)e[9] << 8) | ((u32)e[10] << 16) | ((u32)e[11] << 24);
        u32 size  = (u32)e[12] | ((u32)e[13] << 8) | ((u32)e[14] << 16) | ((u32)e[15] << 24);
        if (start + size > max_end) max_end = start + size;
        const char *tn = "otro";
        if (type == 0x07) tn = "Windows NTFS";
        else if (type == 0x0B || type == 0x0C || type == 0x06 || type == 0x0E) tn = "Windows FAT";
        else if (type == 0x83) tn = "Linux";
        else if (type == 0x82) tn = "Linux swap";
        else if (type == 0xEF) tn = "EFI";
        else if (type == 0xEE) tn = "GPT protector";
        else if (type == 0x63) tn = "FenixOS";
        if (type == 0x63) fenix_parts++;
        ksnprintf(l, sizeof(l), "  part %d: tipo %02X (%s), %u MB %s",
                  i + 1, type, tn, size >> 11, (e[0] & 0x80) ? "[activa]" : "");
        inst_line(l);
    }
    if (!parts) {
        inst_line("El disco no tiene particiones: se puede usar entero.");
        inst_line("Modo recomendado: disco completo.");
    } else {
        inst_line("Particiones existentes: se PRESERVAN todas.");
        inst_line("FenixOS solo se instala en su particion nueva (tipo 0x63)");
        inst_line("y su menu multiboot permitira seguir arrancando");
        inst_line("Windows o Linux sin tocarlos.");
    }
    /* espacio libre */
    u32 free_start = (max_end + 2047u) & ~2047u;      /* alineado a 1 MB */
    u32 free_secs = devs[sel_dev].sectors > free_start ? devs[sel_dev].sectors - free_start : 0;
    u32 need = 128 + fenix_kernel_sectors + 64;
    ksnprintf(l, sizeof(l), "Espacio libre: %u MB (necesarios: %u MB)",
              free_secs >> 11, need >> 11);
    inst_line(l);
    if (parts && free_secs < need && !fenix_parts) {
        inst_line("AVISO: espacio insuficiente para la particion de FenixOS.");
    }
    state = IST_MODE;
}

/* ---------------- escritura del sistema ---------------- */
static int write_system(void) {
    u32 base = inst_part_base;
    u32 area_sectors = inst_part_sectors;
    static u8 sector[512];

    /* 1) MBR con stage1 */
    if (inst_mode == 1) {
        /* disco completo: MBR nuevo, tabla vacía */
        memset(sector, 0, 512);
        memcpy(sector, fenix_embed_stage1, 512);
        memset(sector + 446, 0, 64);
        sector[510] = 0x55;
        sector[511] = 0xAA;
        if (dev_write(sel_dev, 0, sector) != 0) return -1;
    } else {
        /* convivencia: código nuevo + tabla PRESERVADA + entrada FenixOS */
        if (!have_mbr_copy) return -2;
        u8 *mbr = (u8 *)mbr_copy;
        memcpy(sector, fenix_embed_stage1, 512);       /* código 0..445 + firma */
        memcpy(sector + 446, mbr + 446, 64);           /* preservar entradas */
        /* buscar ranura: entrada 0x63 existente o libre */
        int slot = -1;
        for (int i = 0; i < 4; i++) {
            u8 *e = sector + 446 + 16 * i;
            if (e[4] == 0x63) { slot = i; break; }
            if (slot < 0 && e[4] == 0) slot = i;
        }
        if (slot < 0) return -3;
        /* calcular espacio libre */
        u32 max_end = 0;
        int fenix_parts = 0;
        for (int i = 0; i < 4; i++) {
            const u8 *e = sector + 446 + 16 * i;
            u8 t = e[4];
            if (!t) continue;
            u32 st = (u32)e[8] | ((u32)e[9] << 8) | ((u32)e[10] << 16) | ((u32)e[11] << 24);
            u32 sz = (u32)e[12] | ((u32)e[13] << 8) | ((u32)e[14] << 16) | ((u32)e[15] << 24);
            if (t == 0x63) fenix_parts++;
            if (st + sz > max_end) max_end = st + sz;
        }
        u32 free_start = (max_end + 2047u) & ~2047u;
        u32 free_secs = devs[sel_dev].sectors > free_start
                        ? devs[sel_dev].sectors - free_start : 0;
        u32 need = 128 + fenix_kernel_sectors + 64;
        if (fenix_parts == 0 && free_secs < need) return -4;
        u8 *e = sector + 446 + 16 * slot;
        if (e[4] != 0x63) {
            u32 pbase = free_start;
            u32 psize = devs[sel_dev].sectors - free_start;
            memset(e, 0, 16);
            e[4] = 0x63;                               /* tipo FenixOS */
            e[8]  = (u8)(pbase & 0xFF);
            e[9]  = (u8)((pbase >> 8) & 0xFF);
            e[10] = (u8)((pbase >> 16) & 0xFF);
            e[11] = (u8)((pbase >> 24) & 0xFF);
            e[12] = (u8)(psize & 0xFF);
            e[13] = (u8)((psize >> 8) & 0xFF);
            e[14] = (u8)((psize >> 16) & 0xFF);
            e[15] = (u8)((psize >> 24) & 0xFF);
            e[1] = 0x01; e[2] = 0x02; e[3] = 0x00;     /* CHS inicio aproximado */
            e[5] = 0xFE; e[6] = 0xFF; e[7] = 0xFF;     /* CHS fin (máximo) */
            inst_part_base = pbase;
            inst_part_sectors = psize;
        }
        base = inst_part_base;
        area_sectors = inst_part_sectors;
        sector[510] = 0x55;
        sector[511] = 0xAA;
        if (dev_write(sel_dev, 0, sector) != 0) return -1;
    }

    /* 2) stage2: base+1 .. base+40 */
    const u8 *s2 = fenix_embed_stage2;
    for (int i = 0; i < 40; i++) {
        if (dev_write(sel_dev, base + 1 + i, s2 + i * 512) != 0) return -5;
    }

    /* 3) sector del gestor de arranque (menú multiboot) */
    memset(sector, 0, 512);
    memcpy(sector, BOOTCFG_MAGIC, 8);
    sector[BOOTCFG_OFF_OPT] = BOOTCFG_DEF_OPT;
    sector[BOOTCFG_OFF_TMO] = BOOTCFG_DEF_TMO;
    if (dev_write(sel_dev, base + BOOTCFG_REL_LBA, sector) != 0) return -6;

    /* 4) kernel en ejecución (copia exacta de kernel.bin) */
    const u8 *ksrc = (const u8 *)kernel_start_addr;
    for (u32 i = 0; i < fenix_kernel_sectors; i++) {
        memset(sector, 0, 512);
        u32 off = i * 512;
        u32 chunk = 512;
        if (kernel_end_addr - kernel_start_addr < off + chunk)
            chunk = (u32)(kernel_end_addr - kernel_start_addr - off);
        if (chunk) memcpy(sector, ksrc + off, chunk);
        if (dev_write(sel_dev, base + 128 + i, sector) != 0) return -7;
    }

    /* 5) configuración por defecto al final de la zona */
    u32 end = area_sectors ? base + area_sectors : devs[sel_dev].sectors;
    memset(sector, 0, 512);
    memcpy(sector, "FNXCFG01", 8);
    memcpy(sector + 8,
           "tema=fuego\nhostname=fenixos\nautologin=admin\n"
           "ip=10.0.2.15\ngw=10.0.2.2\ndns=10.0.2.3\n", 78);
    if (dev_write(sel_dev, end - 8, sector) != 0) return -8;

    return 0;
}

static void run_install(void) {
    inst_clear();
    inst_line("Instalando FenixOS 1.4...");
    inst_line("(MBR, gestor de arranque, kernel y configuracion)");
    state = IST_RUN;
    klogf(LOG_INFO, "INST", "instalando: dev %d modo %d base %u",
          sel_dev, inst_mode, inst_part_base);
    int r = write_system();
    inst_clear();
    if (r != 0) {
        err_code = r;
        state = IST_ERR;
        inst_line("La instalacion no se completo (error interno).");
        inst_line("Ningun dato ajeno a FenixOS ha sido modificado.");
        klogf(LOG_ERROR, "INST", "instalacion fallida: codigo %d", r);
        return;
    }
    state = IST_DONE;
    klogf(LOG_INFO, "INST", "instalacion completada: dev %d, base %u, %u sectores",
          sel_dev, inst_part_base, inst_part_sectors);
    inst_line("Instalacion completada con exito.");
    inst_line("");
    if (inst_mode == 2) {
        inst_line("Se creo una particion FenixOS (tipo 0x63) sin tocar");
        inst_line("las particiones existentes de otros sistemas.");
    }
    inst_line("Al reiniciar desde ese disco, el GESTOR DE ARRANQUE");
    inst_line("mostrara el menu multiboot:");
    inst_line("  1) FenixOS        2) modo seguro");
    inst_line("  3) otro SO de este disco (Windows/Linux)");
    inst_line("  4) otro disco     5) informacion del sistema");
    inst_line("");
    inst_line("Reinicia y elige el disco instalado en el menu del BIOS");
    inst_line("(o deja este disco como primero) para probarlo.");
    klog("INST", "instalacion completada");
}

/* ---------------- API de ventana ---------------- */
void wm_open_installer(void) {
    extern Window *gui_win_open_inst(void);   /* helper en gui.c */
    Window *w = gui_win_open_inst();
    if (!w) return;
    if (state == IST_SCAN) rescan();
}

static void sel_and_analyze(int idx) {
    sel_dev = idx;
    analyze_selected();
}

/* ---------------- render ---------------- */
static void draw_btn(i32 x, i32 y, i32 bw, const char *label, u32 bg) {
    bb_fill_rect(x, y, bw, 26, bg);
    bb_rect(x, y, bw, 26, 0xFF5A6068);
    bb_text_t(x + 10, y + 5, label, 0xFFFFFFFF);
}

void installer_render(Window *w) {
    if (!w) return;
    /* cuerpo */
    bb_fill_rect(w->x + 1, w->y + 28, w->w - 2, w->h - 29, 0xFF0D1117);
    /* líneas de texto */
    for (int i = 0; i < inst_nlines; i++)
        bb_text_t(w->x + 12, w->y + 40 + i * 17, inst_lines[i], 0xFFE6EDF3);
    /* resaltar discos seleccionables en IST_SCAN */
    if (state == IST_SCAN) {
        for (int i = 0; i < ndevs && i < 4; i++) {
            i32 ry = w->y + 40 + (i + 1) * 17;
            bb_rect(w->x + 8, ry - 3, w->w - 16, 18,
                    (i == sel_dev) ? current_theme.accent : 0xFF22303A);
        }
    }
    i32 by = w->y + w->h - 40;
    switch (state) {
    case IST_SCAN:
        draw_btn(w->x + 12, by, 110, "Reexplorar", 0xFF1B2126);
        draw_btn(w->x + w->w - 12 - 90, by, 90, "Cerrar", 0xFF5A2521);
        break;
    case IST_MODE:
        draw_btn(w->x + 12, by, 130, "Disco completo", 0xFF1B2126);
        draw_btn(w->x + 12 + 140, by, 170, "Junto a otros OS", current_theme.accent);
        draw_btn(w->x + w->w - 12 - 90, by, 90, "Volver", 0xFF1B2126);
        break;
    case IST_CONFIRM:
        draw_btn(w->x + 12, by, 200, "Confirmar instalacion", current_theme.accent);
        draw_btn(w->x + w->w - 12 - 90, by, 90, "Volver", 0xFF1B2126);
        break;
    case IST_DONE:
    case IST_ERR:
        draw_btn(w->x + 12, by, 90, "Cerrar", 0xFF1B2126);
        break;
    default:
        break;
    }
}

/* ---------------- clicks ---------------- */
int installer_click(Window *w, i32 mx, i32 my) {
    if (!w) return 0;
    i32 by = w->y + w->h - 40;
    if (my < by || my > by + 26) {
        /* clicks en filas de discos */
        if (state == IST_SCAN) {
            for (int i = 0; i < ndevs && i < 4; i++) {
                i32 ry = w->y + 40 + (i + 1) * 17;
                if (my >= ry - 3 && my < ry + 15 && mx > w->x && mx < w->x + w->w) {
                    sel_and_analyze(i);
                    return 1;
                }
            }
        }
        return 0;
    }
    i32 x = mx;
    switch (state) {
    case IST_SCAN:
        if (x >= w->x + 12 && x < w->x + 122) { rescan(); return 1; }
        if (x >= w->x + w->w - 102) { w->visible = 0; return 1; }
        break;
    case IST_MODE:
        if (x >= w->x + 12 && x < w->x + 142) {
            /* disco completo: solo si no hay particiones ajenas */
            int foreign = 0;
            if (have_mbr_copy) {
                const u8 *mbr = (const u8 *)mbr_copy;
                for (int i = 0; i < 4; i++) {
                    u8 t = mbr[446 + 16 * i + 4];
                    if (t && t != 0x63) foreign = 1;
                }
            }
            if (foreign) {
                inst_clear();
                inst_line("Denegado: el disco tiene particiones de otros");
                inst_line("sistemas. Usa 'Junto a otros OS' para convivir");
                inst_line("con ellas sin sobrescribirlas.");
                return 1;
            }
            inst_mode = 1;
            inst_part_base = 0;
            inst_part_sectors = 0;
            state = IST_CONFIRM;
            inst_clear();
            inst_line("Modo: DISCO COMPLETO (FenixOS unico sistema).");
            inst_line("Se escribiran: MBR, gestor de arranque, kernel y");
            inst_line("configuracion por defecto en el disco elegido.");
            return 1;
        }
        if (x >= w->x + 152 && x < w->x + 322) {
            inst_mode = 2;
            state = IST_CONFIRM;
            inst_clear();
            inst_line("Modo: JUNTO A OTROS SISTEMAS (convivencia).");
            inst_line("Nueva particion FenixOS (0x63) en espacio libre;");
            inst_line("particiones existentes de Windows/Linux intactas;");
            inst_line("el menu multiboot permitira arrancarlos despues.");
            return 1;
        }
        if (x >= w->x + w->w - 102) { rescan(); return 1; }
        break;
    case IST_CONFIRM:
        if (x >= w->x + 12 && x < w->x + 212) { run_install(); return 1; }
        if (x >= w->x + w->w - 102) { sel_and_analyze(sel_dev); return 1; }
        break;
    case IST_DONE:
    case IST_ERR:
        if (x >= w->x + 12 && x < w->x + 102) { w->visible = 0; return 1; }
        break;
    default:
        break;
    }
    return 0;
}
