/* FenixOS — kernel.c: kmain, inicialización por capas del sistema.
 * HAL (fb, serial) -> Kernel (GDT, IDT, PIC, PIT, PMM, heap, tareas)
 * -> Executive (GUI, reloj) -> Subsistemas (FenixShell). */
#include "fenixos.h"

/* datos de arranque compartidos con sysinfo (v1.3) */
u32 fenix_boot_flags = 0;
u32 fenix_vbe_mem64k = 0;
u32 fenix_kernel_sectors = 0;
char fenix_gpu_vendor[28] = {0};
char fenix_gpu_product[28] = {0};

void kmain(BootInfo *bi) {
    /* ---------- HAL ---------- */
    serial_init();
    klog("BOOT", "FenixOS 1.4 'Faro' iniciando");

    if (bi->magic != FENIX_MAGIC) {
        klog("BOOT", "bootinfo invalido: deteniendo");
        for (;;) hlt_cpu();
    }
    fenix_boot_flags = bi->boot_flags;
    fenix_vbe_mem64k = bi->vbe_mem64k;
    fenix_kernel_sectors = bi->kernel_sectors;
    memcpy(fenix_gpu_vendor, bi->gpu_vendor, sizeof(fenix_gpu_vendor));
    fenix_gpu_vendor[sizeof(fenix_gpu_vendor) - 1] = 0;
    memcpy(fenix_gpu_product, bi->gpu_product, sizeof(fenix_gpu_product));
    fenix_gpu_product[sizeof(fenix_gpu_product) - 1] = 0;
    if (bi->boot_flags & BF_SAFE_MODE) {
        klogw("BOOT", "MODO SEGURO: sin red, raton ni sonido");
    }

    fb_init(bi);
    console_init();
    console_puts("FenixOS 1.4 'Faro' - bootloader propio + kernel x86_64\n");
    console_puts("Resolucion: ");
    {
        char tmp[64];
        ksnprintf(tmp, sizeof(tmp), "%ux%u@%u bpp\n\n", fb.width, fb.height, fb.bpp);
        console_puts(tmp);
    }
    klog("BOOT", "framebuffer activo");

    /* ---------- Kernel base ---------- */
    gdt_init();
    klog("BOOT", "GDT recargada");
    idt_init();
    klog("BOOT", "IDT lista");
    pic_remap();
    klog("BOOT", "PIC remapeado (IRQ 0-15 -> 32-47)");

    /* ---------- Memoria ---------- */
    pmm_init(bi);
    {
        char tmp[96];
        ksnprintf(tmp, sizeof(tmp), "PMM: %u MB gestionados (%u paginas), kernel en [0x%X..0x%X]",
                  (u32)(pmm_total_pages * PAGE_SIZE >> 20), (u32)pmm_total_pages,
                  (u32)kernel_start_addr, (u32)kernel_end_addr);
        klog("MEM", tmp);
    }

    heap_init();
    klog("MEM", "heap de 16MB inicializado");

    /* backbuffer del compositor */
    {
        u64 bbsize = (u64)fb.width * fb.height * 4;
        u64 bbpages = (bbsize + PAGE_SIZE - 1) / PAGE_SIZE;
        u64 bbphys = pmm_alloc_contig((u32)bbpages);
        if (!bbphys) {
            panic("sin memoria para el backbuffer grafico", 0, 0, 0);
        }
        backbuffer = (u32 *)bbphys;
        memset(backbuffer, 0, (size_t)bbsize);
        klog("MEM", "backbuffer del compositor reservado");
    }

    /* ---------- Multitarea ---------- */
    task_init();
    klogf(LOG_INFO, "TASK", "scheduler listo (round-robin, %d tareas max)", MAX_TASKS);

    /* ---------- Drivers de bloque y configuración persistente ---------- */
    blk_init(bi);                  /* ATA PIO + AHCI + zona de instalación */
    klogf(LOG_INFO, "BLK", "zona de instalacion: base %u, %u sectores (%s)",
          blk_part_base(), blk_part_sectors(),
          blk_part_base() ? "particion 0x63" : "disco entero");
    config_defaults();
    config_load_disk();            /* aplica tema/hostname/red guardados */
    klog("CFG", "configuracion del sistema lista");

    /* disco de datos secundario + FAT32 (v1.4): lectura/escritura de
     * archivos reales compatibles con Windows/Linux */
    ata2_init();
    fat_mount();

    /* ---------- Executive gráfico ---------- */
    gui_init();
    klog("GUI", "gui_init ok");
    wm_open_shell();
    klog("GUI", "escritorio y ventana FenixShell creados");

    /* reloj inicial */
    rtc_read_datetime();

    /* ---------- Subsistemas como tareas ---------- */
    ramfs_init();
    win_sample_install();
    users_init();                  /* sesion inicial (autologin de config) */
    shell_spawn();
    task_create("gui", gui_task, 0);
    task_create("reloj", clock_task, 0);
    klog("TASK", "tareas creadas: fsh, gui, reloj");

    /* ---------- Red TCP/IP (puede fallar sin NIC: no bloquea) ---------- */
    if (bi->boot_flags & BF_SAFE_MODE) {
        klogw("NET", "modo seguro: pila TCP/IP no inicializada");
    } else {
        net_init();
    }

    /* ---------- Audio AC97 (v1.4) ---------- */
    if (bi->boot_flags & BF_SAFE_MODE) {
        klogw("AC97", "modo seguro: audio omitido");
    } else {
        ac97_init();
    }

    /* ---------- Drivers con interrupciones ---------- */
    pit_init(100);
    kbd_init();
    if (bi->boot_flags & BF_SAFE_MODE) {
        klogw("HW", "modo seguro: raton PS/2 omitido");
    } else {
        mouse_init();
        klog("HW", "PIT 100Hz, teclado PS/2 y raton PS/2 activos");
    }

    console_puts("Arranque completo. Cambiando al escritorio grafico...\n");

    /* habilitar interrupciones: el timer empieza a planificar tareas */
    sti_irq();

    for (;;) hlt_cpu();
}
