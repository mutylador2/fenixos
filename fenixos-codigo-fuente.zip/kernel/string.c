/* FenixOS — string.c: funciones básicas de cadenas y memoria */
#include "fenixos.h"

void *memset(void *dst, int v, size_t n) {
    u8 *d = (u8 *)dst;
    while (n--) *d++ = (u8)v;
    return dst;
}

void *memcpy(void *dst, const void *src, size_t n) {
    u8 *d = (u8 *)dst;
    const u8 *s = (const u8 *)src;
    /* copia por qwords cuando es posible (rápido para compositor) */
    if ((((u64)d & 7) == ((u64)s & 7)) && n >= 32) {
        while ((u64)d & 7) { *d++ = *s++; n--; }
        u64 *dq = (u64 *)d;
        const u64 *sq = (const u64 *)s;
        while (n >= 8) { *dq++ = *sq++; n -= 8; }
        d = (u8 *)dq; s = (const u8 *)sq;
    }
    while (n--) *d++ = *s++;
    return dst;
}

int memcmp(const void *a, const void *b, size_t n) {
    const u8 *x = (const u8 *)a, *y = (const u8 *)b;
    while (n--) {
        if (*x != *y) return (int)*x - (int)*y;
        x++; y++;
    }
    return 0;
}

size_t strlen(const char *s) {
    size_t n = 0;
    while (s[n]) n++;
    return n;
}

int strcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (u8)*a - (u8)*b;
}

int strncmp(const char *a, const char *b, size_t n) {
    while (n && *a && *a == *b) { a++; b++; n--; }
    if (n == 0) return 0;
    return (u8)*a - (u8)*b;
}

char *strcpy(char *dst, const char *src) {
    char *d = dst;
    while ((*d++ = *src++)) ;
    return dst;
}

char *strncpy(char *dst, const char *src, size_t n) {
    char *d = dst;
    while (n && (*d++ = *src++)) n--;
    while (n--) *d++ = 0;
    return dst;
}

char *strcat(char *dst, const char *src) {
    char *d = dst + strlen(dst);
    while ((*d++ = *src++)) ;
    return dst;
}

char *strstr(const char *hay, const char *needle) {
    if (!*needle) return (char *)hay;
    for (; *hay; hay++) {
        const char *h = hay, *nd = needle;
        while (*h && *nd && *h == *nd) { h++; nd++; }
        if (!*nd) return (char *)hay;
    }
    return NULLP;
}

void *memmove(void *dst, const void *src, size_t n) {
    u8 *d = (u8 *)dst;
    const u8 *s2 = (const u8 *)src;
    if (d < s2) {
        for (size_t i = 0; i < n; i++) d[i] = s2[i];
    } else {
        for (size_t i = n; i > 0; i--) d[i - 1] = s2[i - 1];
    }
    return dst;
}
