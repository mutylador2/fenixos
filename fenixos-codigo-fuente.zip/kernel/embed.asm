; =====================================================================
; FenixOS — embed.asm: stage1 y stage2 incrustados en el kernel (v1.3)
;
; El instalador gráfico escribe el bootloader en el disco destino. Para
; funcionar desde cualquier medio de arranque (CD, USB, disco) lleva
; copias de stage1.bin y stage2.bin dentro del propio kernel.
;
; El Makefile compila el kernel CON ESTOS PLACEHOLDERS (tamaño fijo) y
; después scripts/patch_embed.py sustituye los marcadores FNXEMB1 /
; FNXEMB2 por los binarios reales (mismo tamaño, kernel ya enlazado).
; =====================================================================
section .rodata

global fenix_embed_stage1
global fenix_embed_stage2

fenix_embed_stage1:
    db "FNXEMB1"
    times 512 - 7 db 0xEE

fenix_embed_stage2:
    db "FNXEMB2"
    times 20480 - 7 db 0xEE
