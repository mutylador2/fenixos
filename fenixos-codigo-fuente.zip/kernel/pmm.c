/* FenixOS — pmm.c: gestor de memoria física (bitmap de 4KB sobre e820)
 * El kernel usa mapeo de identidad: dirección física == virtual.
 * Solo se gestionan páginas por debajo de 1GB (región mapeada). */
#include "fenixos.h"

#define MANAGED_LIMIT MEM_LIMIT_1GB
#define BITMAP_MAX (MANAGED_LIMIT / PAGE_SIZE / 8)   /* 32KB */

static u8 bitmap[BITMAP_MAX];        /* 1 = reservado */
u64 pmm_total_pages = 0;
u64 pmm_used_pages = 0;
u64 kernel_start_addr = 0x100000;
u64 kernel_end_addr = 0;

extern u8 kernel_end[];              /* símbolo kernel_end del linker.ld */

static inline int bit_test(u64 page) {
    return bitmap[page >> 3] & (1u << (page & 7));
}
static inline void bit_set(u64 page) {
    bitmap[page >> 3] |= (u8)(1u << (page & 7));
}
static inline void bit_clear(u64 page) {
    bitmap[page >> 3] &= (u8)~(1u << (page & 7));
}

void pmm_init(BootInfo *bi) {
    memset(bitmap, 0xFF, sizeof(bitmap));          /* todo reservado por defecto */
    kernel_start_addr = 0x100000;
    kernel_end_addr = (u64)kernel_end;             /* símbolo real del linker */

    E820Entry *e = (E820Entry *)(u64)bi->e820_ptr;
    for (u32 i = 0; i < bi->e820_count; i++) {
        if (e[i].type != E820_USABLE) continue;
        u64 base = e[i].base, end = e[i].base + e[i].len;
        if (base < 0x100000) base = 0x100000;      /* reservar toda la memoria baja */
        if (end > MANAGED_LIMIT) end = MANAGED_LIMIT;
        base = (base + PAGE_SIZE - 1) & ~(u64)(PAGE_SIZE - 1);
        end &= ~(u64)(PAGE_SIZE - 1);
        if (end <= base) continue;
        for (u64 p = base; p < end; p += PAGE_SIZE) {
            u64 page = p / PAGE_SIZE;
            if (!bit_test(page)) continue;         /* ya libre */
            bit_clear(page);
            pmm_total_pages++;
        }
    }
    pmm_used_pages = 0;

    /* reservar región del kernel (imagen + bss) */
    {
        u64 kstart = kernel_start_addr & ~(u64)(PAGE_SIZE - 1);
        u64 kend = (kernel_end_addr + PAGE_SIZE - 1) & ~(u64)(PAGE_SIZE - 1);
        for (u64 p = kstart; p < kend; p += PAGE_SIZE) {
            u64 page = p / PAGE_SIZE;
            if (page * PAGE_SIZE < MANAGED_LIMIT && !bit_test(page)) {
                bit_set(page);
                pmm_used_pages++;
            }
        }
    }

    /* reservar región del framebuffer lineal si cae bajo 1GB */
    extern FbInfo fb;
    if (fb.bpp && fb.paddr < MANAGED_LIMIT) {
        u64 fbsize = (u64)fb.pitch * fb.height;
        for (u64 p = fb.paddr & ~(u64)(PAGE_SIZE - 1);
             p < fb.paddr + fbsize; p += PAGE_SIZE) {
            u64 page = p / PAGE_SIZE;
            if (page * PAGE_SIZE < MANAGED_LIMIT && !bit_test(page)) {
                bit_set(page);
                pmm_used_pages++;
            }
        }
    }
}

u64 pmm_alloc(void) {
    for (u64 b = 0; b < BITMAP_MAX; b++) {
        if (bitmap[b] == 0xFF) continue;
        for (int i = 0; i < 8; i++) {
            if (!(bitmap[b] & (1u << i))) {
                bitmap[b] |= (u8)(1u << i);
                pmm_used_pages++;
                return (b * 8 + i) * PAGE_SIZE;
            }
        }
    }
    return 0;
}

u64 pmm_alloc_contig(u32 pages) {
    if (pages == 0) return 0;
    u64 run = 0;
    u64 total = MANAGED_LIMIT / PAGE_SIZE;
    for (u64 page = 0; page < total; page++) {
        if (!bit_test(page)) {
            run++;
            if (run == pages) {
                u64 first = page - pages + 1;
                for (u64 p = first; p <= page; p++) bit_set(p);
                pmm_used_pages += pages;
                return first * PAGE_SIZE;
            }
        } else {
            run = 0;
        }
    }
    return 0;
}

void pmm_free(u64 page) {
    u64 idx = page / PAGE_SIZE;
    if (idx * PAGE_SIZE >= MANAGED_LIMIT) return;
    if (bit_test(idx)) {
        bit_clear(idx);
        pmm_used_pages--;
    }
}
