/* FenixOS — pit.c: temporizador 8253/8254 canal 0 a 100 Hz */
#include "fenixos.h"

volatile u64 pit_ticks = 0;

#define PIT_HZ 100
#define PIT_BASE 1193182

void pit_init(u32 hz) {
    if (hz == 0) hz = PIT_HZ;
    u32 div = PIT_BASE / hz;
    outb(0x43, 0x36);                 /* canal 0, lo/hi, modo 3 (onda cuadrada) */
    outb(0x40, (u8)(div & 0xFF));
    outb(0x40, (u8)((div >> 8) & 0xFF));
}

/* llamado desde la IRQ del timer */
void pit_tick(void) {
    pit_ticks++;
}

void pit_sleep_ticks(u64 n) {
    u64 end = pit_ticks + n;
    while (pit_ticks < end) hlt_cpu();
}
