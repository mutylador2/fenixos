; =====================================================================
; FenixOS Kernel — isr.asm
; Stubs de interrupción (modo largo).
;
; En 64-bit IRETQ restaura SIEMPRE 5 campos: RIP, CS, RFLAGS, RSP, SS.
; La CPU solo empuja 3 (RFLAGS, CS, RIP) en interrupciones del mismo
; anillo, así que el stub construye el marco canónico de 5 slots:
; copia RIP/CS/RFLAGS más abajo y escribe los slots RSP/SS.
;
; Layout del frame (coincide con struct Frame de C, 22 qwords):
;   regs[15] (r15..rax), vector, err, rip, cs, rflags, rsp, ss
; =====================================================================

%macro PUSHALL 0
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
%endmacro

%macro POPALL 0
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
%endmacro

section .data
err_scratch: dq 0

section .text
global isr_stub_table
extern isr_dispatch

; %1 = vector, %2 = 1 si la CPU empuja código de error
%macro ISRSTUB 2
isr_stub_%1:
%if %2 == 1
    pop qword [err_scratch]          ; sacar el err de la CPU (queda como no-err)
%endif
    ; [rsp]=RIP, [rsp+8]=CS, [rsp+16]=RFLAGS (marco de 3 de la CPU)
    push qword [rsp+16]              ; copia RFLAGS hacia abajo
    push qword [rsp+16]              ; copia CS
    push qword [rsp+16]              ; copia RIP
%if %2 == 0
    push qword 0                     ; err inexistente -> 0
%else
    push qword [err_scratch]         ; err de la CPU a su slot
%endif
    push qword %1                    ; vector
    PUSHALL
    mov rdi, rsp
    ; La CPU entrega en +176/+184/+192 sus propios slots RFLAGS/RSP/SS del
    ; marco iret de 5. Normalizo RSP y SS a las posiciones que lee el C/iretq:
    ; RSP @ +160 (copiado del slot real de la CPU en +184) y SS @ +168.
    mov rax, [rsp+184]               ; RSP interrumpido (slot de la CPU)
    mov [rsp+160], rax
    mov qword [rsp+168], 0x10        ; SS
    mov rax, [rsp+112]               ; restaurar rax original desde el frame
    cld
    call isr_dispatch                ; rax = frame a restaurar (mismo o materializado)
    mov rsp, rax
    POPALL
    add rsp, 16                      ; descartar vector + err -> apunta a RIP
    iretq                            ; 5 slots: RIP, CS, RFLAGS, RSP, SS
%endmacro

; Excepciones con código de error: 8, 10-14, 17, 21, 22, 29-31
ISRSTUB 0, 0
ISRSTUB 1, 0
ISRSTUB 2, 0
ISRSTUB 3, 0
ISRSTUB 4, 0
ISRSTUB 5, 0
ISRSTUB 6, 0
ISRSTUB 7, 0
ISRSTUB 8, 1
ISRSTUB 9, 0
ISRSTUB 10, 1
ISRSTUB 11, 1
ISRSTUB 12, 1
ISRSTUB 13, 1
ISRSTUB 14, 1
ISRSTUB 15, 0
ISRSTUB 16, 0
ISRSTUB 17, 1
ISRSTUB 18, 0
ISRSTUB 19, 0
ISRSTUB 20, 0
ISRSTUB 21, 1
ISRSTUB 22, 1
ISRSTUB 23, 0
ISRSTUB 24, 0
ISRSTUB 25, 0
ISRSTUB 26, 0
ISRSTUB 27, 0
ISRSTUB 28, 0
ISRSTUB 29, 1
ISRSTUB 30, 1
ISRSTUB 31, 1

; IRQs y vectores de software (32..255)
%assign v 32
%rep 224
    ISRSTUB v, 0
%assign v v+1
%endrep

section .rodata
isr_stub_table:
%assign v 0
%rep 256
    dq isr_stub_%[v]
%assign v v+1
%endrep
