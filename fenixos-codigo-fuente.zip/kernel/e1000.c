/* FenixOS — e1000.c: driver de la NIC Intel 82540EM (QEMU e1000) (v1.2)
 *
 * Acceso por MMIO (BAR0). Funciona POR SONDEO (polling): sin interrupciones,
 * lo que evita acoplar la NIC al IDT y simplifica el planificador.
 *  - anillo TX de 8 descriptores (espera activa al DD)
 *  - anillo RX de 32 descriptores de 2048 B consumidos por e1000_poll()
 *
 * El BAR0 de la e1000 en QEMU cae en el GB 3 (0xFEBC0000), que stage2
 * ya mapea con identidad (PD_FB cubre 512 entradas de 2 MB = todo el GB). */
#include "fenixos.h"

/* registros MMIO */
#define REG_CTRL   0x0000
#define REG_STATUS 0x0008
#define REG_RCTL   0x0100
#define REG_TCTL   0x0400
#define REG_RDBAL  0x2800
#define REG_RDBAH  0x2804
#define REG_RDLEN  0x2808
#define REG_RDH    0x2810
#define REG_RDT    0x2818
#define REG_TDBAL  0x3800
#define REG_TDBAH  0x3804
#define REG_TDLEN  0x3808
#define REG_TDH    0x3810
#define REG_TDT    0x3818
#define REG_RAL    0x5400
#define REG_RAH    0x5404

#define CTRL_RST   (1u << 26)
#define STATUS_LU  (1u << 1)

#define TX_RING    8
#define RX_RING    32
#define PKT_MAX    2048

int net_link_up = 0;

typedef struct {
    u64 addr;
    u16 length;
    u16 csum;
    u8  status;
    u8  errors;
    u16 special;
} __attribute__((packed)) RxDesc;

typedef struct {
    u64 addr;
    u16 length;
    u8  cso;                          /* checksum offset (8 bits!) */
    u8  cmd;
    u8  sta;
    u8  css;                          /* checksum start */
    u16 special;
} __attribute__((packed)) TxDesc;      /* 16 bytes exactos, formato legacy */

/* cmd TX: EOP=0x01 | IFCS=0x02 | RS=0x08 */
#define TX_CMD_EOP   0x01
#define TX_CMD_IFCS  0x02
#define TX_CMD_RS    0x08
/* status: DD = 0x01 en ambos anillos */

static volatile u32 *mm = NULLP;      /* base MMIO */
static int nic_present = 0;
static u8  nic_mac[6];

static TxDesc *tx_ring;
static RxDesc *rx_ring;
static u8 *tx_bufs;                   /* TX_RING x PKT_MAX */
static u8 *rx_bufs;                   /* RX_RING x PKT_MAX */
static volatile u32 tx_cur, rx_cur;

static inline u32 erd(u32 off) { return mm[off / 4]; }
static inline void ewr(u32 off, u32 v) { mm[off / 4] = v; }

int e1000_present(void) { return nic_present; }

void e1000_mac(u8 mac_out[6]) {
    for (int i = 0; i < 6; i++) mac_out[i] = nic_mac[i];
}

int e1000_init(void) {
    nic_present = 0;
    net_link_up = 0;

    PciDev *d = pci_find(0x8086, 0x100E);   /* 82540EM (QEMU model=e1000) */
    if (!d) {
        klogw("NET", "sin NIC e1000 en el bus PCI");
        return -1;
    }
    u32 bar0 = d->bar[0] & 0xFFFFFFF0u;
    if (d->bar[0] & 1) {
        klogw("NET", "BAR0 de e1000 es de E/S: no soportado");
        return -1;
    }
    /* comprobación de mapeo: solo GB0 (0..0x3FFFFFFF) y GB3 (0xC0000000+) */
    u32 gb = bar0 >> 30;
    if (gb != 0 && gb != 3) {
        char tmp[64];
        ksnprintf(tmp, sizeof(tmp), "BAR0 %X fuera de las regiones mapeadas", bar0);
        kloge("NET", tmp);
        return -1;
    }
    mm = (volatile u32 *)(u64)bar0;

    /* reset del controlador */
    ewr(REG_CTRL, erd(REG_CTRL) | CTRL_RST);
    for (int i = 0; i < 100000 && (erd(REG_CTRL) & CTRL_RST); i++)
        io_wait();

    /* MAC de fábrica (+ bit Address Valid de RAH: sin él el filtro RX
     * descarta las tramas unicast dirigidas a nosotros y ARP muere) */
    u32 ral = erd(REG_RAL);
    u32 rah = erd(REG_RAH) | 0x80000000u;
    ewr(REG_RAH, rah);
    nic_mac[0] = (u8)(ral & 0xFF);
    nic_mac[1] = (u8)((ral >> 8) & 0xFF);
    nic_mac[2] = (u8)((ral >> 16) & 0xFF);
    nic_mac[3] = (u8)((ral >> 24) & 0xFF);
    nic_mac[4] = (u8)(rah & 0xFF);
    nic_mac[5] = (u8)((rah >> 8) & 0xFF);

    /* anillos y buffers */
    tx_ring = (TxDesc *)kcalloc(TX_RING * sizeof(TxDesc));
    rx_ring = (RxDesc *)kcalloc(RX_RING * sizeof(RxDesc));
    tx_bufs = (u8 *)kmalloc(TX_RING * PKT_MAX);
    rx_bufs = (u8 *)kmalloc(RX_RING * PKT_MAX);
    if (!tx_ring || !rx_ring || !tx_bufs || !rx_bufs) {
        kloge("NET", "sin memoria para los anillos de la NIC");
        return -2;
    }
    memset(rx_bufs, 0, RX_RING * PKT_MAX);
    tx_cur = 0;
    rx_cur = 0;

    /* RX */
    for (int i = 0; i < RX_RING; i++)
        rx_ring[i].addr = (u64)(uintptr_t)(rx_bufs + i * PKT_MAX);
    ewr(REG_RDBAL, (u32)((uintptr_t)rx_ring & 0xFFFFFFFFu));
    ewr(REG_RDBAH, 0);                    /* identidad < 4GB */
    ewr(REG_RDLEN, RX_RING * sizeof(RxDesc));
    ewr(REG_RDH, 0);
    ewr(REG_RDT, RX_RING - 1);            /* tail: último disponible */
    ewr(REG_RCTL, 0x3A);                  /* EN | UPE | MPE | LPE, buffers 2048 */

    /* TX */
    ewr(REG_TDBAL, (u32)((uintptr_t)tx_ring & 0xFFFFFFFFu));
    ewr(REG_TDBAH, 0);
    ewr(REG_TDLEN, TX_RING * sizeof(TxDesc));
    ewr(REG_TDH, 0);
    ewr(REG_TDT, 0);
    ewr(REG_TCTL, 0x400FA);               /* EN | PSP | CT=15 | COLD=64 */

    net_link_up = (erd(REG_STATUS) & STATUS_LU) ? 1 : 0;
    nic_present = 1;
    char tmp[96];
    ksnprintf(tmp, sizeof(tmp), "e1000 lista: MAC %x:%x:%x:%x:%x:%x, enlace %s",
              nic_mac[0], nic_mac[1], nic_mac[2], nic_mac[3], nic_mac[4], nic_mac[5],
              net_link_up ? "arriba" : "abajo");
    klog("NET", tmp);
    return 0;
}

/* envía una trama Ethernet completa (ya construida) */
int e1000_send(const void *data, u32 len) {
    if (!nic_present || len == 0 || len > PKT_MAX) return -1;
    u32 i = tx_cur;
    memcpy(tx_bufs + i * PKT_MAX, data, len);
    tx_ring[i].addr = (u64)(uintptr_t)(tx_bufs + i * PKT_MAX);
    tx_ring[i].length = (u16)len;
    tx_ring[i].cso = 0;
    tx_ring[i].cmd = TX_CMD_EOP | TX_CMD_IFCS | TX_CMD_RS;
    tx_ring[i].sta = 0;
    tx_ring[i].css = 0;
    tx_ring[i].special = 0;
    tx_cur = (i + 1) % TX_RING;
    ewr(REG_TDT, tx_cur);

    /* espera activa a la confirmación (con ceda para el scheduler) */
    u64 start = pit_ticks;
    while (!(tx_ring[i].sta & 0x01)) {
        if (pit_ticks - start > 30) return -2;   /* 300 ms */
        hlt_cpu();
    }
    return 0;
}

/* recoge la siguiente trama recibida (si la hay); 0 = nada */
int e1000_poll(void *buf, u32 bufsize) {
    if (!nic_present) return 0;
    u32 i = rx_cur;
    if (!(rx_ring[i].status & 0x01)) return 0;    /* sin DD */
    u16 len = rx_ring[i].length;
    rx_ring[i].status = 0;
    rx_cur = (i + 1) % RX_RING;
    ewr(REG_RDT, (rx_cur + RX_RING - 1) % RX_RING);
    if (len == 0) return 0;
    if (len > bufsize) len = (u16)bufsize;
    memcpy(buf, rx_bufs + i * PKT_MAX, len);
    return (int)len;
}
