/* FenixOS — fat32.c: sistema de archivos FAT32 lectura/escritura (v1.4)
 *
 * Monta la primera partición FAT32 (tipos 0x0B/0x0C) que encuentre en:
 *   1. el disco ATA secundario (disco de datos añadido, p.ej. USB/extra),
 *   2. el disco de arranque (particiones del MBR del backend blk),
 * o un "superfloppy" (FAT32 sin particionar) en el secundario.
 *
 * Permite leer y escribir archivos REALES que Windows/Linux también
 * ven: interoperabilidad directa con un pendrive o una partición de
 * datos compartida.
 *
 * Alcance honesto (v1.4):
 *   - Directorio raíz (sin navegación por subdirectorios; se muestran).
 *   - Nombres largos (LFN) en lectura; en escritura crea LFN + alias 8.3.
 *   - Archivos hasta 8 MB. Sin atributos avanzados ni diario. */
#include "fenixos.h"

/* ---------------- estado del montaje ---------------- */
static int   fat_ok = 0;
static u32   fat_base = 0;          /* LBA absoluto del inicio del volumen */
static u16   fat_spc = 0;           /* sectores por cluster */
static u32   fat_reserved = 0;
static u8    fat_nfats = 0;
static u32   fat_fatsz = 0;         /* sectores por FAT */
static u32   fat_rootclus = 0;
static u32   fat_total = 0;         /* sectores totales del volumen */
static u32   fat_clusters = 0;      /* nº de clusters de datos */
static u32   fat_fat_start = 0;     /* LBA absoluto de la FAT1 */
static u32   fat_data_start = 0;    /* LBA absoluto del cluster 2 */
static u32   fat_bpc = 0;           /* bytes por cluster */
static char  fat_label_str[12];
static char  fat_src[64];           /* de dónde salió el volumen */
static u32   fat_free_hint = 0xFFFFFFFF;   /* clusters libres (si FSInfo) */

/* lector de bloques activo (segundo disco o backend blk) */
typedef int (*FatReadFn)(u32 lba, void *buf);
typedef int (*FatWriteFn)(u32 lba, const void *buf);
static FatReadFn  fat_rd = 0;
static FatWriteFn fat_wr = 0;

/* caché de 1 sector de la FAT (los clusters se recorren en cadena) */
static u8  fatcache[512];
static u32 fatcache_idx = 0xFFFFFFFF;

#define FAT32_EOC   0x0FFFFFFFu
#define ATTR_LFN    0x0F
#define ATTR_DIR    0x10
#define ATTR_VOLUME 0x08
#define FAT_MAX_FILE (8u * 1024u * 1024u)

/* ---------------- helpers de bloque ---------------- */
static int fsec_read(u32 vol_lba, u8 *buf) {
    if (!fat_rd) return -1;
    return fat_rd(fat_base + vol_lba, buf);
}
static int fsec_write(u32 vol_lba, const u8 *buf) {
    if (!fat_wr) return -1;
    return fat_wr(fat_base + vol_lba, buf);
}

static u16 rd16(const u8 *p) { return (u16)(p[0] | (p[1] << 8)); }
static u32 rd32(const u8 *p) {
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}
static void wr16(u8 *p, u16 v) { p[0] = (u8)v; p[1] = (u8)(v >> 8); }
static void wr32(u8 *p, u32 v) {
    p[0] = (u8)v; p[1] = (u8)(v >> 8); p[2] = (u8)(v >> 16); p[3] = (u8)(v >> 24);
}

/* ---------------- FAT: leer/entradas ---------------- */
static u32 fat_entry(u32 clus) {
    u32 sec = clus >> 7;                       /* 128 entradas de 4B por sector */
    if (sec >= fat_fatsz) return FAT32_EOC;
    if (fatcache_idx != sec) {
        if (fsec_read(fat_fat_start + sec, fatcache) != 0) return FAT32_EOC;
        fatcache_idx = sec;
    }
    u32 off = (clus & 127) * 4;
    return rd32(fatcache + off) & 0x0FFFFFFFu;
}

static void fat_cache_invalidate(void) { fatcache_idx = 0xFFFFFFFF; }

/* fija una entrada de la FAT (lectura-modificación-escritura directa) */
static int fat_set_entry(u32 clus, u32 val) {
    u32 sec = clus >> 7;
    if (sec >= fat_fatsz) return -1;
    u8 b[512];
    if (fsec_read(fat_fat_start + sec, b) != 0) return -1;
    wr32(b + (clus & 127) * 4, val & 0x0FFFFFFFu);
    /* escribir en TODAS las copias de la FAT */
    for (int f = 0; f < fat_nfats; f++) {
        if (fsec_write(fat_fat_start + (u32)f * fat_fatsz + sec, b) != 0) return -1;
    }
    fat_cache_invalidate();
    return 0;
}

static u32 fat_next_cluster(u32 clus) { return fat_entry(clus); }

static int fat_is_eoc(u32 v) { return v >= 0x0FFFFFF8u; }

/* busca un cluster libre (valor 0), lo marca EOC y lo devuelve */
static u32 fat_alloc_cluster(void) {
    u8 b[512];
    for (u32 sec = 0; sec < fat_fatsz; sec++) {
        if (fsec_read(fat_fat_start + sec, b) != 0) return 0;
        for (int i = 0; i < 128; i++) {
            u32 clus = sec * 128 + (u32)i;
            if (clus < 2) continue;
            if ((rd32(b + i * 4) & 0x0FFFFFFF) == 0) {
                if (fat_set_entry(clus, FAT32_EOC) != 0) return 0;
                return clus;
            }
        }
        if (sec > 4096) break;                 /* no escanear FATs gigantes */
    }
    return 0;                                  /* disco lleno */
}

/* libera una cadena de clusters (pone 0 en cada entrada) */
static void fat_free_chain(u32 start) {
    u32 c = start;
    int guard = 0;
    while (c >= 2 && c < fat_clusters + 2 && !fat_is_eoc(c) && guard++ < 100000) {
        u32 nxt = fat_entry(c);
        fat_set_entry(c, 0);
        c = nxt;
    }
    fat_cache_invalidate();
}

/* nº de clusters de una cadena (0 si invalida) */
static u32 fat_chain_len(u32 start) {
    u32 c = start, n = 0;
    while (c >= 2 && c < fat_clusters + 2 && !fat_is_eoc(c) && n < 100000) {
        c = fat_next_cluster(c);
        n++;
    }
    return fat_is_eoc(c) ? n : 0;
}

/* ---------------- BPB y montaje ---------------- */
static int parse_bpb(void) {
    u8 b[512];
    if (fsec_read(0, b) != 0) return -1;
    if (b[510] != 0x55 || b[511] != 0xAA) return -1;
    if (b[0] != 0xEB && b[0] != 0xE9) return -1;
    u16 bps = rd16(b + 11);
    if (bps != 512) return -1;
    u8 spc = b[13];
    if (!spc || spc > 128) return -1;
    if (memcmp(b + 82, "FAT32", 5) != 0) return -1;   /* solo FAT32 */

    fat_reserved = rd16(b + 14);
    fat_nfats = b[16];
    u16 totsec16 = rd16(b + 19);
    u32 totsec32 = rd32(b + 32);
    u32 fatsz16 = rd16(b + 22);
    fat_fatsz = rd32(b + 36);
    if (!fat_fatsz) fat_fatsz = fatsz16;
    fat_rootclus = rd32(b + 44);
    fat_total = totsec32 ? totsec32 : totsec16;
    if (!fat_reserved || !fat_nfats || fat_nfats > 4 || !fat_fatsz || !fat_total)
        return -1;
    if (fat_rootclus < 2) return -1;

    fat_spc = spc;
    fat_fat_start = fat_reserved;
    fat_data_start = fat_reserved + (u32)fat_nfats * fat_fatsz;
    if (fat_data_start >= fat_total) return -1;
    fat_clusters = (fat_total - fat_data_start) / fat_spc;
    fat_bpc = (u32)fat_spc * 512;
    if (fat_clusters < 8) return -1;

    memcpy(fat_label_str, b + 71, 11);
    fat_label_str[11] = 0;
    for (int i = 10; i >= 0 && fat_label_str[i] == ' '; i--) fat_label_str[i] = 0;
    if (!fat_label_str[0]) strcpy(fat_label_str, "SIN-NOMBRE");

    /* pista de clusters libres en el sector FSInfo */
    fat_free_hint = 0xFFFFFFFF;
    return 0;
}

static int try_mount_with(FatReadFn rd, FatWriteFn wr, const char *donde) {
    fat_rd = rd;
    fat_wr = wr;
    if (parse_bpb() != 0) { fat_rd = 0; fat_wr = 0; return -1; }
    fat_ok = 1;
    strncpy(fat_src, donde, sizeof(fat_src) - 1);
    fat_src[sizeof(fat_src) - 1] = 0;
    return 0;
}

int fat_mount(void) {
    fat_ok = 0;
    fatcache_idx = 0xFFFFFFFF;
    fat_rd = 0; fat_wr = 0;

    /* 1) disco secundario: superfloppy y luego particiones */
    if (ata2_present()) {
        if (try_mount_with(ata2_read_sector, ata2_write_sector,
                           "disco secundario (disco entero)") == 0) {
            klogf(LOG_INFO, "FAT", "FAT32 montado: %s, %u MB, %u MB libres aprox",
                  fat_label_str, fat_total >> 11, fat_free_kb() / 1024);
            return 0;
        }
        /* particiones del secundario */
        u8 mbr[512];
        if (ata2_read_sector(0, mbr) == 0 && mbr[510] == 0x55 && mbr[511] == 0xAA) {
            for (int i = 0; i < 4; i++) {
                const u8 *e = mbr + 446 + i * 16;
                u8 type = e[4];
                if (type != 0x0B && type != 0x0C) continue;
                u32 start = rd32(e + 8);
                fat_base = start;      /* parse_bpb lee relativo a fat_base */
                if (try_mount_with(ata2_read_sector, ata2_write_sector,
                                   "particion FAT32 del disco secundario") == 0) {
                    klogf(LOG_INFO, "FAT", "FAT32 montado: particion %d, %s, %u MB",
                          i + 1, fat_label_str, fat_total >> 11);
                    return 0;
                }
            }
        }
        fat_base = 0;
    }

    /* 2) disco de arranque (backend blk): particiones FAT32 */
    if (blk_present()) {
        u8 mbr[512];
        if (blk_read(0, mbr) == 0 && mbr[510] == 0x55 && mbr[511] == 0xAA) {
            for (int i = 0; i < 4; i++) {
                const u8 *e = mbr + 446 + i * 16;
                u8 type = e[4];
                if (type != 0x0B && type != 0x0C) continue;
                u32 start = rd32(e + 8);
                fat_base = start;
                if (try_mount_with(blk_read, blk_write,
                                   "particion FAT32 del disco de arranque") == 0) {
                    klogf(LOG_INFO, "FAT", "FAT32 montado: particion %d, %s, %u MB",
                          i + 1, fat_label_str, fat_total >> 11);
                    return 0;
                }
            }
        }
        fat_base = 0;
    }

    fat_rd = 0; fat_wr = 0;
    klogw("FAT", "sin particion FAT32 utilizable");
    return -1;
}

int  fat_present(void)  { return fat_ok; }
const char *fat_label(void) { return fat_ok ? fat_label_str : ""; }
const char *fat_where(void) { return fat_ok ? fat_src : ""; }
u32  fat_total_mb(void) { return fat_ok ? fat_total >> 11 : 0; }
u32  fat_bytes_per_cluster(void) { return fat_ok ? fat_bpc : 0; }
u32  fat_root_entries_max(void) {
    /* raíz = cadena de clusters; aprox. entradas disponibles */
    return fat_ok ? (fat_chain_len(fat_rootclus) * fat_bpc) / 32 : 0;
}

u32 fat_free_kb(void) {
    if (!fat_ok) return 0;
    u8 b[512];
    u32 free_c = 0;
    for (u32 sec = 0; sec < fat_fatsz && sec < 4096; sec++) {
        if (fsec_read(fat_fat_start + sec, b) != 0) break;
        for (int i = 0; i < 128; i++) {
            u32 clus = sec * 128 + (u32)i;
            if (clus < 2 || clus >= fat_clusters + 2) continue;
            if ((rd32(b + i * 4) & 0x0FFFFFFF) == 0) free_c++;
        }
    }
    return (free_c * fat_bpc) / 1024;
}

/* ---------------- nombres ---------------- */
/* convierte la entrada 8.3 "NOMBRE   EXT" en "nombre.ext" */
static void entry_to_name(const u8 *e, char *out) {
    char base[9], ext[4];
    memcpy(base, e, 8); base[8] = 0;
    memcpy(ext, e + 8, 3); ext[3] = 0;
    for (int i = 7; i >= 0 && base[i] == ' '; i--) base[i] = 0;
    for (int i = 2; i >= 0 && ext[i] == ' '; i--) ext[i] = 0;
    /* primer byte 0x05 representa 0xE5 */
    if ((u8)base[0] == 0x05) base[0] = (char)0xE5;
    u32 o = 0;
    for (int i = 0; base[i] && o < 12; i++) {
        char c = base[i];
        out[o++] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
    }
    if (ext[0]) {
        out[o++] = '.';
        for (int i = 0; ext[i] && o < 14; i++) {
            char c = ext[i];
            out[o++] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
        }
    }
    out[o] = 0;
}

/* compara un nombre de usuario con el nombre 8.3 de la entrada */
static int name_match83(const u8 *e, const char *name) {
    char tmp[16];
    entry_to_name(e, tmp);
    return strncasecmp_fenix(tmp, name, sizeof(tmp)) == 0 && strlen(tmp) == strlen(name);
}

/* arma el nombre LFN de la entrada corta en dir[off]
 * (las LFN preceden a la corta: la parte 1 es la más cercana a la
 * entrada corta y la que lleva el bit 0x40 está más lejos) */
static void entry_lfn_name(const u8 *sec0, u32 off, char *out, u32 outs) {
    out[0] = 0;
    static const u32 offs[13] = { 1,3,5,7,9,14,16,18,20,22,24,28,30 };
    char tmp[128];
    u32 tl = 0;
    int got = 0;
    /* recorrer hacia atrás desde la corta: parte 1, parte 2, ... */
    for (int back = 1; back <= 16 && off >= 32u * (u32)back; back++) {
        const u8 *l = sec0 + (off - 32u * (u32)back);
        if (l[11] != ATTR_LFN) return;         /* sin LFN válida */
        for (int k = 0; k < 13; k++) {
            u16 ch = (u16)l[offs[k]] | ((u16)l[offs[k] + 1] << 8);
            if (ch == 0x0000 || ch == 0xFFFF) continue;
            if (ch >= 32 && ch < 127 && tl + 1 < sizeof(tmp)) tmp[tl++] = (char)ch;
            else if (tl + 1 < sizeof(tmp)) tmp[tl++] = '_';
        }
        if (l[0] & 0x40) { got = 1; break; }   /* última parte: fin */
    }
    if (!got || tl == 0) return;
    if (tl >= outs) tl = outs - 1;
    memcpy(out, tmp, tl);
    out[tl] = 0;
}

/* checksum de nombre corto (para casar LFN) */
static u8 lfn_checksum(const u8 *shortname) {
    u8 sum = 0;
    for (int i = 0; i < 11; i++)
        sum = (u8)(((sum >> 1) | ((sum & 1) << 7)) + shortname[i]);
    return sum;
}

/* ---------------- directorio raíz: enumeración ---------------- */
/* recorre la cadena del directorio raíz; por cada entrada válida llama
 * a cb(off_sec_abs, off_in_sector, entry32, lfn_name) o acumula lista */
typedef int (*DirCb)(u32 sec_abs, u32 off, const u8 *e, const char *lfn, void *ud);

static int dir_walk(DirCb cb, void *ud) {
    if (!fat_ok) return -1;
    u8 sec[512];
    char lfn[128];
    u32 c = fat_rootclus;
    int guard = 0;
    while (c >= 2 && c < fat_clusters + 2 && !fat_is_eoc(c) && guard++ < 4096) {
        u32 start_abs = fat_data_start + (c - 2) * fat_spc;
        for (u32 s = 0; s < fat_spc; s++) {
            if (fsec_read(start_abs + s, sec) != 0) return -1;
            for (u32 off = 0; off < 512; off += 32) {
                const u8 *e = sec + off;
                if (e[0] == 0x00) return 0;    /* fin del directorio */
                if (e[0] == 0xE5) continue;    /* borrada */
                if (e[11] == ATTR_LFN) continue;
                if (e[11] & ATTR_VOLUME) continue;
                lfn[0] = 0;
                entry_lfn_name(sec, off, lfn, sizeof(lfn));
                int r = cb(start_abs + s, off, e, lfn, ud);
                if (r) return r;               /* el callback corta */
            }
        }
        c = fat_next_cluster(c);
    }
    return 0;
}

typedef struct { int idx, want; char *name; u32 namesz; u32 *size; int *is_dir; } ListUd;
static int cb_list(u32 sec_abs, u32 off, const u8 *e, const char *lfn, void *ud) {
    (void)sec_abs; (void)off;
    ListUd *d = (ListUd *)ud;
    if (d->idx++ != d->want) return 0;
    char tmp[16];
    entry_to_name(e, tmp);
    const char *nm = lfn[0] ? lfn : tmp;
    if (d->name && d->namesz) {
        strncpy(d->name, nm, d->namesz - 1);
        d->name[d->namesz - 1] = 0;
    }
    if (d->size) *d->size = rd32(e + 28);
    if (d->is_dir) *d->is_dir = (e[11] & ATTR_DIR) ? 1 : 0;
    return 1;                                  /* corto */
}

int fat_dir_count(void) {
    ListUd d = { 0, -1, NULLP, 0, NULLP, NULLP };
    dir_walk(cb_list, &d);
    return d.idx;
}

int fat_dir_get(int idx, char *name_out, u32 namesz, u32 *size, int *is_dir) {
    ListUd d = { 0, idx, name_out, namesz, size, is_dir };
    int found = dir_walk(cb_list, &d);
    return found ? 0 : -1;
}

/* ---------------- buscar una entrada por nombre ---------------- */
typedef struct { const char *name; u32 sec_abs, off; u8 entry[32]; char lfn[128]; int found; } FindUd;
static int cb_find(u32 sec_abs, u32 off, const u8 *e, const char *lfn, void *ud) {
    FindUd *f = (FindUd *)ud;
    if (name_match83(e, f->name) || (lfn[0] && strncasecmp_fenix(lfn, f->name, 127) == 0
                                     && strlen(lfn) == strlen(f->name))) {
        f->sec_abs = sec_abs;
        f->off = off;
        memcpy(f->entry, e, 32);
        strncpy(f->lfn, lfn, sizeof(f->lfn) - 1);
        f->lfn[sizeof(f->lfn) - 1] = 0;
        f->found = 1;
        return 1;
    }
    return 0;
}

static int dir_find(const char *name, FindUd *f) {
    f->name = name;
    f->found = 0;
    dir_walk(cb_find, f);
    return f->found ? 0 : -1;
}

/* ---------------- leer archivo ---------------- */
int fat_read_file(const char *name, char *buf, u32 max) {
    if (!fat_ok) return -1;
    FindUd f;
    if (dir_find(name, &f) != 0) return -1;
    if (f.entry[11] & ATTR_DIR) return -2;
    u32 size = rd32(f.entry + 28);
    u32 clus = (u32)f.entry[21] << 8 | (u32)f.entry[20];       /* cluster alto */
    clus = (clus << 16) | ((u32)f.entry[26] | ((u32)f.entry[27] << 8));
    if (clus < 2) return size ? -3 : 0;
    if (size > FAT_MAX_FILE) return -4;
    if (size > max) size = max;                /* respetar el búfer del llamante */

    u32 got = 0;
    u8 sec[512];
    int guard = 0;
    while (got < size && clus >= 2 && clus < fat_clusters + 2 && !fat_is_eoc(clus)
           && guard++ < 100000) {
        u32 start_abs = fat_data_start + (clus - 2) * fat_spc;
        for (u32 s = 0; s < fat_spc && got < size; s++) {
            if (fsec_read(start_abs + s, sec) != 0) return -1;
            u32 chunk = size - got;
            if (chunk > 512) chunk = 512;
            memcpy(buf + got, sec, chunk);
            got += chunk;
        }
        clus = fat_next_cluster(clus);
    }
    return (int)got;
}

/* ---------------- escribir archivo ---------------- */
/* genera el nombre corto 8.3 desde "hola mundo.txt" -> "HOLAMU~1.TXT" */
static int make_short_name(const char *name, u8 *out11, int alias_n) {
    const char *dot = NULLP;
    for (const char *p = name; *p; p++) if (*p == '.') dot = p;
    u32 bl = dot ? (u32)(dot - name) : strlen(name);
    const char *ext = dot ? dot + 1 : "";
    u32 el = strlen(ext);
    if (!bl || bl > 255 || el > 3) return -1;
    /* ¿cabe directo como 8.3 mayúsculas? */
    int fits = (bl <= 8);
    for (u32 i = 0; i < bl && fits; i++) {
        char c = name[i];
        if (c >= 'a' && c <= 'z') fits = 0;
        else if (!((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
                   c == '_' || c == '-' || c == '@' || c == '(' || c == ')'))
            return -1;
    }
    for (u32 i = 0; i < el && fits; i++) {
        char c = ext[i];
        if (c >= 'a' && c <= 'z') fits = 0;
        else if (!((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
                   c == '_' || c == '-' || c == '@'))
            return -1;
    }
    memset(out11, ' ', 11);
    if (fits) {
        for (u32 i = 0; i < bl; i++)
            out11[i] = (char)((name[i] >= 'a' && name[i] <= 'z') ? name[i] - 32 : name[i]);
        for (u32 i = 0; i < el; i++)
            out11[8 + i] = (char)((ext[i] >= 'a' && ext[i] <= 'z') ? ext[i] - 32 : ext[i]);
        return 0;                              /* sin LFN necesaria */
    }
    /* alias 6 + ~n */
    u32 b = 0;
    for (u32 i = 0; i < bl && b < 6; i++) {
        char c = name[i];
        if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) out11[b++] = c;
        else if (c >= 'a' && c <= 'z') out11[b++] = (char)(c - 32);
    }
    if (!b) out11[b++] = 'F';
    if (alias_n > 4) return -1;                /* demasiados alias */
    char tail[8];
    u32 tl = (u32)ksnprintf(tail, sizeof(tail), "~%d", alias_n + 1);
    if (b + tl > 8) b = 8 - tl;
    for (u32 i = 0; i < tl; i++) out11[b + i] = tail[i];
    for (u32 i = 0; i < el; i++) {
        char c = ext[i];
        out11[8 + i] = (char)((c >= 'a' && c <= 'z') ? c - 32 : c);
    }
    return 1;                                  /* con LFN necesaria */
}

static int name_exists_short(const u8 *out11) {
    u8 sec[512];
    u32 c = fat_rootclus;
    int guard = 0;
    while (c >= 2 && c < fat_clusters + 2 && !fat_is_eoc(c) && guard++ < 4096) {
        u32 start_abs = fat_data_start + (c - 2) * fat_spc;
        for (u32 s = 0; s < fat_spc; s++) {
            if (fsec_read(start_abs + s, sec) != 0) return 0;
            for (u32 off = 0; off < 512; off += 32) {
                const u8 *e = sec + off;
                if (e[0] == 0x00) return 0;
                if (e[11] == ATTR_LFN || (e[11] & ATTR_VOLUME)) continue;
                if (memcmp(e, out11, 11) == 0) return 1;
            }
        }
        c = fat_next_cluster(c);
    }
    return 0;
}

/* extensión de la cadena del directorio raíz con un cluster limpio */
static int dir_extend_chain(void) {
    u32 nc = fat_alloc_cluster();
    if (!nc) return -1;
    u32 c = fat_rootclus, prev = fat_rootclus;
    int g = 0;
    while (c >= 2 && c < fat_clusters + 2 && !fat_is_eoc(c) && g++ < 4096) {
        prev = c;
        c = fat_next_cluster(c);
    }
    u8 fb[512];
    if (fsec_read(fat_fat_start + (prev >> 7), fb) != 0) return -1;
    wr32(fb + (prev & 127) * 4, nc);
    for (int f = 0; f < fat_nfats; f++)
        if (fsec_write(fat_fat_start + (u32)f * fat_fatsz + (prev >> 7), fb) != 0)
            return -1;
    fat_cache_invalidate();
    if (fat_set_entry(nc, FAT32_EOC) != 0) return -1;
    u8 z[512];
    memset(z, 0, 512);
    u32 start_abs = fat_data_start + (nc - 2) * fat_spc;
    for (u32 s = 0; s < fat_spc; s++)
        if (fsec_write(start_abs + s, z) != 0) return -1;
    return 0;
}

/* posición física (sector absoluto, offset) de una ranura lógica
 * del directorio raíz (32 bytes por ranura) */
static int dir_slot_phys(u32 logical, u32 *sec_abs, u32 *off) {
    u32 idx = 0;
    u32 c = fat_rootclus;
    int guard = 0;
    while (c >= 2 && c < fat_clusters + 2 && !fat_is_eoc(c) && guard++ < 4096) {
        u32 start_abs = fat_data_start + (c - 2) * fat_spc;
        u32 slots_per_cluster = fat_bpc / 32;
        if (logical < idx + slots_per_cluster) {
            u32 in_cluster = (logical - idx) * 32;
            *sec_abs = start_abs + in_cluster / 512;
            *off = in_cluster % 512;
            return 0;
        }
        idx += slots_per_cluster;
        c = fat_next_cluster(c);
    }
    return -1;
}

/* hora/fecha DOS desde el RTC */
static void dos_datetime(u16 *t, u16 *d) {
    rtc_read_datetime();
    u32 y = rtc_year, mo = rtc_month, da = rtc_day;
    if (y < 1980) y = 2026;
    *d = (u16)(((y - 1980) << 9) | (mo << 5) | da);
    *t = (u16)((rtc_hour << 11) | (rtc_min << 5) | (rtc_sec >> 1));
}

int fat_write_file(const char *name, const char *data, u32 len) {
    if (!fat_ok) return -1;
    if (!name || !*name || len > FAT_MAX_FILE) return -4;
    for (const char *p = name; *p; p++)
        if (*p == '/' || *p == '\\' || *p == ':') return -5;

    /* nombre corto (y si hace falta LFN), evitando colisiones */
    u8 short11[12];
    int need_lfn = 0;
    for (int alias = 0; alias < 5; alias++) {
        need_lfn = make_short_name(name, short11, alias);
        if (need_lfn < 0) return -5;
        if (!name_exists_short(short11)) break;
        if (!need_lfn && alias == 0) {
            /* el 8.3 directo existe: ¿es el mismo archivo? lo trataremos
             * abajo como sobrescritura; verificar por nombre largo/83 */
        }
    }
    u8 short11_cmp[12];
    memcpy(short11_cmp, short11, 11);

    /* clusters necesarios */
    u32 nclus = (len + fat_bpc - 1) / fat_bpc;
    if (!nclus) nclus = 1;
    if (nclus > fat_clusters) return -1;

    /* ¿existe ya? -> reciclar entrada y liberar cadena vieja */
    FindUd f;
    u32 old_chain = 0;
    u32 dirent_sec = 0, dirent_off = 0;
    int have_slot = 0;
    if (dir_find(name, &f) == 0) {
        if (f.entry[11] & ATTR_DIR) return -2;
        old_chain = ((u32)f.entry[20] << 24) | ((u32)f.entry[21] << 16) |
                    (u32)f.entry[26] | ((u32)f.entry[27] << 8);
        dirent_sec = f.sec_abs;
        dirent_off = f.off;
        have_slot = 1;
        /* el nombre corto existente manda: no crear otro */
        memcpy(short11_cmp, f.entry, 11);
        need_lfn = 0;                          /* la LFN ya está en disco */
    }

    /* buscar hueco: una racha de (lfn_ents + 1) ranuras libres (0xE5 o
     * 0x00). Tras el primer 0x00 todo es libre (fin lógico del
     * directorio), así que la entrada corta puede quedar DENTRO de la
     * zona 0x00 con sus LFN justo delante. v1.4: antes las LFN se
     * escribían hacia atrás sobre entradas vivas y se corrompía el
     * directorio raíz. */
    if (!have_slot) {
        u32 lfn_ents = need_lfn ? (u32)((strlen(name) + 12) / 13) : 0;
        u32 need_slots = lfn_ents + 1;
        u32 run_start = 0, run_len = 0, total = 0;
        u32 target = 0xFFFFFFFF;           /* ranura lógica de la entrada corta */
        int decided = 0;
        {
            u8 sec[512];
            u32 c = fat_rootclus;
            int guard = 0;
            while (c >= 2 && c < fat_clusters + 2 && !fat_is_eoc(c) &&
                   guard++ < 4096 && !decided) {
                u32 start_abs = fat_data_start + (c - 2) * fat_spc;
                for (u32 s = 0; s < fat_spc && !decided; s++) {
                    if (fsec_read(start_abs + s, sec) != 0) return -1;
                    for (u32 off = 0; off < 512 && !decided; off += 32) {
                        const u8 *e = sec + off;
                        if (e[0] == 0x00) {
                            target = total + lfn_ents;   /* LFN desde aquí */
                            decided = 1;
                            break;
                        }
                        if (e[0] == 0xE5) {
                            if (run_len == 0) run_start = total;
                            run_len++;
                            if (run_len >= need_slots) {
                                target = run_start + lfn_ents;
                                decided = 1;
                                break;
                            }
                        } else {
                            run_len = 0;
                        }
                        total++;
                    }
                }
                if (!decided) c = fat_next_cluster(c);
            }
            if (!decided) target = total + lfn_ents;   /* sin huecos: extender */
        }
        /* asegurar capacidad de la cadena y localizar la ranura física */
        u32 nslots = fat_chain_len(fat_rootclus) * (fat_bpc / 32);
        int guard2 = 0;
        while (nslots < target + 1 && guard2++ < 64) {
            if (dir_extend_chain() != 0) return -1;
            nslots += fat_bpc / 32;
        }
        u32 s_abs = 0, s_off = 0;
        if (dir_slot_phys(target, &s_abs, &s_off) != 0) return -1;
        dirent_sec = s_abs;
        dirent_off = s_off;
        have_slot = 1;
    }

    /* asignar la cadena nueva */
    u32 chain = 0, prev = 0;
    for (u32 i = 0; i < nclus; i++) {
        u32 nc = fat_alloc_cluster();
        if (!nc) {
            if (chain) fat_free_chain(chain);
            return -1;                         /* disco lleno a mitad */
        }
        if (!chain) chain = nc;
        else {
            /* enlazar prev->nc */
            u8 fb[512];
            u32 es = fat_fat_start + (prev >> 7);
            if (fsec_read(es, fb) != 0) return -1;
            wr32(fb + (prev & 127) * 4, nc);
            for (int ff = 0; ff < fat_nfats; ff++)
                if (fsec_write(fat_fat_start + (u32)ff * fat_fatsz + (prev >> 7), fb) != 0)
                    return -1;
            fat_cache_invalidate();
        }
        prev = nc;
    }

    /* escribir los datos */
    u8 sec[512];
    u32 written = 0;
    u32 c = chain;
    while (written < len || (nclus && written == 0 && len == 0)) {
        u32 start_abs = fat_data_start + (c - 2) * fat_spc;
        for (u32 s = 0; s < fat_spc; s++) {
            u32 chunk = len - written;
            if (chunk > 512) chunk = 512;
            if (chunk) memcpy(sec, data + written, chunk);
            if (chunk < 512) memset(sec + chunk, 0, 512 - chunk);
            if (fsec_write(start_abs + s, sec) != 0) {
                fat_free_chain(chain);
                return -1;
            }
            written += chunk;
            if (written >= len && len) break;
        }
        if (written >= len) break;
        c = fat_next_cluster(c);
        if (fat_is_eoc(c) || c < 2) break;
    }
    if (len == 0) written = 0;

    /* liberar la cadena vieja DESPUÉS de escribir la nueva */
    if (old_chain >= 2) fat_free_chain(old_chain);

    /* construir la entrada de directorio */
    u8 newent[32];
    memset(newent, 0, 32);
    memcpy(newent, short11_cmp, 11);
    newent[11] = 0x20;                         /* archivo, archivo */
    u16 dt, dd;
    dos_datetime(&dt, &dd);
    wr16(newent + 14, dt); wr16(newent + 16, dd);   /* creación */
    wr16(newent + 18, dd);                          /* último acceso */
    wr16(newent + 22, dt); wr16(newent + 24, dd);   /* modificación */
    newent[26] = (u8)(chain & 0xFF);
    newent[27] = (u8)((chain >> 8) & 0xFF);
    newent[20] = (u8)((chain >> 16) & 0xFF);
    newent[21] = (u8)((chain >> 24) & 0xFF);
    wr32(newent + 28, len);

    /* escribir entradas LFN (si toca) justo antes de la corta:
     * orden físico correcto = parte N (bit 0x40) más lejos ... parte 1
     * junto a la entrada corta (v1.4.1: antes quedaban al revés) */
    if (need_lfn && dirent_off >= 32 * ((strlen(name) + 12) / 13)) {
        u32 nl = (u32)((strlen(name) + 12) / 13);
        u32 nmlen = (u32)strlen(name);
        u8 lsec[512];
        if (fsec_read(dirent_sec, lsec) == 0) {
            u8 cs = lfn_checksum(short11_cmp);
            static const u32 offs[13] = { 1,3,5,7,9,14,16,18,20,22,24,28,30 };
            for (u32 j = 0; j < nl; j++) {       /* j = ranura hacia atrás */
                u8 *l = lsec + dirent_off - 32 * (nl - j);
                u32 part = nl - j;               /* parte del nombre */
                u8 seq = (u8)part;
                if (j == 0) seq |= 0x40;         /* la más lejos = parte N */
                memset(l, 0, 32);
                l[0] = seq;
                l[11] = ATTR_LFN;
                l[12] = 0;
                l[13] = cs;
                for (int k = 0; k < 13; k++) {
                    u32 ci = (part - 1) * 13 + (u32)k;
                    u16 ch = 0xFFFF;
                    if (ci < nmlen) ch = (u16)(u8)name[ci];
                    else if (ci == nmlen) ch = 0x0000;
                    l[offs[k]] = (u8)(ch & 0xFF);
                    l[offs[k] + 1] = (u8)(ch >> 8);
                }
            }
            if (fsec_write(dirent_sec, lsec) != 0) {
                fat_free_chain(chain);
                return -1;
            }
        }
    }

    /* escribir la entrada corta */
    u8 dsec[512];
    if (fsec_read(dirent_sec, dsec) != 0) {
        fat_free_chain(chain);
        return -1;
    }
    memcpy(dsec + dirent_off, newent, 32);
    if (fsec_write(dirent_sec, dsec) != 0) {
        fat_free_chain(chain);
        return -1;
    }
    fat_cache_invalidate();
    klogf(LOG_INFO, "FAT", "escrito '%s': %lu bytes en %u clusters", name, len, nclus);
    return 0;
}

/* ---------------- borrar archivo ---------------- */
int fat_delete_file(const char *name) {
    if (!fat_ok) return -1;
    FindUd f;
    if (dir_find(name, &f) != 0) return -1;
    if (f.entry[11] & ATTR_DIR) return -2;
    u32 clus = ((u32)f.entry[20] << 24) | ((u32)f.entry[21] << 16) |
               (u32)f.entry[26] | ((u32)f.entry[27] << 8);
    if (clus >= 2) fat_free_chain(clus);
    u8 dsec[512];
    if (fsec_read(f.sec_abs, dsec) != 0) return -1;
    dsec[f.off] = 0xE5;
    if (fsec_write(f.sec_abs, dsec) != 0) return -1;
    /* borrar también las LFN que la preceden */
    u32 back = 32;
    while (f.off >= back) {
        u8 e = dsec[f.off - back];
        if (e == 0x00 || e == 0xE5) break;
        /* releyendo tras la marca: leer de nuevo el sector fresco */
        if (fsec_read(f.sec_abs, dsec) != 0) break;
        if (dsec[f.off - back + 11] != ATTR_LFN) break;
        dsec[f.off - back] = 0xE5;
        if (fsec_write(f.sec_abs, dsec) != 0) break;
        back += 32;
    }
    fat_cache_invalidate();
    klogf(LOG_INFO, "FAT", "borrado '%s'", name);
    return 0;
}
