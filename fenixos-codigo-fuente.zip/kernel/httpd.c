/* FenixOS — httpd.c: servidor web de FenixOS (v1.4)
 *
 * Tarea del kernel que escucha en el puerto TCP 80 y sirve una página
 * de estado del sistema en HTML. Se activa con 'servidor on' y se
 * detiene con 'servidor off'. Desde el anfitrión (con redirección de
 * puertos en QEMU o NAT en VirtualBox) un navegador real puede ver la
 * página servida por FenixOS: demostración de sockets de servidor.
 *
 * Sobre el socket TCP minimal de net.c (una conexión a la vez): el
 * servidor atiende peticiones de forma secuencial, como los primeros
 * servidores web de la historia. */
#include "fenixos.h"

static int httpd_task_id = -1;
static u32 httpd_served = 0;
static volatile int httpd_port = 80;

u32 httpd_served_count(void) { return httpd_served; }
int httpd_active(void) { return httpd_task_id >= 0; }

/* ---------------- página de estado ---------------- */
static u32 build_page(char *pg, u32 cap, const char *path) {
    u32 o = 0;
    u64 secs = pit_ticks / 100;
    u64 mb_used = pmm_used_pages * PAGE_SIZE / (1024u * 1024u);
    u64 mb_total = pmm_total_pages * PAGE_SIZE / (1024u * 1024u);
    char ipb[16];
    net_ip_str(net_my_ip(), ipb, sizeof(ipb));
    int not_found = strcmp(path, "/") != 0 && strcmp(path, "/info") != 0 &&
                    strcmp(path, "/index.html") != 0;

    o += (u32)ksnprintf(pg + o, cap - o,
        "HTTP/1.1 %d %s\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Connection: close\r\n"
        "Server: FenixHTTPd/1.4\r\n", not_found ? 404 : 200,
        not_found ? "Not Found" : "OK");
    /* el Content-Length se rellena al final: reservar hueco */
    u32 cl_off = o;
    o += (u32)ksnprintf(pg + o, cap - o, "Content-Length: %09u\r\n\r\n", 0);
    u32 hdr_len = o;

    if (not_found) {
        o += (u32)ksnprintf(pg + o, cap - o,
            "<html><head><title>FenixOS 404</title></head><body>"
            "<h1>404 - no encontrado</h1>"
            "<p>FenixOS solo sirve <a href='/'>/</a> y /info</p>"
            "</body></html>");
    } else {
        o += (u32)ksnprintf(pg + o, cap - o,
        "<!DOCTYPE html><html><head><meta charset='utf-8'>"
        "<title>FenixOS %s - FenixHTTPd</title></head>"
        "<body style='background:#10141c;color:#e6edf3;"
        "font-family:monospace;max-width:720px;margin:40px auto'>"
        "<h1 style='color:#ff9f43'>FenixOS 1.4 &quot;Faro&quot;</h1>"
        "<p>Servidor web funcionando DENTRO de FenixOS, un sistema "
        "operativo hecho desde cero (bootloader propio, kernel x86_64 "
        "propio, GUI propia y ahora sockets de servidor).</p>"
        "<h2 style='color:#7ee787'>Estado del sistema</h2><pre>", config_hostname());
        o += (u32)ksnprintf(pg + o, cap - o,
        "hostname   : %s\n"
        "usuario    : %s (rol %s)\n"
        "encendido  : %lu min %lu seg\n"
        "RAM        : %lu MB / %lu MB\n"
        "tareas     : %d activas\n"
        "IP         : %s (e1000)\n"
        "peticiones : %u servidas\n",
        config_hostname(), user_current_name(), role_name(user_current_role()),
        secs / 60, secs % 60, mb_used, mb_total, task_count_alive(),
        ipb, httpd_served + 1);
        o += (u32)ksnprintf(pg + o, cap - o, "</pre>\n"
        "<h2 style='color:#7ee787'>Archivos (RAMFS)</h2><pre>");
        int shown = 0;
        for (int i = 0; i < ramfs_slots() && shown < 10; i++) {
            const char *nm; u32 sz;
            if (!ramfs_get(i, &nm, &sz)) continue;
            o += (u32)ksnprintf(pg + o, cap - o, "  %-20s %lu bytes\n", nm, sz);
            shown++;
        }
        if (!shown) o += (u32)ksnprintf(pg + o, cap - o, "  (vacio)\n");
        o += (u32)ksnprintf(pg + o, cap - o, "</pre>\n");
        if (fat_present()) {
            o += (u32)ksnprintf(pg + o, cap - o,
            "<h2 style='color:#7ee787'>Disco FAT32: %s</h2><pre>", fat_label());
            int nf = fat_dir_count();
            for (int i = 0; i < nf && i < 10; i++) {
                char nm[128]; u32 sz; int isd;
                if (fat_dir_get(i, nm, sizeof(nm), &sz, &isd) != 0) continue;
                o += (u32)ksnprintf(pg + o, cap - o, "  %-28s %s%lu\n",
                          nm, isd ? "&lt;DIR&gt;      " : "", sz);
            }
            o += (u32)ksnprintf(pg + o, cap - o, "</pre>\n");
        }
        o += (u32)ksnprintf(pg + o, cap - o,
        "<hr><p style='color:#8b949e'>FenixOS 1.4 &quot;Faro&quot; · "
        "kernel fenix-kernel 1.4.0 · FenixHTTPd responde desde el kernel, "
        "sin procesos de usuario.</p></body></html>");
    }

    /* rellenar el Content-Length real (cuerpo = o - hdr_len) */
    {
        char cl[24];
        ksnprintf(cl, sizeof(cl), "%09u", o - hdr_len);
        memcpy(pg + cl_off + 16, cl, 9);
    }
    return o;
}

/* ---------------- tarea del servidor ---------------- */
void httpd_task(void) {
    for (;;) {
        if (!net_ready()) { pit_sleep_ticks(100); continue; }
        if (net_tcp_listen((u16)httpd_port) != 0) { pit_sleep_ticks(100); continue; }
        klogf(LOG_INFO, "HTTPD", "escuchando en puerto %u", (u32)httpd_port);

        for (;;) {
            int a = net_tcp_accept_wait(500);          /* 5 s por intento */
            if (a == -2 || a == -3) break;             /* listener robado: re-armar */
            if (a != 0) continue;

            /* ---- conexión establecida: recibir la petición ---- */
            char *req = (char *)kmalloc(4096);
            char *pg = (char *)kmalloc(20000);
            if (!req || !pg) {
                if (req) kfree(req);
                if (pg) kfree(pg);
                net_tcp_close();
                continue;
            }
            u32 got = 0;
            u64 deadline = pit_ticks + 200;            /* 2 s */
            int have_hdr = 0;
            while (got < 4090) {
                char tmp[1024];
                int n = net_tcp_recv(tmp, sizeof(tmp), 100);
                if (n > 0) {
                    u32 c = (u32)n;
                    if (got + c >= 4090) c = 4090 - got;
                    memcpy(req + got, tmp, c);
                    got += c;
                    req[got] = 0;
                    if (strstr(req, "\r\n\r\n")) { have_hdr = 1; break; }
                    continue;
                }
                if (n == 0) break;                     /* fin */
                if (pit_ticks >= deadline) break;
            }

            char path[128];
            int ok = have_hdr && !strncmp(req, "GET ", 4);
            if (ok) {
                const char *p = req + 4;
                u32 pi = 0;
                while (*p && *p != ' ' && pi < sizeof(path) - 1) path[pi++] = *p++;
                path[pi] = 0;
            } else {
                strcpy(path, "/");
            }
            klogf(LOG_INFO, "HTTPD", "GET %s (%lu bytes de peticion)", path, got);

            u32 plen = build_page(pg, 20000, path);
            int sr = net_tcp_send(pg, plen);
            klogf(LOG_INFO, "HTTPD", "respuesta %u bytes (%s), peticion #%u",
                  plen, sr == 0 ? "enviada" : "fallo", httpd_served + 1);
            net_tcp_close();
            kfree(req);
            kfree(pg);
            httpd_served++;
            /* volver a escuchar de inmediato */
        }
    }
}

/* ---------------- control desde la shell ---------------- */
int httpd_start(void) {
    if (httpd_active()) return -2;                 /* ya activo */
    if (!net_ready()) return -1;
    httpd_served = 0;
    int id = task_create("httpd", httpd_task, 1);
    if (id < 0) return -3;
    httpd_task_id = id;
    klogf(LOG_INFO, "HTTPD", "servidor iniciado (tarea %d, puerto %u)",
          id, (u32)httpd_port);
    return 0;
}

int httpd_stop(void) {
    if (!httpd_active()) return -2;
    task_kill(httpd_task_id);
    if (net_ready() && net_tcp_listening()) tcb_force_reset();
    httpd_task_id = -1;
    klog("HTTPD", "servidor detenido");
    return 0;
}
