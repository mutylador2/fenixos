; =====================================================================
; FenixOS Bootloader — MBR para ISO HÍBRIDO (v1.3)
;
; fenixos.iso es a la vez:
;   - un CD booteable (El Torito sin emulación: la BIOS carga el blob)
;   - una imagen de disco USB booteable (Rufus en modo DD, o dd)
;
; Al arrancar por USB, la BIOS ejecuta ESTE MBR (escrito por
; build_iso.py en el byte 0 del ISO). El blob de arranque (stub CD +
; stage2 + kernel) vive dentro del ISO en el sector de 2KB 'B'; en
; unidades de 512 B ese sector equivale a 4*LBA:
;     stage2  : 4B + 1
;     kernel  : 4B + 41   (offset 512 + 20480 dentro del blob)
; El MBR carga stage2 (40 sectores) a 0x7E00, le pasa el LBA del
; kernel en 0x0530 (ruta ISO híbrido de stage2) y salta.
;
; build_iso.py parchea el marcador HYEMLB con el LBA del blob tras
; generar el ISO (4 bytes little-endian, base de 512 B).
; =====================================================================
BITS 16
ORG 0x7C00

STAGE2_SECTORS equ 40

start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00

    mov [0x0524], dl             ; unidad de arranque
    mov byte [0x0528], 0         ; modo lectura: LBA
    mov dword [0x052C], 0        ; banderas a cero
    mov eax, [hyb_kernel_lba]
    mov [0x0530], eax            ; LBA absoluto del kernel (ruta híbrido)
    mov dword [0x0534], 0        ; sin partición (ISO)
    mov dword [0x0538], 0        ; tamaño desconocido

    mov eax, [hyb_stage2_lba]
    mov [dap_lba], eax

    ; ---- intento 1: lectura extendida LBA (AH=42h, 40 sectores) ----
    mov si, dap
    mov ah, 0x42
    mov dl, [0x0524]
    int 0x13
    jnc loaded

    ; ---- intento 2: CHS clásico (AH=08h + AH=02h por sector) ----
    mov byte [0x0528], 1
    mov ah, 0x08
    mov dl, [0x0524]
    int 0x13
    jc disk_err
    mov al, cl
    and al, 0x3F
    mov [spt], al
    mov [heads], dh
    inc byte [heads]

    xor di, di
    mov bp, [dap_lba]
.rd:
    mov ax, di
    add ax, bp
    xor dx, dx
    mov cl, [spt]
    xor ch, ch
    div cx
    mov bx, dx
    inc bx
    push bx
    xor dx, dx
    mov cl, [heads]
    xor ch, ch
    div cx
    pop bx
    mov dh, dl
    mov ch, al
    mov cl, bl
    push ax
    mov al, ah
    and al, 0x03
    shl al, 6
    or cl, al
    pop ax
    mov si, cx
    mov bx, di
    mov cl, 9
    shl bx, cl
    mov cx, si
    mov ah, 0x02
    mov al, 1
    mov dl, [0x0524]
    int 0x13
    jc disk_err
    inc di
    cmp di, STAGE2_SECTORS
    jb .rd

loaded:
    xor ax, ax
    mov ds, ax
    jmp 0x0000:0x7E00

disk_err:
    mov si, msg_disk
    call print
    jmp halt

pchar:
    push ax
    push bx
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    pop bx
    pop ax
    ret

print:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp print
.done:
    ret

halt:
    hlt
    jmp halt

spt:   db 0
heads: db 0
msg_disk: db "[Fenix] Error leyendo el USB", 0

dap:
    db 0x10
    db 0
    dw STAGE2_SECTORS
    dw 0x7E00
    dw 0x0000
dap_lba: dq 1                   ; parcheado en runtime desde hyb_stage2_lba

; ---- datos parcheados por build_iso.py (LBA de 512 B) ----
hyb_blob_lba:   dd 0xDEADBEEF   ; marcador HYEMLB: sector 2KB del blob /4
hyb_stage2_lba: dd 0xDEADBEE1   ; marcador HYEML2: hyb_blob_lba + 1
hyb_kernel_lba: dd 0xDEADBEE2   ; marcador HYEMLK: hyb_blob_lba + 41

times 446-($-$$) db 0

; ---- tabla de particiones "híbrida" (cosmética, estilo isohybrid) ----
; entrada 1: cubre todo el ISO, tipo oculto, arrancable
db 0x80                         ; arrancable
db 0x00, 0x01, 0x00             ; CHS inicio (aprox.)
db 0x17                         ; tipo: partición oculta (ISO híbrido)
db 0xFE, 0xFF, 0xFF             ; CHS fin (máximo)
dd 0                            ; LBA inicial
dd 0x00FFFFFF                   ; sectores (build_iso lo ajusta)
times 446+64-($-$$) db 0
dw 0xAA55
