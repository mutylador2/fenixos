; =====================================================================
; FenixOS Bootloader — Etapa 1 v1.3 (MBR, 512 bytes)
; Carga la etapa 2 (40 sectores) a 0x7E00 y salta a ella.
;
; Novedad v1.3 — CONVIVENCIA con otros sistemas operativos:
;   al arrancar desde un disco con tabla de particiones, busca una
;   partición de tipo 0x63 (FenixOS) y carga stage2 desde su inicio
;   (LBA de la partición + 1). Las demás particiones (Windows, Linux)
;   NO se tocan y el menú multiboot de stage2 puede encadenarlas.
;   Sin tabla de particiones (disco entero / imagen v1.x): stage2 se
;   carga del LBA 1 como siempre.
;
; Convención de memoria baja para stage2:
;   0x0524 unidad de arranque (DL, ya lo hacía la v1.0)
;   0x0528 modo de lectura: 0 = LBA extendida, 1 = CHS clásica
;          (la unidad emulada de SeaBIOS solo acepta comandos clásicos;
;          el BIOS reporta la geometría desde la entrada de partición
;          del propio MBR, por eso el área 446..509 debe quedar coherente)
;   0x052C dword de banderas (stage2 lo gestiona)
;   0x0530 LBA absoluto del kernel (ISO híbrido; aquí 0 = no aplica)
;   0x0534 LBA inicial de la partición FenixOS (0 = disco entero)
;   0x0538 nº de sectores de la partición FenixOS
;
; IMPORTANTE: mantener este fichero COMPACTO — el código y los datos
; no deben invadir los bytes 446..509 (tabla de particiones), que
; build_image.py rellena con la partición FenixOS y genisoimage exige
; limpia en el MBR del blob del CD.
; =====================================================================
BITS 16
ORG 0x7C00

STAGE2_SECTORS equ 40
PART_FENIX     equ 0x63

start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00

    mov [0x0524], dl             ; unidad de arranque -> bootinfo.boot_drive
    mov byte [0x0528], 0         ; modo lectura: LBA
    mov dword [0x052C], 0        ; banderas de arranque a cero
    mov dword [0x0530], 0        ; sin LBA absoluto de kernel (no híbrido)
    mov dword [0x0534], 0        ; por defecto: instalación de disco entero
    mov dword [0x0538], 0        ; tamaño desconocido (stage2 lo sondea)

    ; ---- buscar la partición FenixOS (tipo 0x63) en nuestra propia MBR ----
    ; la BIOS nos cargó en 0x7C00 con la tabla intacta; la pila crece
    ; hacia abajo, así que la zona 0x7DBE..0x7DFE (tabla en 0x7C00+446)
    ; sigue legible.
    mov si, 0x7DBE               ; 0x7C00 + 446 (inicio de la tabla)
    mov cx, 4
.scan:
    cmp byte [si+4], PART_FENIX
    je .found
    add si, 16
    loop .scan
    jmp load_st2                 ; sin partición: disco entero (LBA 1)
.found:
    mov eax, [si+8]              ; LBA inicial de la partición
    mov [0x0534], eax
    mov eax, [si+12]             ; nº de sectores de la partición
    mov [0x0538], eax

load_st2:
    ; LBA de stage2 = base + 1  (tras el sector de arranque de la partición)
    mov eax, [0x0534]
    inc eax
    mov [dap_lba], eax

    ; ---- intento 1: lectura extendida LBA (AH=42h, 40 sectores) ----
    mov si, dap
    mov ah, 0x42
    mov dl, [0x0524]
    int 0x13
    jnc loaded

    ; ---- intento 2: CHS clásico (AH=08h geometría + AH=02h por sector)
    mov byte [0x0528], 1
    mov ah, 0x08
    mov dl, [0x0524]
    int 0x13
    jc disk_err
    mov al, cl
    and al, 0x3F
    mov [spt], al                ; sectores por pista (CL bits 0-5)
    mov [heads], dh
    inc byte [heads]             ; DH = máximo head -> heads = DH+1

    xor di, di                   ; DI = índice de sector (0..39)
    mov bp, [dap_lba]            ; BP = LBA base de stage2 (palabra baja)
.rd:
    mov ax, di
    add ax, bp                   ; AX = LBA del sector (base + índice)
    xor dx, dx
    mov cl, [spt]
    xor ch, ch
    div cx                       ; AX = LBA/SPT, DX = sector-1
    mov bx, dx
    inc bx                       ; BX = sector (1..SPT)
    push bx
    xor dx, dx
    mov cl, [heads]
    xor ch, ch
    div cx                       ; AX = cilindro, DX = head
    pop bx
    mov dh, dl                   ; DH = head
    mov ch, al                   ; CH = cilindro (bits 0-7)
    mov cl, bl                   ; CL = sector (bits 0-5)
    push ax
    mov al, ah
    and al, 0x03
    shl al, 6                    ; AL = cilindro bits 8-9 en CL bits 6-7
    or cl, al
    pop ax
    mov si, cx                   ; conservar CH:CL
    mov bx, di
    mov cl, 9
    shl bx, cl                   ; BX = DI*512 -> destino 0x7E00 + DI*512
    mov cx, si
    mov ah, 0x02                 ; lectura clásica, 1 sector
    mov al, 1
    mov dl, [0x0524]
    int 0x13
    jc disk_err
    inc di
    cmp di, STAGE2_SECTORS
    jb .rd

loaded:
    xor ax, ax
    mov ds, ax
    jmp 0x0000:0x7E00

disk_err:
    mov si, msg_disk
    call print
    jmp halt

pchar:
    push ax
    push bx
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    pop bx
    pop ax
    ret

print:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp print
.done:
    ret

halt:
    hlt
    jmp halt

spt:   db 0
heads: db 0
msg_disk: db "[Fenix] Error leyendo disco", 0

; ---- Disk Address Packet (lectura LBA de la etapa 2) ----
dap:
    db 0x10                     ; tamaño
    db 0                        ; reservado
    dw STAGE2_SECTORS           ; nº sectores
    dw 0x7E00                   ; offset destino
    dw 0x0000                   ; segmento destino
dap_lba: dq 1                   ; LBA inicial (base+1; lo recalcula stage1)

times 436-($-$$) db 0           ; margen de seguridad antes de la tabla (446)

; 446..509: zona de la tabla de particiones — stage1 NO la escribe;
; build_image.py instala ahí la partición FenixOS (tipo 0x63) y el
; instalador del kernel preserva las ajenas (Windows/Linux).
times 510-($-$$) db 0
dw 0xAA55                       ; firma de sector de arranque (offset 510)
