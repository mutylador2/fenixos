; =====================================================================
; FenixOS Bootloader — Etapa 2 v1.3 (0x7E00, 40 sectores)
;  1. Mapa de memoria e820 -> 0x0700 (máx 48 entradas, paso 24 bytes)
;  2. MENÚ MULTIBOOT (solo al arrancar desde disco/USB):
;     1) FenixOS  2) modo seguro  3) otro SO de este disco (chainload)
;     4) otro disco  5) información del sistema
;     Opción por defecto y timeout se leen del sector de configuración
;     LBA part_base+41 (firma 'FNXBOOT1'), reescribible por el kernel
;     (persistencia de la configuración de arranque).
;  3. Modo gráfico VBE con framebuffer lineal (preferencia 1024x768x32)
;  4. Carga del kernel:
;     - CD (modo 2): el kernel ya está en el blob (tras stage2)
;     - ISO híbrido por USB: 0x0530 = LBA absoluto del kernel (lo fija
;       el MBR híbrido tras localizar el blob dentro del ISO)
;     - disco: LBA part_base + 128 (partición FenixOS o disco entero)
;  5. Tablas de página: identidad 1GB (2MB) + 1GB del framebuffer
;     (ese GB también cubre el MMIO PCI de la e1000 y del AHCI)
;  6. Modo protegido -> copiar kernel a 0x100000 -> modo largo 64-bit
;  7. Salto al kernel con RDI = 0x0500 (BootInfo)
;
; Convención de memoria baja compartida con stage1:
;   0x0524 unidad de arranque BIOS (DL)
;   0x0528 modo de lectura (0 LBA, 1 CHS, 2 CD-blob)
;   0x052C dword de banderas (bit0 modo seguro; bit1 arranque desde CD)
;   0x0530 LBA absoluto del kernel (ISO híbrido; lo fija el MBR híbrido)
;   0x0534 base de la partición FenixOS (lo fija stage1; 0 = disco entero)
;   0x0538 sectores de la partición (o del disco, vía AH=48h)
; =====================================================================
BITS 16
ORG 0x7E00

%ifndef STAGE2_PAD
%define STAGE2_PAD 20480            ; 40 sectores por defecto
%endif
%ifndef KERNEL_SECTORS
%define KERNEL_SECTORS 320
%endif
%ifndef KERNEL_DWORDS
%define KERNEL_DWORDS 40000
%endif

BOOTINFO    equ 0x0500
E820_BUF    equ 0x0700
E820_MAX    equ 48
VBE_INFO    equ 0x0C00
MODE_INFO   equ 0x0E00
DAP         equ 0x0F40
MBR_SCRATCH equ 0x6000            ; copia del MBR para chainload
BOOTCFG_BUF equ 0x7800            ; sector de config del gestor (512 B)
PML4        equ 0x1000
PDPT        equ 0x2000
PD_LO       equ 0x3000
PD_FB       equ 0x4000
KBUF        equ 0x40000
KLOAD       equ 0x100000
KSTACK      equ 0x90000
KERNEL_BLOB_SEG equ (0x7C00 + 512 + STAGE2_PAD) / 16

start:
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00

    mov si, msg_hello
    call print
    jmp a20                              ; ¡no caer dentro de trace_char!

; ---------------------------------------------------------------------
; Depuración por puerto serie COM1 (trace: A=a20 M=mapa m=ok V=vbe...)
; ---------------------------------------------------------------------
trace_char:
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    push ax
    mov dx, 0x3F8                        ; COM1 (SeaBIOS la deja usable)
    out dx, al
    pop ax
    ret

; ---------------------------------------------------------------------
; A20 (rápida + intento BIOS alternativo)
; ---------------------------------------------------------------------
a20:
    mov al, 'A'
    call trace_char
    in al, 0x92
    mov al, 'B'
    call trace_char
    in al, 0x92
    or al, 0x02
    and al, 0xFE
    out 0x92, al
    mov al, 'C'
    call trace_char
    mov ax, 0x2401
    int 0x15                             ; ignorar resultado
    mov al, 'D'
    call trace_char

; ---------------------------------------------------------------------
; Mapa de memoria e820
; ---------------------------------------------------------------------
do_e820:
    mov di, E820_BUF
    xor ebx, ebx
    mov word [e820_count], 0
    sti                                  ; el BIOS puede requerir IF=1
.e820_loop:
    mov eax, 0xE820
    mov edx, 0x534D4150                  ; 'SMAP'
    mov ecx, 24
    int 0x15
    jnc .e820_cfok
    mov al, 'C'                          ; CF activo
    call trace_char
    jmp .e820_fail
.e820_cfok:
    cmp eax, 0x534D4150
    je .e820_sigok
    mov al, 'S'                          ; firma incorrecta
    call trace_char
    jmp .e820_fail
.e820_sigok:
    inc word [e820_count]
    add di, 24
    cmp di, E820_BUF + E820_MAX*24
    jae .e820_done
    test ebx, ebx
    jz .e820_done
    jmp .e820_loop
.e820_fail:
    mov si, err_mem
    call print
    jmp halt
.e820_done:
    mov al, 'm'
    call trace_char
    cmp word [e820_count], 0
    je .e820_fail

; ---------------------------------------------------------------------
; Tamaño del disco de arranque cuando no hay partición (disco entero):
; AH=48h devuelve el total de sectores -> 0x0538 (0 si no disponible).
; ---------------------------------------------------------------------
probe_disk_size:
    cmp dword [0x0534], 0                ; ¿instalación con partición?
    jne .pd_done                         ; sí: stage1 ya tomó el tamaño del MBR
    cmp byte [0x0528], 2                 ; CD: no hay disco que sondear
    je .pd_done
    mov word [dap48], 0x1E               ; tamaño del buffer
    mov si, dap48
    mov ah, 0x48
    mov dl, [0x0524]
    int 0x13
    jc .pd_done
    mov eax, [dap48+0x10]                ; sectores totales (qword, bajo)
    mov [0x0538], eax
.pd_done:

; =====================================================================
; MENÚ MULTIBOOT — solo cuando se arranca desde disco/USB (modo 0/1).
; En CD el kernel ya está en RAM y se arranca directo (la unidad
; cdemu de SeaBIOS no permite lecturas fiables para chainload).
; =====================================================================
menu:
    cmp byte [0x0528], 2
    je vbe_start                         ; CD: sin menú, directo
    mov dword [0x052C], 0                ; banderas a cero (modo seguro por tecla)
    call read_bootcfg                    ; opción por defecto + timeout

.menu_show:
    mov si, menu_hdr
    call print
    mov si, menu_items
    call print
    mov si, menu_def1
    call print
    mov ah, 0x03
    xor bh, bh
    int 0x10                             ; DX = posición del contador
    mov [cnt_row], dh
    mov [cnt_col], dl
    mov si, menu_def2
    call print
    mov al, [def_opt]
    add al, '0'
    call pchar16
    mov si, menu_def3
    call print

.menu_wait:
    mov ah, 0x01
    int 0x16
    jnz .menu_key
    mov eax, [0x046C]                    ; ticks del BIOS (18.2/s)
    cmp eax, [deadline]
    jae .menu_timeout
    mov ebx, [deadline]
    sub ebx, eax
    shr ebx, 4                           ; /16 ≈ segundos (redondeo por arriba)
    inc ebx
    ; reescribir el contador en su posición
    push ebx
    mov ah, 0x02
    xor bh, bh
    mov dh, [cnt_row]
    mov dl, [cnt_col]
    int 0x10
    pop eax
    call print_dec
    mov al, ' '
    call pchar16
    mov al, ' '
    call pchar16
    jmp .menu_wait
.menu_timeout:
    mov si, crlf
    call print
    mov al, [def_opt]
    cmp al, 1
    je .t_go
    cmp al, 2
    je .t_go
    mov al, 1                            ; defecto 3-5: arrancar FenixOS normal
.t_go:
    call menu_dispatch
    jmp vbe_start
.menu_key:
    mov ah, 0x00
    int 0x16
    push ax                             ; print (crlf) devuelve AL=último
    mov si, crlf                        ; carácter en AL: preservar la tecla
    call print
    pop ax
    cmp al, '1'
    jb .menu_show
    cmp al, '5'
    ja .menu_show
    sub al, '0'
    call menu_dispatch
    jmp vbe_start                        ; opción 1/2 -> continuar arranque

; menu_dispatch: AL = opción (1..5). 1/2 preparan y REGRESAN; 3/4
; saltan a otro sistema; 5 muestra info y vuelve al menú por sí sola.
menu_dispatch:
    cmp al, 1
    je .d1
    cmp al, 2
    je .d2
    cmp al, 3
    je chain_part
    cmp al, 4
    je chain_disk
    cmp al, 5
    je menu_info
    ret
.d1:
    mov byte [safe_mode], 0
    ret
.d2:
    mov byte [safe_mode], 1
    or dword [0x052C], 1                 ; bandera modo seguro -> kernel
    ret

; ---------------------------------------------------------------------
; read_bootcfg: lee el sector de configuración del gestor de arranque
; (LBA part_base+41) vía AH=42h. Sin firma válida: valores por defecto
; (opción 1, 8 segundos).
; ---------------------------------------------------------------------
read_bootcfg:
    mov byte [def_opt], 1
    mov byte [tmo_secs], 8
    mov eax, [0x0534]
    add eax, 41
    mov dword [bc_dap+8], eax
    mov si, bc_dap
    mov ah, 0x42
    mov dl, [0x0524]
    int 0x13
    jc .rb_defaults
    cmp dword [BOOTCFG_BUF], 'FNXB'      ; 'FNXBOOT1'
    jne .rb_defaults
    cmp dword [BOOTCFG_BUF+4], 'OOT1'
    jne .rb_defaults
    mov al, [BOOTCFG_BUF+8]
    cmp al, 1
    jb .rb_defaults
    cmp al, 5
    ja .rb_defaults
    mov [def_opt], al
    mov al, [BOOTCFG_BUF+9]
    mov [tmo_secs], al
    jmp .rb_arm
.rb_defaults:
    mov byte [def_opt], 1
    mov byte [tmo_secs], 8
.rb_arm:
    ; deadline = ticks actuales + timeout*18.2
    movzx eax, byte [tmo_secs]
    mov ebx, 18
    mul ebx
    add eax, 12                          ; redondeo (18.2 ticks/s)
    add eax, [0x046C]
    mov [deadline], eax
    ret

; ---------------------------------------------------------------------
; chain_part (opción 3): lista las particiones del disco de arranque y
; transfiere el control al sector de arranque (VBR) de la elegida.
; Windows/Linux siguen arrancando: NO se escribe ni un byte del disco.
; ---------------------------------------------------------------------
chain_part:
    mov dword [rd_dap+8], 0              ; LBA 0 = MBR
    mov word [rd_dap+2], 1
    mov word [rd_dap+4], MBR_SCRATCH
    mov word [rd_dap+6], 0
    call rd_lba_boot
    jc chain_fail
    mov si, cp_hdr
    call print
    mov bp, MBR_SCRATCH + 446
    mov byte [cp_idx], 1
.cp_list:
    cmp byte [bp+4], 0
    je .cp_next
    mov al, [cp_idx]
    add al, '0'
    call pchar16
    mov si, cp_sep
    call print
    mov al, [bp+4]
    call cp_typename
    mov si, cp_sizepre
    call print
    mov eax, [bp+12]
    shr eax, 11                          ; sectores/512 -> MB
    call print_dec
    mov si, cp_mb
    call print
    test byte [bp], 0x80
    jz .cp_nonl
    mov si, cp_active
    call print
    jmp .cp_next
.cp_nonl:
    mov si, crlf
    call print
.cp_next:
    inc byte [cp_idx]
    add bp, 16
    cmp byte [cp_idx], 5
    jb .cp_list
.cp_ask:
    mov si, cp_ask
    call print
    mov ah, 0x00
    int 0x16
    push ax                             ; preservar la tecla (print la pisa)
    mov si, crlf
    call print
    pop ax
    sub al, '0'
    jc .cp_back
    cmp al, 1
    jb .cp_back
    cmp al, 4
    ja .cp_back
    mov [cp_sel], al
    mov bp, MBR_SCRATCH + 446
    mov byte [cp_idx], 1
.cp_find:
    cmp byte [bp+4], 0
    je .cp_skip
    mov al, [cp_idx]
    cmp al, [cp_sel]
    je .cp_go
.cp_skip:
    add bp, 16
    inc byte [cp_idx]
    cmp byte [cp_idx], 4
    jbe .cp_find
    jmp .cp_back
.cp_go:
    cmp byte [bp+4], 0xEE
    je chain_gpt
    mov eax, [bp+8]                      ; LBA inicial de la partición
    mov dword [rd_dap+8], eax
    mov word [rd_dap+2], 1
    mov word [rd_dap+4], 0x7C00
    mov word [rd_dap+6], 0
    call rd_lba_boot
    jc chain_fail
    call chain_jump                      ; DL = disco de arranque
.cp_back:
    jmp menu.menu_show
chain_gpt:
    mov si, cp_gpt
    call print
    mov ah, 0x00
    int 0x16
    jmp menu.menu_show
chain_fail:
    mov si, cp_fail
    call print
    mov ah, 0x00
    int 0x16
    jmp menu.menu_show

; cp_typename: AL = tipo de partición; imprime un nombre corto
cp_typename:
    push si
    mov si, t_unk
    cmp al, 0x07
    jne .t1
    mov si, t_ntfs
    jmp .out
.t1:
    cmp al, 0x0B
    je .tf
    cmp al, 0x0C
    je .tf
    cmp al, 0x06
    je .tf
    cmp al, 0x0E
    jne .t2
.tf:
    mov si, t_fat
    jmp .out
.t2:
    cmp al, 0x83
    jne .t3
    mov si, t_linux
    jmp .out
.t3:
    cmp al, 0x82
    jne .t4
    mov si, t_swap
    jmp .out
.t4:
    cmp al, 0xEF
    jne .t5
    mov si, t_efi
    jmp .out
.t5:
    cmp al, 0x63
    jne .out
    mov si, t_fenix
.out:
    call print
    pop si
    ret

; ---------------------------------------------------------------------
; chain_disk (opción 4): lista los discos del BIOS y transfiere el
; control al sector 0 del elegido (USB, segundo disco, ...).
; ---------------------------------------------------------------------
chain_disk:
    mov si, cd_hdr
    call print
    mov byte [cd_idx], 0x80
.cd_list:
    mov ah, 0x08
    mov dl, [cd_idx]
    int 0x13
    jc .cd_next
    mov al, [cd_idx]
    and al, 0x7F
    add al, '0'
    call pchar16
    mov si, cd_sep
    call print
    ; tamaño aproximado: cilindros x cabezas x spt / 2048 MB
    movzx ecx, cx
    and ecx, 0xC000                      ; bits 8-9 del cilindro
    shr ecx, 14
    movzx ebx, ch                        ; bits 0-7 del cilindro
    mov eax, ecx
    shl eax, 8
    or eax, ebx
    inc eax                              ; nº de cilindros
    mov edi, eax
    movzx eax, dh
    inc eax                              ; cabezas
    imul eax, edi
    movzx ebx, cl
    and ebx, 0x3F                        ; sectores por pista
    imul eax, ebx
    shr eax, 11                          ; MB
    call print_dec
    mov si, cp_mb
    call print
    mov si, crlf
    call print
.cd_next:
    inc byte [cd_idx]
    cmp byte [cd_idx], 0x87
    jbe .cd_list
    mov si, cd_ask
    call print
    mov ah, 0x00
    int 0x16
    push ax                             ; preservar la tecla (print la pisa)
    mov si, crlf
    call print
    pop ax
    cmp al, '0'
    jb .cd_back
    cmp al, '7'
    ja .cd_back
    sub al, '0'
    or al, 0x80
    mov [cd_target], al
    ; leer el sector 0 del disco elegido a 0x7C00
    mov byte [rd_dap], 0x10
    mov byte [rd_dap+1], 0
    mov word [rd_dap+2], 1
    mov word [rd_dap+4], 0x7C00
    mov word [rd_dap+6], 0
    mov dword [rd_dap+8], 0
    mov dword [rd_dap+12], 0
    mov si, rd_dap
    mov ah, 0x42
    mov dl, [cd_target]
    int 0x13
    jnc .cd_go
    ; fallback CHS: cilindro 0, cabeza 0, sector 1
    mov ah, 0x02
    mov al, 1
    mov ch, 0
    mov cl, 1
    mov dh, 0
    mov dl, [cd_target]
    mov bx, 0x7C00
    int 0x13
    jc chain_fail
.cd_go:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    mov dl, [cd_target]
    sti
    jmp 0x0000:0x7C00
.cd_back:
    jmp menu.menu_show

; ---------------------------------------------------------------------
; menu_info (opción 5): pantalla de información en modo texto
; ---------------------------------------------------------------------
menu_info:
    mov si, mi_hdr
    call print
    ; CPU: fabricante (CPUID hoja 0)
    xor eax, eax
    cpuid
    mov eax, ebx
    mov [mi_buf], eax
    mov eax, edx
    mov [mi_buf+4], eax
    mov eax, ecx
    mov [mi_buf+8], eax
    mov byte [mi_buf+12], 0
    mov si, mi_cpu
    call print
    mov si, mi_buf
    call print
    mov si, crlf
    call print
    ; CPU: marca (hojas extendidas 0x80000002..4)
    mov eax, 0x80000000
    cpuid
    cmp eax, 0x80000004
    jb .mi_nobrand
    mov eax, 0x80000002
    cpuid
    mov [mi_buf], eax
    mov [mi_buf+4], ebx
    mov [mi_buf+8], ecx
    mov [mi_buf+12], edx
    mov eax, 0x80000003
    cpuid
    mov [mi_buf+16], eax
    mov [mi_buf+20], ebx
    mov [mi_buf+24], ecx
    mov [mi_buf+28], edx
    mov eax, 0x80000004
    cpuid
    mov [mi_buf+32], eax
    mov [mi_buf+36], ebx
    mov [mi_buf+40], ecx
    mov [mi_buf+44], edx
    mov byte [mi_buf+48], 0
    mov si, mi_cpu
    call print
    mov si, mi_buf
    call print
    mov si, crlf
    call print
.mi_nobrand:
    ; RAM: suma de las regiones e820 utilizables (64 bits)
    mov si, mi_ram
    call print
    xor eax, eax
    xor edx, edx
    mov si, E820_BUF
    mov cx, [e820_count]
.mi_sum:
    cmp dword [si+16], 1                 ; tipo utilizable
    jne .mi_next
    mov ebx, [si]                        ; longitud (baja)
    add eax, ebx
    mov ebx, [si+4]                      ; longitud (alta)
    adc edx, ebx
.mi_next:
    add si, 24
    loop .mi_sum
    mov ecx, 20                          ; EDX:EAX >>= 20 -> MB
.mi_shr:
    shr edx, 1
    rcr eax, 1
    loop .mi_shr
    call print_dec
    mov si, mi_mb
    call print
    ; discos duros detectados por el BIOS
    mov si, mi_disk
    call print
    mov byte [cd_idx], 0x80
.mi_dloop:
    mov ah, 0x08
    mov dl, [cd_idx]
    int 0x13
    jc .mi_dnext
    mov al, [cd_idx]
    call pchar16
    mov al, ' '
    call pchar16
.mi_dnext:
    inc byte [cd_idx]
    cmp byte [cd_idx], 0x87
    jbe .mi_dloop
    mov si, crlf
    call print
    mov si, mi_foot
    call print
    mov ah, 0x00
    int 0x16
    jmp menu.menu_show

; ---------------------------------------------------------------------
; VBE: info general + selección de modo
; ---------------------------------------------------------------------
vbe_start:
do_vbe:
    xor ax, ax
    mov di, VBE_INFO
    mov cx, 256                          ; 512 bytes
    rep stosw
    mov di, MODE_INFO
    mov cx, 128                          ; 256 bytes
    rep stosw

    mov dword [VBE_INFO], 0x32454256     ; 'VBE2'
    mov ax, 0x4F00
    mov di, VBE_INFO
    int 0x10
    cmp ax, 0x004F
    jne vbe_fail
    call vbe_capture_gpu                 ; OEM strings + TotalMemory -> BootInfo
    mov ax, [VBE_INFO+0x0E]
    mov [mlist_off], ax
    mov ax, [VBE_INFO+0x10]
    mov [mlist_seg], ax

    cmp byte [safe_mode], 1
    je .vbe_safe
    ; pasada 1 (normal): 1024x768x32 exacto
    mov byte [pass_bpp], 32
    mov word [pass_w], 1024
    mov word [pass_h], 768
    mov word [pass_maxw], 4096
    mov word [pass_maxh], 4096
    call scan_modes
    test byte [found_any], 1
    jnz vbe_selected
    ; pasada 2: cualquier 32bpp <= 1280x1024
    mov word [pass_maxw], 1280
    mov word [pass_maxh], 1024
    jmp vbe_pass2
.vbe_safe:
    ; modo seguro: máximo 800x600
    mov word [pass_maxw], 800
    mov word [pass_maxh], 600
vbe_pass2:
    mov byte [pass_bpp], 32
    mov word [pass_w], 0
    mov word [pass_h], 0
    call scan_modes
    test byte [found_any], 1
    jnz vbe_selected

    ; pasada 3: cualquier 16bpp <= max
    mov byte [pass_bpp], 16
    mov word [pass_w], 0
    mov word [pass_h], 0
    call scan_modes
    test byte [found_any], 1
    jnz vbe_selected
    jmp vbe_fail

; vbe_capture_gpu: copia OEMVendorName/OEMProductName y TotalMemory del
; bloque VBE_INFO a la BootInfo para el panel Información del Sistema.
vbe_capture_gpu:
    mov ax, [VBE_INFO+0x12]
    mov [BI+0x3C], ax                    ; TotalMemory (unidades de 64KB)
    xor eax, eax
    mov [BI+0x40], eax
    mov [BI+0x44], eax
    mov [BI+0x5C], eax
    mov [BI+0x60], eax
    mov si, [VBE_INFO+0x16]              ; OEMVendorNamePtr (offset)
    mov ax, [VBE_INFO+0x18]              ; (segmento)
    test ax, ax
    jz .vg_prod
    mov fs, ax
    mov di, BI+0x40
    mov cx, 27
.vg_vloop:
    mov al, [fs:si]
    mov [di], al
    inc si
    inc di
    test al, al
    jz .vg_prod
    loop .vg_vloop
    mov byte [di-1], 0
.vg_prod:
    mov si, [VBE_INFO+0x1A]              ; OEMProductNamePtr
    mov ax, [VBE_INFO+0x1C]
    test ax, ax
    jz .vg_done
    mov fs, ax
    mov di, BI+0x5C
    mov cx, 27
.vg_ploop:
    mov al, [fs:si]
    mov [di], al
    inc si
    inc di
    test al, al
    jz .vg_done
    loop .vg_ploop
    mov byte [di-1], 0
.vg_done:
    ret

vbe_selected:
    mov bx, [best_mode]
    or bx, 0x4000                        ; framebuffer lineal
    mov ax, 0x4F02
    int 0x10
    cmp ax, 0x004F
    jne vbe_fail
    mov eax, [best_paddr]
    mov [BI+4], eax                      ; fb_paddr
    mov ax, [best_pitch]
    mov [BI+8], ax                       ; fb_pitch
    mov ax, [best_w]
    mov [BI+0x0C], ax                    ; fb_width
    mov ax, [best_h]
    mov [BI+0x10], ax                    ; fb_height
    mov al, [best_bpp]
    mov [BI+0x14], al                    ; fb_bpp
    jmp load_kernel

vbe_fail:
    mov si, err_vbe
    call print
    jmp halt

; ---------------------------------------------------------------------
; scan_modes: recorre la lista de modos según pass_* y elige el mejor
; ---------------------------------------------------------------------
scan_modes:
    mov byte [found_any], 0
    mov dword [best_score], 0
    mov word [best_mode], 0
    mov si, [mlist_off]
.sm_loop:
    mov ax, [mlist_seg]                  ; recargar FS desde memoria
    mov fs, ax
    mov cx, [fs:si]
    cmp cx, 0xFFFF
    je .sm_done
    add si, 2
    push si
    or cx, 0x4000
    mov ax, 0x4F01
    mov di, MODE_INFO
    int 0x10
    pop si
    cmp ax, 0x004F
    jne .sm_loop
    mov dx, [MODE_INFO]                  ; ModeAttributes
    and dx, 0x91                         ; bit0 soportado | bit4 gráficos | bit7 LFB
    cmp dx, 0x91
    jne .sm_loop
    cmp byte [MODE_INFO+0x1B], 6         ; modelo: direct color
    jne .sm_loop
    mov al, [MODE_INFO+0x19]             ; bpp
    cmp al, [pass_bpp]
    jne .sm_loop
    mov ax, [MODE_INFO+0x12]             ; ancho
    mov bx, [MODE_INFO+0x14]             ; alto
    cmp ax, [pass_maxw]
    ja .sm_loop
    cmp bx, [pass_maxh]
    ja .sm_loop
    cmp word [pass_w], 0
    je .sm_accept
    cmp ax, [pass_w]
    jne .sm_loop
    cmp bx, [pass_h]
    jne .sm_loop
.sm_accept:
    movzx eax, ax
    movzx ebx, bx
    mul ebx                              ; eax = w*h (puntuación)
    cmp eax, [best_score]
    jbe .sm_loop
    mov [best_score], eax
    mov cx, [fs:si-2]                    ; modo original de la lista
    and cx, 0x3FFF
    mov [best_mode], cx
    mov byte [found_any], 1
    mov ax, [MODE_INFO+0x10]
    mov [best_pitch], ax
    mov ax, [MODE_INFO+0x12]
    mov [best_w], ax
    mov ax, [MODE_INFO+0x14]
    mov [best_h], ax
    mov al, [MODE_INFO+0x19]
    mov [best_bpp], al
    mov eax, [MODE_INFO+0x28]
    mov [best_paddr], eax
    jmp .sm_loop
.sm_done:
    ret

; ---------------------------------------------------------------------
; Cargar kernel: KERNEL_SECTORS sectores -> KBUF
;   - modo 2 (CD): ya está en el blob, pm32 lo copia desde el blob
;   - 0x0530 != 0 (ISO híbrido por USB): LBA absoluto fijado por el MBR
;   - resto: LBA part_base + 128 (partición o disco entero)
; ---------------------------------------------------------------------
load_kernel:
    cmp byte [0x0528], 2         ; arranque desde CD: kernel aún en el blob
    jne .lk_disk
    mov word [ksrc_seg], KERNEL_BLOB_SEG
    jmp build_tables             ; el blob sobrevive al cambio de modo VBE
.lk_disk:
    mov eax, [0x0530]            ; LBA absoluto (ISO híbrido por USB)
    test eax, eax
    jnz .lk_have
    mov eax, [0x0534]            ; base de la partición FenixOS
    add eax, 128
.lk_have:
    mov [cur_lba], eax
    mov dword [sect_left], KERNEL_SECTORS
    mov word [dst_seg], 0x4000
.lk_chunk:
    cmp dword [sect_left], 0
    je .lk_done
    mov dword [chunk], 64
    mov eax, [sect_left]
    cmp eax, 64
    jae .lk_have2
    mov [chunk], eax
.lk_have2:
    mov byte [DAP], 0x10                 ; tamaño del paquete
    mov byte [DAP+1], 0                  ; reservado
    mov ax, [chunk]
    mov [DAP+2], ax                      ; nº sectores
    mov word [DAP+4], 0                  ; offset = 0
    mov ax, [dst_seg]
    mov [DAP+6], ax                      ; segmento
    mov eax, [cur_lba]
    mov [DAP+8], eax                     ; LBA (32 bits bajos)
    mov dword [DAP+12], 0                ; LBA altos
    mov si, DAP
    mov ah, 0x42
    mov dl, [BI+0x24]                    ; unidad de arranque
    int 0x13
    jc kern_fail
    mov eax, [chunk]
    sub [sect_left], eax
    add [cur_lba], eax
    add word [dst_seg], 0x800            ; 64 sectores = 0x8000 bytes
    jmp .lk_chunk

.lk_done:

; ---------------------------------------------------------------------
; Tablas de página (ES=0)
; ---------------------------------------------------------------------
build_tables:
    xor ax, ax
    mov es, ax
    xor eax, eax
    mov di, PML4
    mov cx, 4096                         ; 16KB a cero: PML4+PDPT+PD_LO+PD_FB
    rep stosd

    mov dword [PML4], 0x2003             ; PML4[0] -> PDPT
    mov dword [PDPT], 0x3003             ; PDPT[0] -> PD del primer 1GB

    xor eax, eax
    mov di, PD_LO
    mov cx, 512
.pdl:
    mov edx, eax
    or edx, 0x83                         ; P | W | PS
    mov [di], edx
    add eax, 0x200000
    add di, 8
    loop .pdl

    mov eax, [BI+4]                      ; fb_paddr
    shr eax, 30                          ; índice de 1GB del framebuffer
    mov ebx, eax
    shl ebx, 3
    mov dword [PDPT+ebx], 0x4003         ; PDPT[idx] -> PD_FB
    mov eax, [BI+4]
    and eax, 0xC0000000                  ; base del GB del framebuffer
    mov di, PD_FB
    mov cx, 512
.pdf:
    mov edx, eax
    or edx, 0x83
    mov [di], edx
    add eax, 0x200000
    add di, 8
    loop .pdf

; ---------------------------------------------------------------------
; Bootinfo completo ('FNX1' = señal de arranque válido)
; ---------------------------------------------------------------------
fill_bootinfo:
    movzx eax, word [e820_count]         ; solo 16 bits (¡el dword siguiente es otra variable!)
    mov [BI+0x18], eax
    mov dword [BI+0x1C], E820_BUF
    mov eax, KERNEL_SECTORS
    mov [BI+0x20], eax
    mov eax, [0x0530]
    mov [BI+0x30], eax                   ; LBA absoluto del kernel (híbrido)
    mov eax, [0x0534]
    mov [BI+0x34], eax                   ; base de la partición FenixOS
    mov eax, [0x0538]
    mov [BI+0x38], eax                   ; sectores de partición/disco
    mov eax, [0x052C]
    and eax, 1                           ; bit0 = modo seguro (del menú)
    cmp byte [0x0528], 2
    jne .fb_nocd
    or eax, 2                            ; bit1 = arranque desde CD
.fb_nocd:
    mov [BI+0x2C], eax
    mov dword [BI], 0x314E5846           ; 'FNX1'

; ---------------------------------------------------------------------
; Modo protegido (32-bit): copiar kernel a 0x100000
; ---------------------------------------------------------------------
go_pm:
    cli
    lgdt [gdt_desc]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp 0x18:pm32

kern_fail:
    mov si, err_kern
    call print
    jmp halt

BITS 32
pm32:
    mov ax, 0x10
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov fs, ax
    mov gs, ax
    mov esp, 0x7C00
    ; origen del kernel: KBUF (0x40000, disco/USB) o blob (CD)
    movzx esi, word [ksrc_seg]
    shl esi, 4
    mov edi, KLOAD
    mov ecx, KERNEL_DWORDS
    cld
    rep movsd

    mov eax, cr4
    or eax, 0x20                         ; PAE
    mov cr4, eax
    mov eax, PML4
    mov cr3, eax
    mov ecx, 0xC0000080                  ; EFER
    rdmsr
    or eax, 0x100                        ; LME
    wrmsr
    mov eax, cr0
    or eax, 0x80000000                   ; PG
    mov cr0, eax
    jmp 0x08:lm64

BITS 64
lm64:
    xor eax, eax
    mov ds, eax
    mov es, eax
    mov ss, eax
    mov fs, eax
    mov gs, eax
    mov rsp, KSTACK
    mov rdi, BOOTINFO
    mov rax, KLOAD
    jmp rax

.hang:
    cli
    hlt
    jmp .hang

; ---------------------------------------------------------------------
; utilidades 16-bit
; ---------------------------------------------------------------------
BITS 16
print:
    lodsb
    or al, al
    jz .d
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    jmp print
.d: ret

pchar16:
    push bx
    mov ah, 0x0E
    mov bx, 0x0007
    int 0x10
    pop bx
    ret

; print_dec: EAX -> decimal (clobbers ecx/edx)
print_dec:
    push eax
    push ebx
    push ecx
    push edx
    mov ebx, 10
    xor ecx, ecx
.pd1:
    xor edx, edx
    div ebx
    push dx
    inc ecx
    test eax, eax
    jnz .pd1
.pd2:
    pop ax
    add al, '0'
    call pchar16
    loop .pd2
    pop edx
    pop ecx
    pop ebx
    pop eax
    ret

; rd_lba_boot: AH=42h con rd_dap sobre la unidad de arranque (0x0524)
rd_lba_boot:
    mov byte [rd_dap], 0x10
    mov byte [rd_dap+1], 0
    mov si, rd_dap
    mov ah, 0x42
    mov dl, [0x0524]
    int 0x13
    ret

; chain_jump: transfiere el control al VBR ya cargado en 0x7C00
chain_jump:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    mov dl, [0x0524]
    sti
    jmp 0x0000:0x7C00

halt:
    hlt
    jmp halt

; ---------------------------------------------------------------------
; datos
; ---------------------------------------------------------------------
align 8
gdt:
    dq 0
    dq 0x00AF9A000000FFFF                ; 0x08: código 64-bit
    dq 0x00CF92000000FFFF                ; 0x10: datos
    dq 0x00CF9A000000FFFF                ; 0x18: código 32-bit
gdt_desc:
    dw gdt_desc - gdt - 1
    dd gdt

msg_hello: db "[Fenix] stage2 1.3: e820+menu+VBE+kernel", 13, 10, 0
err_mem:   db "[Fenix] ERROR: mapa de memoria", 0
err_vbe:   db "[Fenix] ERROR: VBE no disponible", 0
err_kern:  db "[Fenix] ERROR: carga de kernel", 0
crlf:      db 13, 10, 0

; ---------------- menú multiboot ----------------
menu_hdr:  db 13, 10
           db "=============================================================", 13, 10
           db "  FenixOS 1.3 'Titan' - Gestor de Arranque", 13, 10
           db "=============================================================", 13, 10, 0
menu_items db " 1) Iniciar FenixOS", 13, 10
           db " 2) FenixOS - modo seguro (sin red ni raton)", 13, 10
           db " 3) Iniciar otro sistema de este disco", 13, 10
           db " 4) Iniciar desde otro disco (USB / 2do disco)", 13, 10
           db " 5) Informacion del sistema", 13, 10
           db "-------------------------------------------------------------", 13, 10, 0
menu_def1: db " Autoarranque en ", 0
menu_def2: db " s  -  opcion por defecto: ", 0
menu_def3: db " (pulsa 1-5)", 13, 10, 0

cp_hdr:    db " Particiones del disco (Windows/Linux siguen arrancando:", 13, 10
           db " FenixOS no modifica ninguna particion existente):", 13, 10, 0
cp_sep:    db ") ", 0
cp_sizepre db " ~", 0
cp_mb:     db " MB", 0
cp_active: db " [activa]", 13, 10, 0
cp_ask:    db 13, 10, " Particion a arrancar (1-4, otra tecla = menu): ", 0
cp_gpt:    db 13, 10, " GPT detectado: chainload no soportado en modo BIOS.", 13, 10, 0
cp_fail:   db 13, 10, " [Fenix] Error leyendo el sector de arranque.", 13, 10, 0

cd_hdr:    db " Discos duros del BIOS:", 13, 10, 0
cd_sep:    db ") ~", 0
cd_ask:    db 13, 10, " Disco a arrancar (0-7, otra tecla = menu): ", 0

mi_hdr:    db 13, 10, "=== Informacion del sistema (modo texto) ===", 13, 10, 0
mi_cpu:    db " CPU: ", 0
mi_ram:    db " RAM utilizable: ", 0
mi_mb:     db " MB", 13, 10, 0
mi_disk:   db " Discos BIOS: ", 0
mi_foot:   db 13, 10, " Pulsa una tecla para volver al menu...", 0

t_ntfs:    db "Windows (NTFS)", 0
t_fat:     db "Windows (FAT)", 0
t_linux:   db "Linux", 0
t_swap:    db "Linux swap", 0
t_efi:     db "EFI", 0
t_fenix:   db "FenixOS", 0
t_unk:     db "Otro", 0

BI equ BOOTINFO

; ---------------- variables ----------------
e820_count: dw 0
mlist_off:  dw 0
mlist_seg:  dw 0
pass_bpp:   db 0
pass_w:     dw 0
pass_h:     dw 0
pass_maxw:  dw 0
pass_maxh:  dw 0
found_any:  db 0
best_score: dd 0
best_mode:  dw 0
best_pitch: dw 0
best_w:     dw 0
best_h:     dw 0
best_bpp:   db 0
best_paddr: dd 0
chunk:      dd 0
sect_left:  dd 0
cur_lba:    dd 0
dst_seg:    dw 0
ksrc_seg:   dw 0x4000                    ; origen del kernel para pm32 (KBUF>>4)
safe_mode:  db 0
def_opt:    db 1
tmo_secs:   db 8
deadline:   dd 0
cnt_row:    db 0
cnt_col:    db 0
cp_idx:     db 0
cp_sel:     db 0
cd_idx:     db 0
cd_target:  db 0x80
mi_buf:     times 52 db 0
; Disk Address Packet genérico (lectura por la unidad de arranque)
; +0 tamaño, +1 res, +2 nº sectores, +4 offset, +6 segmento, +8 LBA
rd_dap:     db 0x10, 0, 1, 0
            dw 0, 0
            dq 0
; paquete AH=48h (resultado del sondeo de tamaño de disco)
dap48:      times 0x20 db 0
; paquete para el sector de configuración del gestor de arranque
bc_dap:     db 0x10, 0, 1, 0
            dw BOOTCFG_BUF, 0
            dq 0

; relleno exacto a 40 sectores (20480 bytes)
times (STAGE2_PAD)-($-$$) db 0
