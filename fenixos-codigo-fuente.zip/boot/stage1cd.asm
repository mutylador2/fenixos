; =====================================================================
; FenixOS Bootloader — Etapa 0 para CD (stub El Torito, 512 bytes)
;
; El CD se construye con El Torito en modo SIN EMULACIÓN y el blob de
; arranque contiene TODO: este stub (0x7C00) + stage2 (0x7E00) + el
; kernel completo (tras stage2). SeaBIOS (y cualquier BIOS El Torito)
; copia el blob entero a 0x7C00 antes de saltar aquí, así que NO hace
; falta leer nada del CD: el kernel ya está en RAM.
;
;   1. Marca el modo de arranque 2 (kernel ya cargado) en 0x0528
;   2. Pone a cero las banderas y la geometría de instalación
;   3. Salta a stage2 (0x7E00), que continúa con e820/VBE/modo largo
;
; v1.3: SRC_SEG es paramétrico (depende del tamaño real de stage2, 40
; sectores = 20480 bytes -> kernel en 0xCC00).
;
; Por qué no El Torito con emulación de disco duro: la unidad emulada
; de SeaBIOS/QEMU solo acepta comandos INT 13h clásicos y la ruta
; AH=02h sobre el cdemu se cuelga. Con el blob completo evitamos esa
; ruta por completo.
; =====================================================================
BITS 16
ORG 0x7C00

%ifndef STAGE2_PAD
%define STAGE2_PAD 20480
%endif
SRC_SEG equ (0x7C00 + 512 + STAGE2_PAD) / 16

start:
    cli
    cld
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00

    mov byte [0x0528], 2                  ; modo: kernel aún en el blob
    mov byte [0x0524], dl                 ; unidad de arranque (informativo)
    mov dword [0x052C], 0                 ; banderas de arranque a cero
    mov dword [0x0530], 0                 ; sin LBA absoluto (no híbrido)
    mov dword [0x0534], 0                 ; sin partición (CD)
    mov dword [0x0538], 0                 ; tamaño desconocido

    xor ax, ax
    mov ds, ax
    jmp 0x0000:0x7E00                     ; continuar en stage2

times 510-($-$$) db 0
dw 0xAA55
